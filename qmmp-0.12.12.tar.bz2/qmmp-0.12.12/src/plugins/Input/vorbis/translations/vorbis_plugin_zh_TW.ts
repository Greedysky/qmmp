<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_TW">
<context>
    <name>DecoderVorbisFactory</name>
    <message>
        <location filename="../decodervorbisfactory.cpp" line="47"/>
        <source>Ogg Vorbis Plugin</source>
        <translation>Ogg Vorbis 外掛</translation>
    </message>
    <message>
        <location filename="../decodervorbisfactory.cpp" line="50"/>
        <source>Ogg Vorbis Files</source>
        <translation>Ogg Vorbis 檔案</translation>
    </message>
    <message>
        <location filename="../decodervorbisfactory.cpp" line="137"/>
        <source>About Ogg Vorbis Audio Plugin</source>
        <translation>關於 Ogg Vorbis 聲訊插件</translation>
    </message>
    <message>
        <location filename="../decodervorbisfactory.cpp" line="138"/>
        <source>Qmmp Ogg Vorbis Audio Plugin</source>
        <translation>Qmmp Ogg Vorbis 聲訊插件</translation>
    </message>
    <message>
        <location filename="../decodervorbisfactory.cpp" line="139"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>撰寫：Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../decodervorbisfactory.cpp" line="140"/>
        <source>Source code based on mq3 project</source>
        <translation>源碼基於 mq3 項目</translation>
    </message>
</context>
</TS>
