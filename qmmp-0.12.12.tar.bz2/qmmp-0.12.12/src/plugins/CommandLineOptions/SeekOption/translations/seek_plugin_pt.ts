<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt">
<context>
    <name>SeekOption</name>
    <message>
        <location filename="../seekoption.cpp" line="29"/>
        <source>Seek to position in the current track</source>
        <translation>Procure para posicionar na faixa atual</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="30"/>
        <source>Seek forward</source>
        <translation>Para a frente</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="31"/>
        <source>Seek backwards</source>
        <translation>Para trás</translation>
    </message>
</context>
</TS>
