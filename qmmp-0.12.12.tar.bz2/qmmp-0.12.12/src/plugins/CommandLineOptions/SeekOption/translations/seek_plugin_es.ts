<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es">
<context>
    <name>SeekOption</name>
    <message>
        <location filename="../seekoption.cpp" line="29"/>
        <source>Seek to position in the current track</source>
        <translation>Ir hasta una posición en la pista actual</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="30"/>
        <source>Seek forward</source>
        <translation>Avanzar</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="31"/>
        <source>Seek backwards</source>
        <translation>Retroceder</translation>
    </message>
</context>
</TS>
