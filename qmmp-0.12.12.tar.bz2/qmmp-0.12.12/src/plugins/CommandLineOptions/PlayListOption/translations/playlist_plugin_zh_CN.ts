<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>PlayListOption</name>
    <message>
        <location filename="../playlistoption.cpp" line="33"/>
        <source>Show playlist manipulation commands</source>
        <translation>显示播放列表的操作命令</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="34"/>
        <source>List all available playlists</source>
        <translation>列出所有可用的播放列表</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="35"/>
        <source>Show playlist content</source>
        <translation>显示播放列表内容</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="36"/>
        <source>Play track &lt;track&gt; in playlist &lt;id&gt;</source>
        <translation>播出播放列表&lt;id&gt;中的曲目&lt;track&gt;</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="37"/>
        <source>Clear playlist</source>
        <translation>清理播放列表</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="38"/>
        <source>Toggle playlist repeat</source>
        <translation>切换播放列表重复功能</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="39"/>
        <source>Toggle playlist shuffle</source>
        <translation>切换播放列表的重排功能</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="40"/>
        <source>Show playlist options</source>
        <translation>显示播放列表选项</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="104"/>
        <location filename="../playlistoption.cpp" line="126"/>
        <location filename="../playlistoption.cpp" line="143"/>
        <source>Invalid playlist ID</source>
        <translation>无效的播放列表ID</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="120"/>
        <source>Invalid number of arguments</source>
        <translation>无效的参数值</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="130"/>
        <source>Invalid track ID</source>
        <translation>无效的曲目ID</translation>
    </message>
</context>
</TS>
