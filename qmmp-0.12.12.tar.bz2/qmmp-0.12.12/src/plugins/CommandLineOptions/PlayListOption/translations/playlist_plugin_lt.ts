<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="lt">
<context>
    <name>PlayListOption</name>
    <message>
        <location filename="../playlistoption.cpp" line="33"/>
        <source>Show playlist manipulation commands</source>
        <translation type="unfinished">Rodyti grojaraščio pagalbą</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="34"/>
        <source>List all available playlists</source>
        <translation type="unfinished">Rodyti visus grojaraščius</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="35"/>
        <source>Show playlist content</source>
        <translation type="unfinished">Rodyti grojaraščio turinį</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="36"/>
        <source>Play track &lt;track&gt; in playlist &lt;id&gt;</source>
        <translation type="unfinished">Groti takelį &lt;track&gt; grojaraštyje &lt;id&gt;</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="37"/>
        <source>Clear playlist</source>
        <translation type="unfinished">Išvalyti grojaraštį</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="38"/>
        <source>Toggle playlist repeat</source>
        <translation type="unfinished">Įjungti grojaraščio kartojimą</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="39"/>
        <source>Toggle playlist shuffle</source>
        <translation type="unfinished">Įjungti grojaraščio sumaišymą</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="40"/>
        <source>Show playlist options</source>
        <translation type="unfinished">Rodyti grojaraščio pasirinkimus</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="104"/>
        <location filename="../playlistoption.cpp" line="126"/>
        <location filename="../playlistoption.cpp" line="143"/>
        <source>Invalid playlist ID</source>
        <translation type="unfinished">Neteisingas grojaraščio ID</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="120"/>
        <source>Invalid number of arguments</source>
        <translation type="unfinished">Neteisingas argumentų kiekis</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="130"/>
        <source>Invalid track ID</source>
        <translation type="unfinished">Neteisingas takelio ID</translation>
    </message>
</context>
</TS>
