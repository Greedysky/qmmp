<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="sr_BA">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About Qmmp</source>
        <translation>О Кумпу</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="49"/>
        <source>About</source>
        <translation>О програму</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="105"/>
        <source>License Agreement</source>
        <translation>Уговор о лиценци</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="63"/>
        <source>Authors</source>
        <translation>Аутори</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="91"/>
        <source>Thanks To</source>
        <translation>Захвала</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="63"/>
        <source>Qt-based Multimedia Player (Qmmp)</source>
        <translation>Кут мултимедијални плејер (Кумп)</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="67"/>
        <source>Version: %1</source>
        <translation>Издање: %1</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="68"/>
        <source>Using Qt %1 (compiled with Qt %2)</source>
        <translation>Користим Кут %1 (компајлиран Кутом %2)</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="71"/>
        <source>(c) %1-%2 Qmmp Development Team</source>
        <translation>© %1-%2 Кумп развојни тим</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="76"/>
        <source>Input plugins:</source>
        <translation>Прикључци улаза:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="85"/>
        <source>Output plugins:</source>
        <translation>Прикључци излаза:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="94"/>
        <source>Visual plugins:</source>
        <translation>Визуелни прикључци:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="103"/>
        <source>Effect plugins:</source>
        <translation>Прикључци ефекта:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="112"/>
        <source>General plugins:</source>
        <translation>Општи прикључци:</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="77"/>
        <source>Translators</source>
        <translation>Преводиоци</translation>
    </message>
</context>
<context>
    <name>AddUrlDialog</name>
    <message>
        <location filename="../forms/addurldialog.ui" line="14"/>
        <source>Enter URL to add</source>
        <translation>Унесите УРЛ</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="46"/>
        <source>&amp;Add</source>
        <translation>&amp;Додај</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="53"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Одустани</translation>
    </message>
    <message>
        <location filename="../addurldialog.cpp" line="85"/>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
</context>
<context>
    <name>ColumnEditor</name>
    <message>
        <location filename="../forms/columneditor.ui" line="14"/>
        <source>Edit Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="36"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="76"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="64"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="29"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="85"/>
        <source>Artist</source>
        <translation type="unfinished">Извођач</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="86"/>
        <source>Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="90"/>
        <source>Title</source>
        <translation type="unfinished">Наслов</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="93"/>
        <source>Genre</source>
        <translation type="unfinished">Жанр</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="94"/>
        <source>Comment</source>
        <translation type="unfinished">Коментар</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="95"/>
        <source>Composer</source>
        <translation type="unfinished">Композитор</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="96"/>
        <source>Duration</source>
        <translation type="unfinished">дужину</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="101"/>
        <source>Year</source>
        <translation type="unfinished">Година</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="100"/>
        <source>Track Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="87"/>
        <source>Artist - Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="88"/>
        <source>Artist - Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="89"/>
        <source>Album Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="91"/>
        <source>Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="92"/>
        <source>Two-digit Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="97"/>
        <source>Disc Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="98"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="99"/>
        <source>File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="102"/>
        <source>Parent Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="103"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../forms/configdialog.ui" line="325"/>
        <source>Description</source>
        <translation>опис</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="330"/>
        <source>Filename</source>
        <translation>име фајла</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="65"/>
        <source>Album</source>
        <translation>албум</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="64"/>
        <source>Track</source>
        <translation>нумера</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="66"/>
        <source>Disabled</source>
        <translation>онемогућен</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="85"/>
        <source>File Types</source>
        <translation>Типови фајлова</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="190"/>
        <source>Transports</source>
        <translation>Преноси</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="201"/>
        <source>Decoders</source>
        <translation>Декодери</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="212"/>
        <source>Engines</source>
        <translation>Мотори</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="256"/>
        <source>Output</source>
        <translation>Излаз</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="267"/>
        <source>File Dialogs</source>
        <translation>Дијалози фајлова</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="278"/>
        <source>User Interfaces</source>
        <translation>Корисничка сучеља</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="328"/>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;аутодетекција&gt;</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="329"/>
        <source>Brazilian Portuguese</source>
        <translation>бразилски португалски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="330"/>
        <source>Chinese Simplified</source>
        <translation>поједностављени кинески</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="331"/>
        <source>Chinese Traditional</source>
        <translation>традиционални кинески</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="332"/>
        <source>Czech</source>
        <translation>чешки</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="333"/>
        <source>Dutch</source>
        <translation>холандски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="334"/>
        <source>English</source>
        <translation>енглески</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="335"/>
        <source>French</source>
        <translation>француски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="336"/>
        <source>Galician</source>
        <translation>галицијски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="337"/>
        <source>German</source>
        <translation>њемачки</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="338"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="339"/>
        <source>Hebrew</source>
        <translation>хебрејски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="340"/>
        <source>Hungarian</source>
        <translation>мађарски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="341"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="342"/>
        <source>Italian</source>
        <translation>италијански</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="343"/>
        <source>Japanese</source>
        <translation>јапански</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="344"/>
        <source>Kazakh</source>
        <translation>казашки</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="345"/>
        <source>Lithuanian</source>
        <translation>литвански</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="346"/>
        <source>Polish</source>
        <translation>пољски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="347"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="348"/>
        <source>Russian</source>
        <translation>руски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="349"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="350"/>
        <source>Slovak</source>
        <translation>словачки</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="351"/>
        <source>Spanish</source>
        <translation>шпански</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="352"/>
        <source>Turkish</source>
        <translation>турски</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="353"/>
        <source>Ukrainian</source>
        <translation>украјински</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="354"/>
        <source>Serbian (Ijekavian)</source>
        <translation>српски (ијекавски)</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="355"/>
        <source>Serbian (Ekavian)</source>
        <translation>српски (екавски)</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="14"/>
        <source>Qmmp Settings</source>
        <translation>Поставке Кумпа</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="160"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="123"/>
        <source>Metadata</source>
        <translation>Метаподаци</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="129"/>
        <source>Load metadata from files</source>
        <translation>Учитај метаподатке из фајла</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="270"/>
        <location filename="../configdialog.cpp" line="315"/>
        <source>Preferences</source>
        <translation>Подешавањa</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="283"/>
        <location filename="../configdialog.cpp" line="318"/>
        <source>Information</source>
        <translation>Подаци</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="58"/>
        <source>Playlist</source>
        <translation>Листа нумера</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="67"/>
        <source>Plugins</source>
        <translation>Прикључци</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="76"/>
        <source>Advanced</source>
        <translation>Напредно</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="85"/>
        <source>Connectivity</source>
        <translation>Повезивање</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="234"/>
        <source>Visualization</source>
        <translation>Визуелизација</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="223"/>
        <source>Effects</source>
        <translation>Ефекти</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="245"/>
        <source>General</source>
        <translation>Опште</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="94"/>
        <location filename="../forms/configdialog.ui" line="768"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="150"/>
        <source>Group format:</source>
        <translation>Формат групе:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="170"/>
        <source>Read tags while loading a playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="180"/>
        <source>Directory Scanning Options</source>
        <translation>Опције скенирања фасцикле</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="186"/>
        <source>Restrict files to:</source>
        <translation>Ограничи фајлове на:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="209"/>
        <source>Miscellaneous</source>
        <translation>Разно</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="215"/>
        <source>Auto-save playlist when modified</source>
        <translation>Аутоматски сачувај листу нумера по измјени</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="222"/>
        <source>Clear previous playlist when opening new one</source>
        <translation>Очисти претходну листу нумера по отварању нове</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="342"/>
        <source>Look and Feel</source>
        <translation>Изглед</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="348"/>
        <source>Language:</source>
        <translation>Језик:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="404"/>
        <source>Add files from command line to this playlist:</source>
        <translation>Додај фајлове са командне линије у ову листу нумера:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="491"/>
        <source>URL Dialog</source>
        <translation>УРЛ дијалог</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="497"/>
        <source>Auto-paste URL from clipboard</source>
        <translation>Аутоматски налијепи УРЛ са клипборда</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="638"/>
        <source>Replay Gain</source>
        <translation>Нивелатор јачине</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="644"/>
        <source>Replay Gain mode:</source>
        <translation>Режим нивелатора јачине:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="661"/>
        <source>Preamp:</source>
        <translation>Претпојачање:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="693"/>
        <location filename="../forms/configdialog.ui" line="738"/>
        <source>dB</source>
        <translation>dB</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="706"/>
        <source>Default gain:</source>
        <translation>Подразумијевано:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="758"/>
        <source>Use  peak info to prevent clipping</source>
        <translation>Користи податке о врховима да спријечиш насијецање</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="788"/>
        <source>Buffer size:</source>
        <translation>Величина бафера:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="807"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="823"/>
        <source>Use software volume control</source>
        <translation>Софтверска контрола јачине звука</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="840"/>
        <source>Volume adjustment step:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="774"/>
        <source>Output bit depth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="781"/>
        <source>Use dithering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="421"/>
        <source>Cover Image Retrieve</source>
        <translation>Добављање слике омота</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="427"/>
        <source>Use separate image files</source>
        <translation>Користи засебне фајлове слика</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="437"/>
        <source>Include files:</source>
        <translation>Укључи фајлове:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="196"/>
        <location filename="../forms/configdialog.ui" line="447"/>
        <source>Exclude files:</source>
        <translation>Искључи фајлове:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="459"/>
        <source>Recursive search depth:</source>
        <translation>Дубина рекурзивне претраге:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="384"/>
        <source>Playback</source>
        <translation>Пуштање</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="390"/>
        <source>Continue playback on startup</source>
        <translation>Настави пуштање по покретању</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="397"/>
        <source>Determine file type by content</source>
        <translation>Одреди тип фајла по садржају</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="536"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="548"/>
        <source>Enable proxy usage</source>
        <translation>Користи прокси</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="555"/>
        <source>Proxy host name:</source>
        <translation>Сервер:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="568"/>
        <source>Proxy port:</source>
        <translation>Порт:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="581"/>
        <source>Use authentication with proxy</source>
        <translation>Користи аутентификацију</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="588"/>
        <source>Proxy user name:</source>
        <translation>Корисничко име:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="601"/>
        <source>Proxy password:</source>
        <translation>Лозинка:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="136"/>
        <source>Convert underscores to blanks</source>
        <translation>Претвори доње црте у размак</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="143"/>
        <source>Convert %20 to blanks</source>
        <translation>Претвори %20 у размак</translation>
    </message>
</context>
<context>
    <name>CoverEditor</name>
    <message>
        <location filename="../forms/covereditor.ui" line="22"/>
        <source>Image source:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="76"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="83"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="90"/>
        <source>Save as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="33"/>
        <source>External file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="34"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoverViewer</name>
    <message>
        <location filename="../coverviewer.cpp" line="35"/>
        <source>&amp;Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="68"/>
        <source>Save Cover As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="70"/>
        <location filename="../coverviewer.cpp" line="83"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="81"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DetailsDialog</name>
    <message>
        <location filename="../detailsdialog.cpp" line="170"/>
        <source>%1/%2</source>
        <translation>%1/%2</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="216"/>
        <source>Cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="246"/>
        <source>Title</source>
        <translation>Наслов</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="247"/>
        <source>Artist</source>
        <translation>Извођач</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="248"/>
        <source>Album artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="249"/>
        <source>Album</source>
        <translation>Албум</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="250"/>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="251"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="252"/>
        <source>Composer</source>
        <translation>Композитор</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="253"/>
        <source>Year</source>
        <translation>Година</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="254"/>
        <source>Track</source>
        <translation>Нумера</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="255"/>
        <source>Disc number</source>
        <translation>Број диска</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="273"/>
        <source>Duration</source>
        <translation type="unfinished">дужину</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="276"/>
        <source>Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="276"/>
        <source>kbps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="277"/>
        <source>Sample rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="277"/>
        <source>Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="278"/>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="279"/>
        <source>Sample size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="279"/>
        <source>bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="280"/>
        <source>Format name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="281"/>
        <source>File size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="281"/>
        <source>KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="325"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="325"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="14"/>
        <source>Details</source>
        <translation>Детаљи</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="44"/>
        <source>Open the directory containing this file</source>
        <translation>Отвори фасциклу овог фајла</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="47"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="63"/>
        <source>Summary</source>
        <translation>Резиме</translation>
    </message>
</context>
<context>
    <name>JumpToTrackDialog</name>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="14"/>
        <source>Jump To Track</source>
        <translation>Скок на нумеру</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="37"/>
        <source>Filter:</source>
        <translation>Филтер:</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="73"/>
        <location filename="../jumptotrackdialog.cpp" line="91"/>
        <location filename="../jumptotrackdialog.cpp" line="138"/>
        <source>Queue</source>
        <translation>Стави у ред</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="89"/>
        <source>Refresh</source>
        <translation>Освјежи</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="105"/>
        <source>Jump To</source>
        <translation>Скочи на</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="58"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="59"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="60"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="89"/>
        <location filename="../jumptotrackdialog.cpp" line="136"/>
        <source>Unqueue</source>
        <translation>Уклони из реда</translation>
    </message>
</context>
<context>
    <name>MetaDataFormatterMenu</name>
    <message>
        <location filename="../metadataformattermenu.cpp" line="26"/>
        <source>Artist</source>
        <translation type="unfinished">Извођач</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="27"/>
        <source>Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="28"/>
        <source>Album Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="31"/>
        <source>Title</source>
        <translation type="unfinished">Наслов</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="32"/>
        <source>Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="33"/>
        <source>Two-digit Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="37"/>
        <source>Track Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="39"/>
        <source>Genre</source>
        <translation type="unfinished">Жанр</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="40"/>
        <source>Comment</source>
        <translation type="unfinished">Коментар</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="41"/>
        <source>Composer</source>
        <translation type="unfinished">Композитор</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="46"/>
        <source>Duration</source>
        <translation type="unfinished">дужину</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="58"/>
        <source>Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="59"/>
        <source>Sample Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="60"/>
        <source>Number of Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="61"/>
        <source>Sample Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="62"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="63"/>
        <source>Decoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="66"/>
        <source>File Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="42"/>
        <source>Disc Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="47"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="48"/>
        <source>File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="43"/>
        <source>Year</source>
        <translation type="unfinished">Година</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="50"/>
        <source>Condition</source>
        <translation type="unfinished">услов</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="49"/>
        <source>Artist - Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="54"/>
        <source>Artist - [Year] Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="56"/>
        <source>Parent Directory Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListDownloader</name>
    <message>
        <location filename="../playlistdownloader.cpp" line="117"/>
        <source>Unsupported playlist format</source>
        <translation>Неподржан формат листе нумера</translation>
    </message>
</context>
<context>
    <name>PlayListHeaderModel</name>
    <message>
        <location filename="../playlistheadermodel.cpp" line="36"/>
        <source>Artist - Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="186"/>
        <source>Title</source>
        <translation type="unfinished">Наслов</translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="187"/>
        <source>Add Column</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListManager</name>
    <message>
        <location filename="../playlistmanager.cpp" line="171"/>
        <location filename="../playlistmanager.cpp" line="316"/>
        <source>Playlist</source>
        <translation>Листа нумера</translation>
    </message>
</context>
<context>
    <name>PlayListTrack</name>
    <message>
        <location filename="../playlisttrack.cpp" line="249"/>
        <source>Streams</source>
        <translation>Токови</translation>
    </message>
    <message>
        <location filename="../playlisttrack.cpp" line="254"/>
        <source>Empty group</source>
        <translation>Празна група</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../winfileassoc.cpp" line="278"/>
        <source>Enqueue in Qmmp</source>
        <translation>Стави у ред пуштања у Кумпу</translation>
    </message>
</context>
<context>
    <name>QmmpUiSettings</name>
    <message>
        <location filename="../qmmpuisettings.cpp" line="57"/>
        <source>Playlist</source>
        <translation>Листа нумера</translation>
    </message>
</context>
<context>
    <name>QtFileDialogFactory</name>
    <message>
        <location filename="../qtfiledialog.cpp" line="34"/>
        <source>Qt File Dialog</source>
        <translation>Кут дијалог фајлова</translation>
    </message>
</context>
<context>
    <name>TagEditor</name>
    <message>
        <location filename="../forms/tageditor.ui" line="38"/>
        <source>Title:</source>
        <translation>Наслов:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="64"/>
        <source>Artist:</source>
        <translation>Извођач:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="90"/>
        <source>Album:</source>
        <translation>Албум:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="113"/>
        <source>Album artist:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="123"/>
        <source>Composer:</source>
        <translation>Композитор:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="143"/>
        <source>Genre:</source>
        <translation>Жанр:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="250"/>
        <source>Disc number:</source>
        <translation>Диск:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="190"/>
        <location filename="../forms/tageditor.ui" line="228"/>
        <location filename="../forms/tageditor.ui" line="260"/>
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="169"/>
        <source>Track:</source>
        <translation>Нумера:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="203"/>
        <source>Year:</source>
        <translation>Година:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="14"/>
        <source>Tag Editor</source>
        <translation>Уређивач ознака</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="275"/>
        <source>Comment:</source>
        <translation>Коментар:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="311"/>
        <source>Include selected tag in file</source>
        <translation>Укључи ознаку у фајл</translation>
    </message>
</context>
<context>
    <name>TemplateEditor</name>
    <message>
        <location filename="../forms/templateeditor.ui" line="39"/>
        <source>Reset</source>
        <translation>Ресетуј</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="46"/>
        <source>Insert</source>
        <translation>Уметни</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="14"/>
        <source>Template Editor</source>
        <translation>Уређивач шаблона</translation>
    </message>
</context>
<context>
    <name>UiHelper</name>
    <message>
        <location filename="../uihelper.cpp" line="124"/>
        <location filename="../uihelper.cpp" line="136"/>
        <source>All Supported Bitstreams</source>
        <translation>Сви подржани формати</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="130"/>
        <source>Select one or more files to open</source>
        <translation>Изаберите један или више фајлова за отварање</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="142"/>
        <source>Select one or more files to play</source>
        <translation>Изаберите један или више фајлова за пуштање</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="150"/>
        <source>Choose a directory</source>
        <translation>Изаберите фасциклу</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="166"/>
        <location filename="../uihelper.cpp" line="190"/>
        <source>Playlist Files</source>
        <translation>Фајлови листа нумера</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="168"/>
        <source>Open Playlist</source>
        <translation>Отварање листе нумера</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="191"/>
        <source>Save Playlist</source>
        <translation>Уписивање листе нумера</translation>
    </message>
</context>
<context>
    <name>WinFileAssocPage</name>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="17"/>
        <source>Media files handled by Qmmp:</source>
        <translation>Фајлови медија којима рукује Кумп:</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="49"/>
        <source>Select All</source>
        <translation>Изабери све</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="56"/>
        <source>Select None</source>
        <translation>Поништи избор</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="136"/>
        <source>Warning</source>
        <translation>Упозорење</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="137"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Нису сви фајлови могли да се додијеле. Провјерите ваше дозволе и покушајте поново.</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="144"/>
        <source>Check all file types in the list</source>
        <translation>Изабери све типове фајлова са списка</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="145"/>
        <source>Uncheck all file types in the list</source>
        <translation>Уклони избор са свих типова фајла са списка</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="146"/>
        <source>Check the media file extensions you would like Qmmp to handle. When you click Apply, the checked files will be associated with Qmmp. If you uncheck a media type, the file association will be restored.</source>
        <translation>Изаберите типове медија фајлова којима желите да рукује Кумп. Кад притиснете дугме Примијени, изабрани фајлови биће додијељени Кумпу. Ако уклоните избор, уклонићете додјелу Кумпу.</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="150"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Restoration doesn&apos;t work on Windows Vista/7.</source>
        <translation>&lt;b&gt;Напомена:&lt;/b&gt; Враћање оригиналних додјела не ради на Виндоуз Висти/7.</translation>
    </message>
</context>
</TS>
