<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nl">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About Qmmp</source>
        <translation>Over Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="49"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="63"/>
        <source>Authors</source>
        <translation>Auteurs</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="77"/>
        <source>Translators</source>
        <translation>Vertalers</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="91"/>
        <source>Thanks To</source>
        <translation>Met dank aan</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="105"/>
        <source>License Agreement</source>
        <translation>Licentie Overeenkomst</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="63"/>
        <source>Qt-based Multimedia Player (Qmmp)</source>
        <translation>Qt gebaseerde multimediaspeler (Qmmp)</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="67"/>
        <source>Version: %1</source>
        <translation>Versie: %1</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="68"/>
        <source>Using Qt %1 (compiled with Qt %2)</source>
        <translation>Gebruikt Qt %1 (gecompileerd met Qt %2)</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="71"/>
        <source>(c) %1-%2 Qmmp Development Team</source>
        <translation>(c) %1-%2 Qmmp Ontwikkelingsteam</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="76"/>
        <source>Input plugins:</source>
        <translation>Invoer plugins:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="85"/>
        <source>Output plugins:</source>
        <translation>Uitvoer plugins:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="94"/>
        <source>Visual plugins:</source>
        <translation>Visuele plugins:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="103"/>
        <source>Effect plugins:</source>
        <translation>Effect plugins:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="112"/>
        <source>General plugins:</source>
        <translation>Algemene plugins:</translation>
    </message>
</context>
<context>
    <name>AddUrlDialog</name>
    <message>
        <location filename="../forms/addurldialog.ui" line="14"/>
        <source>Enter URL to add</source>
        <translation>Geef nieuwe URL</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="46"/>
        <source>&amp;Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="53"/>
        <source>&amp;Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../addurldialog.cpp" line="85"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
</context>
<context>
    <name>ColumnEditor</name>
    <message>
        <location filename="../forms/columneditor.ui" line="14"/>
        <source>Edit Column</source>
        <translation>Wijzig kolom</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="36"/>
        <source>Name:</source>
        <translation>Naam:</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="76"/>
        <source>Format:</source>
        <translation>Formaat:</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="64"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="29"/>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="85"/>
        <source>Artist</source>
        <translation>Artiest</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="86"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="90"/>
        <source>Title</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="93"/>
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="94"/>
        <source>Comment</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="95"/>
        <source>Composer</source>
        <translation>Componist</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="96"/>
        <source>Duration</source>
        <translation>Duur</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="101"/>
        <source>Year</source>
        <translation>Jaar</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="100"/>
        <source>Track Index</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="87"/>
        <source>Artist - Album</source>
        <translation>Artiest - Album</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="88"/>
        <source>Artist - Title</source>
        <translation>Artiest - Titel</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="89"/>
        <source>Album Artist</source>
        <translation>Album Artiest</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="91"/>
        <source>Track Number</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="92"/>
        <source>Two-digit Track Number</source>
        <translation>2 cijferig nummer</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="97"/>
        <source>Disc Number</source>
        <translation>Schijf nummer</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="98"/>
        <source>File Name</source>
        <translation>Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="99"/>
        <source>File Path</source>
        <translation>Bestandspad</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="102"/>
        <source>Parent Directory</source>
        <translation>Bovenliggende map</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="103"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
</context>
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../forms/configdialog.ui" line="14"/>
        <source>Qmmp Settings</source>
        <translation>Qmmp Instellingen</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="58"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="67"/>
        <source>Plugins</source>
        <translation>Modules</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="76"/>
        <source>Advanced</source>
        <translation>Geavanceerd</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="85"/>
        <source>Connectivity</source>
        <translation>Connectiviteit</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="94"/>
        <location filename="../forms/configdialog.ui" line="768"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="123"/>
        <source>Metadata</source>
        <translation>Metadata</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="143"/>
        <source>Convert %20 to blanks</source>
        <translation>Zet %20 om in spaties</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="129"/>
        <source>Load metadata from files</source>
        <translation>Laad metadata van bestanden</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="136"/>
        <source>Convert underscores to blanks</source>
        <translation>Zet lage strepen om in spaties</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="150"/>
        <source>Group format:</source>
        <translation>Groep formaat:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="160"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="170"/>
        <source>Read tags while loading a playlist</source>
        <translation>Tags uitlezen tijdens laden van afspeellijst</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="180"/>
        <source>Directory Scanning Options</source>
        <translation>Opties voor het scannen van mappen</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="186"/>
        <source>Restrict files to:</source>
        <translation>Gebruikte bestandsformaten:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="196"/>
        <location filename="../forms/configdialog.ui" line="447"/>
        <source>Exclude files:</source>
        <translation>Exclusief de bestanden:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="209"/>
        <source>Miscellaneous</source>
        <translation>Allerlei</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="215"/>
        <source>Auto-save playlist when modified</source>
        <translation>Automatisch playlist bewaren na wijziging</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="222"/>
        <source>Clear previous playlist when opening new one</source>
        <translation>Vorige playlist verwijderen bij het openen van een nieuwe</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="270"/>
        <location filename="../configdialog.cpp" line="315"/>
        <source>Preferences</source>
        <translation>Voorkeuren</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="283"/>
        <location filename="../configdialog.cpp" line="318"/>
        <source>Information</source>
        <translation>Informatie</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="325"/>
        <source>Description</source>
        <translation>Beschrijving</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="330"/>
        <source>Filename</source>
        <translation>Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="342"/>
        <source>Look and Feel</source>
        <translation>Uiterlijk</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="348"/>
        <source>Language:</source>
        <translation>Taal:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="384"/>
        <source>Playback</source>
        <translation>Afspelen</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="390"/>
        <source>Continue playback on startup</source>
        <translation>Verdergaan met afspelen bij opstarten</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="397"/>
        <source>Determine file type by content</source>
        <translation>Bepaal bestandstype op basis van inhoud</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="404"/>
        <source>Add files from command line to this playlist:</source>
        <translation>Voeg bestanden van het commando prompt toe aan de afspeellijst:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="421"/>
        <source>Cover Image Retrieve</source>
        <translation>Gebruik afbeeldingshoes</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="427"/>
        <source>Use separate image files</source>
        <translation>Gebruik aparte afbeeldingsbestanden</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="437"/>
        <source>Include files:</source>
        <translation>Inclusief de bestanden:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="459"/>
        <source>Recursive search depth:</source>
        <translation>Recursieve zoekdiepte:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="491"/>
        <source>URL Dialog</source>
        <translation>URL Dialoog</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="497"/>
        <source>Auto-paste URL from clipboard</source>
        <translation>Automatisch URL plakken van het klembord</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="536"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="548"/>
        <source>Enable proxy usage</source>
        <translation>Gebruik proxy</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="555"/>
        <source>Proxy host name:</source>
        <translation>Proxy host naam:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="568"/>
        <source>Proxy port:</source>
        <translation>Proxy poort:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="581"/>
        <source>Use authentication with proxy</source>
        <translation>Gebruik authenticatie bij proxy</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="588"/>
        <source>Proxy user name:</source>
        <translation>Proxy gebruikersnaam:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="601"/>
        <source>Proxy password:</source>
        <translation>Proxy wachtwoord:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="638"/>
        <source>Replay Gain</source>
        <translation>Replay Gain</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="644"/>
        <source>Replay Gain mode:</source>
        <translation>Replay Gain modus:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="661"/>
        <source>Preamp:</source>
        <translation>Voorversterking:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="693"/>
        <location filename="../forms/configdialog.ui" line="738"/>
        <source>dB</source>
        <translation>dB</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="706"/>
        <source>Default gain:</source>
        <translation>Standaard verhoging:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="758"/>
        <source>Use  peak info to prevent clipping</source>
        <translation>Gebruik piek info om stotteren te voorkomen</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="788"/>
        <source>Buffer size:</source>
        <translation>Buffer-grootte:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="807"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="823"/>
        <source>Use software volume control</source>
        <translation>Gebruik software volume</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="840"/>
        <source>Volume adjustment step:</source>
        <translation>Volumestap:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="774"/>
        <source>Output bit depth:</source>
        <translation>Bitdiepte van uitvoer:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="781"/>
        <source>Use dithering</source>
        <translation>Ruis gebruiken</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="64"/>
        <source>Track</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="65"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="66"/>
        <source>Disabled</source>
        <translation>Uitgeschakeld</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="85"/>
        <source>File Types</source>
        <translation>Bestandstypes</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="190"/>
        <source>Transports</source>
        <translation>Protocols</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="201"/>
        <source>Decoders</source>
        <translation>Decoders</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="212"/>
        <source>Engines</source>
        <translation>Aandrijvingen</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="223"/>
        <source>Effects</source>
        <translation>Effecten</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="234"/>
        <source>Visualization</source>
        <translation>Visualisatie</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="245"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="256"/>
        <source>Output</source>
        <translation>Uitvoer</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="267"/>
        <source>File Dialogs</source>
        <translation>Bestandsdialogen</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="278"/>
        <source>User Interfaces</source>
        <translation>GebruikersInterfaces</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="328"/>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Automatisch&gt;</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="329"/>
        <source>Brazilian Portuguese</source>
        <translation>Portugees (Brazilië)</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="330"/>
        <source>Chinese Simplified</source>
        <translation>Chinees (Vereenvoudigd)</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="331"/>
        <source>Chinese Traditional</source>
        <translation>Chinees (Traditioneel)</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="332"/>
        <source>Czech</source>
        <translation>Tsjechisch</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="333"/>
        <source>Dutch</source>
        <translation>Nederlands</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="334"/>
        <source>English</source>
        <translation>Engels</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="335"/>
        <source>French</source>
        <translation>Frans</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="336"/>
        <source>Galician</source>
        <translation>Galicisch</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="337"/>
        <source>German</source>
        <translation>Duits</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="338"/>
        <source>Greek</source>
        <translation>Grieks</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="339"/>
        <source>Hebrew</source>
        <translation>Hebreeuws</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="340"/>
        <source>Hungarian</source>
        <translation>Hongaars</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="341"/>
        <source>Indonesian</source>
        <translation>Indonesisch</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="342"/>
        <source>Italian</source>
        <translation>Italiaans</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="343"/>
        <source>Japanese</source>
        <translation>Japans</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="344"/>
        <source>Kazakh</source>
        <translation>Kazachs</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="345"/>
        <source>Lithuanian</source>
        <translation>Litouws</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="346"/>
        <source>Polish</source>
        <translation>Pools</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="347"/>
        <source>Portuguese</source>
        <translation>Portugees</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="348"/>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="349"/>
        <source>Serbian</source>
        <translation>Servisch</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="350"/>
        <source>Slovak</source>
        <translation>Slowaaks</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="351"/>
        <source>Spanish</source>
        <translation>Spaans</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="352"/>
        <source>Turkish</source>
        <translation>Turks</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="353"/>
        <source>Ukrainian</source>
        <translation>Oekraïens</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="354"/>
        <source>Serbian (Ijekavian)</source>
        <translation>Servisch (Ijekavisch)</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="355"/>
        <source>Serbian (Ekavian)</source>
        <translation>Servisch (Ekavisch)</translation>
    </message>
</context>
<context>
    <name>CoverEditor</name>
    <message>
        <location filename="../forms/covereditor.ui" line="22"/>
        <source>Image source:</source>
        <translation>Afbeeldingsbron:</translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="76"/>
        <source>Load</source>
        <translation>Laad</translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="83"/>
        <source>Delete</source>
        <translation>Verwijder</translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="90"/>
        <source>Save as...</source>
        <translation>Opslaan als...</translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="33"/>
        <source>External file</source>
        <translation>Extern bestand</translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="34"/>
        <source>Tag</source>
        <translation>Tag</translation>
    </message>
</context>
<context>
    <name>CoverViewer</name>
    <message>
        <location filename="../coverviewer.cpp" line="35"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Bewaar als...</translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="68"/>
        <source>Save Cover As</source>
        <translation>Bewaar Albumhoes Als</translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="70"/>
        <location filename="../coverviewer.cpp" line="83"/>
        <source>Images</source>
        <translation>Afbeeldingen</translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="81"/>
        <source>Open Image</source>
        <translation>Afbeelding openen</translation>
    </message>
</context>
<context>
    <name>DetailsDialog</name>
    <message>
        <location filename="../forms/detailsdialog.ui" line="14"/>
        <source>Details</source>
        <translation>Details</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="44"/>
        <source>Open the directory containing this file</source>
        <translation>Open de bijbehorende map van dit bestand</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="47"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="63"/>
        <source>Summary</source>
        <translation>Samenvatting</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="170"/>
        <source>%1/%2</source>
        <translation>%1/%2</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="216"/>
        <source>Cover</source>
        <translation>Hoes</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="246"/>
        <source>Title</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="247"/>
        <source>Artist</source>
        <translation>Artiest</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="248"/>
        <source>Album artist</source>
        <translation>Album Artiest</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="249"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="250"/>
        <source>Comment</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="251"/>
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="252"/>
        <source>Composer</source>
        <translation>Componist</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="253"/>
        <source>Year</source>
        <translation>Jaar</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="254"/>
        <source>Track</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="255"/>
        <source>Disc number</source>
        <translation>CD nummer</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="273"/>
        <source>Duration</source>
        <translation>Duur</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="276"/>
        <source>Bitrate</source>
        <translation>Bitsnelheid</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="276"/>
        <source>kbps</source>
        <translation>kbps</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="277"/>
        <source>Sample rate</source>
        <translation>Sample frequentie</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="277"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="278"/>
        <source>Channels</source>
        <translation>Kanalen</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="279"/>
        <source>Sample size</source>
        <translation>Samplegrootte</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="279"/>
        <source>bits</source>
        <translation>bits</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="280"/>
        <source>Format name</source>
        <translation>Opmaak</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="281"/>
        <source>File size</source>
        <translation>Bestandsgrootte</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="281"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="325"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="325"/>
        <source>No</source>
        <translation>Nee</translation>
    </message>
</context>
<context>
    <name>JumpToTrackDialog</name>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="14"/>
        <source>Jump To Track</source>
        <translation>Ga Naar Nummer</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filter:</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="73"/>
        <location filename="../jumptotrackdialog.cpp" line="91"/>
        <location filename="../jumptotrackdialog.cpp" line="138"/>
        <source>Queue</source>
        <translation>Rij</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="89"/>
        <source>Refresh</source>
        <translation>Herlaad</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="105"/>
        <source>Jump To</source>
        <translation>Ga Naar</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="58"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="59"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="60"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="89"/>
        <location filename="../jumptotrackdialog.cpp" line="136"/>
        <source>Unqueue</source>
        <translation>Verwijderen uit wachtrij</translation>
    </message>
</context>
<context>
    <name>MetaDataFormatterMenu</name>
    <message>
        <location filename="../metadataformattermenu.cpp" line="26"/>
        <source>Artist</source>
        <translation>Artiest</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="27"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="28"/>
        <source>Album Artist</source>
        <translation>Album Artiest</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="31"/>
        <source>Title</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="32"/>
        <source>Track Number</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="33"/>
        <source>Two-digit Track Number</source>
        <translation>2 cijferige nummer</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="37"/>
        <source>Track Index</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="39"/>
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="40"/>
        <source>Comment</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="41"/>
        <source>Composer</source>
        <translation>Componist</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="46"/>
        <source>Duration</source>
        <translation>Duur</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="58"/>
        <source>Bitrate</source>
        <translation>Bitsnelheid</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="59"/>
        <source>Sample Rate</source>
        <translation>Samplesnelheid</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="60"/>
        <source>Number of Channels</source>
        <translation>Aantal kanalen</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="61"/>
        <source>Sample Size</source>
        <translation>Samplegrootte</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="62"/>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="63"/>
        <source>Decoder</source>
        <translation>Decoder</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="66"/>
        <source>File Size</source>
        <translation>Bestandsgrootte</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="42"/>
        <source>Disc Number</source>
        <translation>Schijf nummer</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="47"/>
        <source>File Name</source>
        <translation>Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="48"/>
        <source>File Path</source>
        <translation>Bestandspad</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="43"/>
        <source>Year</source>
        <translation>Jaar</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="50"/>
        <source>Condition</source>
        <translation>Staat</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="49"/>
        <source>Artist - Title</source>
        <translation>Artiest - Naam</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="54"/>
        <source>Artist - [Year] Album</source>
        <translation>Artiest - [Jaar] Album</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="56"/>
        <source>Parent Directory Name</source>
        <translation>Naam van bovenliggende map</translation>
    </message>
</context>
<context>
    <name>PlayListDownloader</name>
    <message>
        <location filename="../playlistdownloader.cpp" line="117"/>
        <source>Unsupported playlist format</source>
        <translation>Niet ondersteund playlist formaat</translation>
    </message>
</context>
<context>
    <name>PlayListHeaderModel</name>
    <message>
        <location filename="../playlistheadermodel.cpp" line="36"/>
        <source>Artist - Title</source>
        <translation>Artiest - Naam</translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="186"/>
        <source>Title</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="187"/>
        <source>Add Column</source>
        <translation>Kolom toevoegen</translation>
    </message>
</context>
<context>
    <name>PlayListManager</name>
    <message>
        <location filename="../playlistmanager.cpp" line="171"/>
        <location filename="../playlistmanager.cpp" line="316"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
</context>
<context>
    <name>PlayListTrack</name>
    <message>
        <location filename="../playlisttrack.cpp" line="249"/>
        <source>Streams</source>
        <translation>Streams</translation>
    </message>
    <message>
        <location filename="../playlisttrack.cpp" line="254"/>
        <source>Empty group</source>
        <translation>Lege groep</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../winfileassoc.cpp" line="278"/>
        <source>Enqueue in Qmmp</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QmmpUiSettings</name>
    <message>
        <location filename="../qmmpuisettings.cpp" line="57"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
</context>
<context>
    <name>QtFileDialogFactory</name>
    <message>
        <location filename="../qtfiledialog.cpp" line="34"/>
        <source>Qt File Dialog</source>
        <translation>Qt Bestandsdialoog</translation>
    </message>
</context>
<context>
    <name>TagEditor</name>
    <message>
        <location filename="../forms/tageditor.ui" line="14"/>
        <source>Tag Editor</source>
        <translation>Tag bewerker</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="38"/>
        <source>Title:</source>
        <translation>Naam:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="64"/>
        <source>Artist:</source>
        <translation>Artiest:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="90"/>
        <source>Album:</source>
        <translation>Album:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="113"/>
        <source>Album artist:</source>
        <translation>Album artiest:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="123"/>
        <source>Composer:</source>
        <translation>Componist:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="143"/>
        <source>Genre:</source>
        <translation>Genre:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="169"/>
        <source>Track:</source>
        <translation>Nummer:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="190"/>
        <location filename="../forms/tageditor.ui" line="228"/>
        <location filename="../forms/tageditor.ui" line="260"/>
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="203"/>
        <source>Year:</source>
        <translation>Jaar:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="250"/>
        <source>Disc number:</source>
        <translation>CD nummer:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="275"/>
        <source>Comment:</source>
        <translation>Commentaar:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="311"/>
        <source>Include selected tag in file</source>
        <translation>Voeg geselecteerde tag toe aan bestand</translation>
    </message>
</context>
<context>
    <name>TemplateEditor</name>
    <message>
        <location filename="../forms/templateeditor.ui" line="14"/>
        <source>Template Editor</source>
        <translation>Layout Bewerker</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="39"/>
        <source>Reset</source>
        <translation>Terugdraaien</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="46"/>
        <source>Insert</source>
        <translation>Invoegen</translation>
    </message>
</context>
<context>
    <name>UiHelper</name>
    <message>
        <location filename="../uihelper.cpp" line="124"/>
        <location filename="../uihelper.cpp" line="136"/>
        <source>All Supported Bitstreams</source>
        <translation>Alle Ondersteunde Bitstromen</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="130"/>
        <source>Select one or more files to open</source>
        <translation>Kies één of meerdere bestanden om te openen</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="142"/>
        <source>Select one or more files to play</source>
        <translation>Kies één of meer af te spelen bestanden</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="150"/>
        <source>Choose a directory</source>
        <translation>Kies een map</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="166"/>
        <location filename="../uihelper.cpp" line="190"/>
        <source>Playlist Files</source>
        <translation>Afspeellijst Bestanden</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="168"/>
        <source>Open Playlist</source>
        <translation>Open Afspeellijst</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="191"/>
        <source>Save Playlist</source>
        <translation>Bewaar Afspeellijst</translation>
    </message>
</context>
<context>
    <name>WinFileAssocPage</name>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="17"/>
        <source>Media files handled by Qmmp:</source>
        <translation>Media bestanden voor Qmmp:</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="49"/>
        <source>Select All</source>
        <translation>Alles selecteren</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="56"/>
        <source>Select None</source>
        <translation>Niks selecteren</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="136"/>
        <source>Warning</source>
        <translation>Waarschuwing</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="137"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Niet alle bestanden konden worden gelinkt. Controleer uw security rechten en probeer op nieuw.</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="144"/>
        <source>Check all file types in the list</source>
        <translation>Vink alle bestandstypes aan in de lijst</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="145"/>
        <source>Uncheck all file types in the list</source>
        <translation>Vink alle bestandstypes uit in de lijst</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="146"/>
        <source>Check the media file extensions you would like Qmmp to handle. When you click Apply, the checked files will be associated with Qmmp. If you uncheck a media type, the file association will be restored.</source>
        <translation>Vink de media types aan die je aan Qmmp wil linken. Als je &quot;Toepassen&quot; klikt, worden de aangevinkte bestanden geassocieerd met Qmmp. Als je een media type uitvinkt wordt de link teruggezet.</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="150"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Restoration doesn&apos;t work on Windows Vista/7.</source>
        <translation>&lt;b&gt;Opgelet:&lt;/b&gt; Terugzetten werkt niet op Windows Vista/7.</translation>
    </message>
</context>
</TS>
