<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="lt">
<context>
    <name>IncDecVolumeCommandLineOption</name>
    <message>
        <location filename="../incdecvolumeoption.cpp" line="29"/>
        <source>Increase volume by 5 steps</source>
        <translation>Pagarsinti 5 procentais</translation>
    </message>
    <message>
        <location filename="../incdecvolumeoption.cpp" line="30"/>
        <source>Decrease volume by 5 steps</source>
        <translation>Pritildyti 5 procentais</translation>
    </message>
</context>
</TS>
