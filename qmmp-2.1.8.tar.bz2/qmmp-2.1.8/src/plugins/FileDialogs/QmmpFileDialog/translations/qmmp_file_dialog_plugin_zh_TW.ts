<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>QmmpFileDialog</name>
    <message>
        <location filename="../qmmpfiledialog.ui" line="14"/>
        <source>Add Files</source>
        <translation>添加文件</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="198"/>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="201"/>
        <location filename="../qmmpfiledialog.ui" line="214"/>
        <location filename="../qmmpfiledialog.ui" line="233"/>
        <location filename="../qmmpfiledialog.ui" line="258"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="211"/>
        <source>List view</source>
        <translation>清單視圖</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="230"/>
        <source>Detailed view</source>
        <translation>詳細視圖</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="255"/>
        <source>Close dialog on add</source>
        <translation>關閉對話並打開已添加</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="124"/>
        <source>File name:</source>
        <translation>文件名：</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="140"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="147"/>
        <source>Files of type:</source>
        <translation>文件類型：</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="173"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
</context>
<context>
    <name>QmmpFileDialogFactory</name>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="70"/>
        <location filename="../qmmpfiledialog.cpp" line="80"/>
        <source>Qmmp File Dialog</source>
        <translation>Qmmp 檔案會話</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="79"/>
        <source>About Qmmp File Dialog</source>
        <translation>關於 Qmmp 檔案會話</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="81"/>
        <source>Written by:
Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;
Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>作者：
Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;
Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="84"/>
        <source>Some code is copied from the Qt library</source>
        <translation>一些源碼基於 Qt 程式庫</translation>
    </message>
</context>
<context>
    <name>QmmpFileDialogImpl</name>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="261"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="274"/>
        <source>Save</source>
        <translation>儲存</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="288"/>
        <source>Directories</source>
        <translation>目錄</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="474"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>％1早已存在。
你想要替換它嗎？</translation>
    </message>
</context>
</TS>
