/***************************************************************************
 *   Copyright (C) 2011-2025 by Ilya Kotov                                 *
 *   forkotov02@ya.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.         *
 ***************************************************************************/

#ifndef SKINNEDHOTKEYEDITOR_H
#define SKINNEDHOTKEYEDITOR_H

#include <QWidget>

namespace Ui {
    class SkinnedHotkeyEditor;
}

/**
    @author Ilya Kotov <forkotov02@ya.ru>
*/
class SkinnedHotkeyEditor : public QWidget
{
    Q_OBJECT

public:
    explicit SkinnedHotkeyEditor(QWidget *parent = nullptr);
    virtual ~SkinnedHotkeyEditor();

private slots:
    void on_changeShortcutButton_clicked();
    void on_resetShortcutsButton_clicked();

private:
    void loadShortcuts();
    Ui::SkinnedHotkeyEditor *m_ui;
};

#endif // SKINNEDHOTKEYEDITOR_H
