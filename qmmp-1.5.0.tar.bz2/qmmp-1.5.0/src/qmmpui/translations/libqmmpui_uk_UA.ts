<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk_UA">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About Qmmp</source>
        <translation>Про Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="49"/>
        <source>About</source>
        <translation>Про програму</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="63"/>
        <source>Authors</source>
        <translation>Автори</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="77"/>
        <source>Translators</source>
        <translation>Перекладачі</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="91"/>
        <source>Thanks To</source>
        <translation>Подяки</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="105"/>
        <source>License Agreement</source>
        <translation>Ліцензія</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="63"/>
        <source>Qt-based Multimedia Player (Qmmp)</source>
        <translation>Мультимедійний програвач на базі Qt (Qmmp)</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="67"/>
        <source>Version: %1</source>
        <translation>Версія: %1</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="68"/>
        <source>Using Qt %1 (compiled with Qt %2)</source>
        <translation>Використовується Qt %1 (зібрано з Qt %2)</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="71"/>
        <source>(c) %1-%2 Qmmp Development Team</source>
        <translation>(c) %1-%2 Команда розробників Qmmp</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="76"/>
        <source>Input plugins:</source>
        <translation>Модулі введення:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="85"/>
        <source>Output plugins:</source>
        <translation>Модулі виведення:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="94"/>
        <source>Visual plugins:</source>
        <translation>Модулі візуалізації:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="103"/>
        <source>Effect plugins:</source>
        <translation>Модулі ефектів:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="112"/>
        <source>General plugins:</source>
        <translation>Загальні модулі:</translation>
    </message>
</context>
<context>
    <name>AddUrlDialog</name>
    <message>
        <location filename="../forms/addurldialog.ui" line="14"/>
        <source>Enter URL to add</source>
        <translation>Введіть адресу для додавання</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="46"/>
        <source>&amp;Add</source>
        <translation>&amp;Додати</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="53"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Відміна</translation>
    </message>
    <message>
        <location filename="../addurldialog.cpp" line="88"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
</context>
<context>
    <name>ColumnEditor</name>
    <message>
        <location filename="../forms/columneditor.ui" line="14"/>
        <source>Edit Column</source>
        <translation>Редагувати стовпчик</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="36"/>
        <source>Name:</source>
        <translation>Ім&apos;я:</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="76"/>
        <source>Format:</source>
        <translation>Формат:</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="64"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="29"/>
        <source>Type:</source>
        <translation>Тип:</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="85"/>
        <source>Artist</source>
        <translation>Виконавець</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="86"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="90"/>
        <source>Title</source>
        <translation>Заголовок</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="93"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="94"/>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="95"/>
        <source>Composer</source>
        <translation>Композитор</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="96"/>
        <source>Duration</source>
        <translation>Тривалість</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="101"/>
        <source>Year</source>
        <translation>Рік</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="100"/>
        <source>Track Index</source>
        <translation>Індекс трека</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="87"/>
        <source>Artist - Album</source>
        <translation>Виконавець - Альбом</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="88"/>
        <source>Artist - Title</source>
        <translation>Виконавець - Назва</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="89"/>
        <source>Album Artist</source>
        <translation>Альбом Виконавець</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="91"/>
        <source>Track Number</source>
        <translation>Номер трека</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="92"/>
        <source>Two-digit Track Number</source>
        <translation>Подвійний номер трека</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="97"/>
        <source>Disc Number</source>
        <translation>Номер диску</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="98"/>
        <source>File Name</source>
        <translation>Ім&apos;я файлу</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="99"/>
        <source>File Path</source>
        <translation>Ім&apos;я файлу</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="102"/>
        <source>Parent Directory Name</source>
        <translation type="unfinished">Ім&apos;я батьківської теки</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="103"/>
        <source>Parent Directory Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="104"/>
        <source>Custom</source>
        <translation>Власний</translation>
    </message>
</context>
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../forms/configdialog.ui" line="14"/>
        <source>Qmmp Settings</source>
        <translation>Налаштування Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="58"/>
        <source>Playlist</source>
        <translation>Список</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="67"/>
        <source>Plugins</source>
        <translation>Модулі</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="76"/>
        <source>Advanced</source>
        <translation>Додатково</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="85"/>
        <source>Connectivity</source>
        <translation>Мережа</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="94"/>
        <location filename="../forms/configdialog.ui" line="847"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="123"/>
        <source>Metadata</source>
        <translation>Метадані</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="143"/>
        <source>Convert %20 to blanks</source>
        <translation>Конвертувати %20 в пробіл</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="129"/>
        <source>Load metadata from files</source>
        <translation>Зчитувати метадані з файлів</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="136"/>
        <source>Convert underscores to blanks</source>
        <translation>Конвертувати підкреслювання в пробіл</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="150"/>
        <source>Group format:</source>
        <translation>Формат групування:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="160"/>
        <location filename="../forms/configdialog.ui" line="576"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="170"/>
        <source>Read tags while loading a playlist</source>
        <translation>Читати теги при завантаженні списка</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="180"/>
        <source>Directory Scanning Options</source>
        <translation>Опції сканування тек</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="186"/>
        <source>Restrict files to:</source>
        <translation>Обмежити вибір файлів до:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="196"/>
        <location filename="../forms/configdialog.ui" line="454"/>
        <source>Exclude files:</source>
        <translation>Виключити файли:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="209"/>
        <source>Miscellaneous</source>
        <translation>Різне</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="215"/>
        <source>Auto-save playlist when modified</source>
        <translation>Автозбереження переліку після зміни</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="222"/>
        <source>Clear previous playlist when opening new one</source>
        <translation>Очищати попередній список при відкритті нового</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="270"/>
        <location filename="../configdialog.cpp" line="327"/>
        <source>Preferences</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="283"/>
        <location filename="../configdialog.cpp" line="330"/>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="325"/>
        <source>Description</source>
        <translation>Пояснення</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="330"/>
        <source>Filename</source>
        <translation>Ім&apos;я файлу</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="342"/>
        <source>Look and Feel</source>
        <translation>Параметри інтерфейсу</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="348"/>
        <source>Language:</source>
        <translation>Мова:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="381"/>
        <source>Display average bitrate</source>
        <translation>Відображати середній бітрейт</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="391"/>
        <source>Playback</source>
        <translation>Відтворення</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="397"/>
        <source>Continue playback on startup</source>
        <translation>Продовжити відтворення при запуску</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="404"/>
        <source>Determine file type by content</source>
        <translation>Визначати тип файлу за вмістом</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="411"/>
        <source>Add files from command line to this playlist:</source>
        <translation>Додавати файли з командного рядка в цей список:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="428"/>
        <source>Cover Image Retrieve</source>
        <translation>Пошук обладинки альбома</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="434"/>
        <source>Use separate image files</source>
        <translation>Використовувати окремі файли зображень</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="444"/>
        <source>Include files:</source>
        <translation>Включити файли:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="466"/>
        <source>Recursive search depth:</source>
        <translation>Глибина рекурсивного пошуку:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="498"/>
        <source>URL Dialog</source>
        <translation>URL-діалог</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="504"/>
        <source>Auto-paste URL from clipboard</source>
        <translation>Автоматично додавати URL з буферу обміну</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="514"/>
        <source>CUE Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="520"/>
        <source>Use system font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="541"/>
        <source>Font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="566"/>
        <source>???</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="605"/>
        <source>Proxy</source>
        <translation>Проксі</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="617"/>
        <source>Enable proxy usage</source>
        <translation>Використосувати проксі</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="624"/>
        <source>Proxy type:</source>
        <translation>Тип проксі:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="634"/>
        <source>Proxy host name:</source>
        <translation>Сервер проксі:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="647"/>
        <source>Proxy port:</source>
        <translation>Порт проксі:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="660"/>
        <source>Use authentication with proxy</source>
        <translation>Використовувати авторизацію на проксі</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="667"/>
        <source>Proxy user name:</source>
        <translation>Ім&apos;я користвача проксі:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="680"/>
        <source>Proxy password:</source>
        <translation>Пароль проксі:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="717"/>
        <source>Replay Gain</source>
        <translation>Нормалізація гучності</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="723"/>
        <source>Replay Gain mode:</source>
        <translation>Режим нормалізації гучності:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="740"/>
        <source>Preamp:</source>
        <translation>Преамплітуда:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="772"/>
        <location filename="../forms/configdialog.ui" line="817"/>
        <source>dB</source>
        <translation>дБ</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="785"/>
        <source>Default gain:</source>
        <translation>Нормалізація за умовчанням:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="837"/>
        <source>Use  peak info to prevent clipping</source>
        <translation>Використовувати інформацію піків для запобігання відсікання</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="853"/>
        <source>Buffer size:</source>
        <translation>Розмір буферу:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="879"/>
        <source>ms</source>
        <translation>мс</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="912"/>
        <source>Use software volume control</source>
        <translation>Використовувати програмний контроль гучності</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="952"/>
        <source>Use two passes for equalizer</source>
        <translation>Два прохода для еквалайзера</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="895"/>
        <source>Volume adjustment step:</source>
        <translation>Крок регулювання гучності:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="919"/>
        <source>Output bit depth:</source>
        <translation>Розрядність виведення:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="860"/>
        <source>Use dithering</source>
        <translation>Використовувати згладжування</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="63"/>
        <source>Track</source>
        <translation>Трек</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="64"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="65"/>
        <source>Disabled</source>
        <translation>Вимкнено</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="72"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="73"/>
        <source>SOCKS5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="86"/>
        <source>File Types</source>
        <translation>Типи файлів</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="202"/>
        <source>Transports</source>
        <translation>Транспорти</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="213"/>
        <source>Decoders</source>
        <translation>Декодери</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="224"/>
        <source>Engines</source>
        <translation>Зовнішні програвачі</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="235"/>
        <source>Effects</source>
        <translation>Ефекти</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="246"/>
        <source>Visualization</source>
        <translation>Візуалізація</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="257"/>
        <source>General</source>
        <translation>Загальне</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="268"/>
        <source>Output</source>
        <translation>Вивід</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="279"/>
        <source>File Dialogs</source>
        <translation>Файлові діалоги</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="290"/>
        <source>User Interfaces</source>
        <translation>Інтерфейси користувача</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="340"/>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Автоматично&gt;</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="341"/>
        <source>Brazilian Portuguese</source>
        <translation>Бразильська португальська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="342"/>
        <source>Chinese Simplified</source>
        <translation>Китайська спрощена</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="343"/>
        <source>Chinese Traditional</source>
        <translation>Китайська традиційна</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="344"/>
        <source>Czech</source>
        <translation>Чеська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="345"/>
        <source>Dutch</source>
        <translation>Голландська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="346"/>
        <source>English</source>
        <translation>Англійська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="347"/>
        <source>French</source>
        <translation>Французька</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="348"/>
        <source>Galician</source>
        <translation>Галісійська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="349"/>
        <source>German</source>
        <translation>Німецька</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="350"/>
        <source>Greek</source>
        <translation>Грецька</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="351"/>
        <source>Hebrew</source>
        <translation>Іврит</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="352"/>
        <source>Hungarian</source>
        <translation>Угорська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="353"/>
        <source>Indonesian</source>
        <translation>Індонезійська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="354"/>
        <source>Italian</source>
        <translation>Італійська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="355"/>
        <source>Japanese</source>
        <translation>Японська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="356"/>
        <source>Kazakh</source>
        <translation>Казахська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="357"/>
        <source>Lithuanian</source>
        <translation>Литовська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="358"/>
        <source>Polish</source>
        <translation>Польська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="359"/>
        <source>Portuguese</source>
        <translation>Португальська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="360"/>
        <source>Russian</source>
        <translation>Російська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="361"/>
        <source>Serbian</source>
        <translation>Сербська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="362"/>
        <source>Slovak</source>
        <translation>Словацька</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="363"/>
        <source>Spanish</source>
        <translation>Іспанська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="364"/>
        <source>Turkish</source>
        <translation>Турецька</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="365"/>
        <source>Ukrainian</source>
        <translation>Українська</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="366"/>
        <source>Serbian (Ijekavian)</source>
        <translation>Сербська (ієкавська)</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="367"/>
        <source>Serbian (Ekavian)</source>
        <translation>Сербська (екавська)</translation>
    </message>
</context>
<context>
    <name>CoverEditor</name>
    <message>
        <location filename="../forms/covereditor.ui" line="22"/>
        <source>Image source:</source>
        <translation>Джерело зображення:</translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="76"/>
        <source>Load</source>
        <translation>Завантажити</translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="83"/>
        <source>Delete</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="90"/>
        <source>Save as...</source>
        <translation>Зберегти як...</translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="33"/>
        <source>External file</source>
        <translation>Зовнішній файл</translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="34"/>
        <source>Tag</source>
        <translation>Тег</translation>
    </message>
</context>
<context>
    <name>CoverViewer</name>
    <message>
        <location filename="../coverviewer.cpp" line="35"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Зберегти як...</translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="68"/>
        <source>Save Cover As</source>
        <translation>Зберегти обкладинку як</translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="70"/>
        <location filename="../coverviewer.cpp" line="83"/>
        <source>Images</source>
        <translation>Зображення</translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="81"/>
        <source>Open Image</source>
        <translation>Відкрити зображення</translation>
    </message>
</context>
<context>
    <name>CueEditor</name>
    <message>
        <location filename="../forms/cueeditor.ui" line="40"/>
        <source>Load</source>
        <translation type="unfinished">Завантажити</translation>
    </message>
    <message>
        <location filename="../forms/cueeditor.ui" line="47"/>
        <source>Delete</source>
        <translation type="unfinished">Видалити</translation>
    </message>
    <message>
        <location filename="../forms/cueeditor.ui" line="54"/>
        <source>Save as...</source>
        <translation type="unfinished">Зберегти як...</translation>
    </message>
    <message>
        <location filename="../cueeditor.cpp" line="131"/>
        <source>Open CUE File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cueeditor.cpp" line="133"/>
        <location filename="../cueeditor.cpp" line="152"/>
        <source>CUE Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cueeditor.cpp" line="150"/>
        <source>Save CUE File</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DetailsDialog</name>
    <message>
        <location filename="../forms/detailsdialog.ui" line="14"/>
        <source>Details</source>
        <translation>Подробиці</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="44"/>
        <source>Open the directory containing this file</source>
        <translation>Відкрити теку, яка містить цей файл</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="47"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="63"/>
        <source>Summary</source>
        <translation>Підсумок</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="203"/>
        <source>%1/%2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="255"/>
        <source>Cover</source>
        <translation>Обкладинка</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="292"/>
        <source>Title</source>
        <translation>Заголовок</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="293"/>
        <source>Artist</source>
        <translation>Виконавець</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="294"/>
        <source>Album artist</source>
        <translation>Альбом виконавця</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="295"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="296"/>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="297"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="298"/>
        <source>Composer</source>
        <translation>Композитор</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="299"/>
        <source>Year</source>
        <translation>Рік</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="300"/>
        <source>Track</source>
        <translation>Доріжка</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="301"/>
        <source>Disc number</source>
        <translation>Номер диску</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="319"/>
        <source>Duration</source>
        <translation>Тривалість</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="322"/>
        <source>Bitrate</source>
        <translation>Бітрейт</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="322"/>
        <source>kbps</source>
        <translation>кб/с</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="323"/>
        <source>Sample rate</source>
        <translation>Частота дискретизації</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="323"/>
        <source>Hz</source>
        <translation>Гц</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="324"/>
        <source>Channels</source>
        <translation>Канали</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="325"/>
        <source>Sample size</source>
        <translation>Розмір семпла</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="325"/>
        <source>bits</source>
        <translation>біт</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="326"/>
        <source>Format name</source>
        <translation>Назва формату</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="327"/>
        <source>File size</source>
        <translation>Розмір файла</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="327"/>
        <source>KiB</source>
        <translation>КіБ</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="371"/>
        <source>Yes</source>
        <translation>Так</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="371"/>
        <source>No</source>
        <translation>Ні</translation>
    </message>
</context>
<context>
    <name>JumpToTrackDialog</name>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="14"/>
        <source>Jump To Track</source>
        <translation>Перейти до треку</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="46"/>
        <source>Filter:</source>
        <translation>Фільтр:</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="85"/>
        <location filename="../jumptotrackdialog.cpp" line="90"/>
        <location filename="../jumptotrackdialog.cpp" line="151"/>
        <source>Queue</source>
        <translation>В чергу</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="101"/>
        <source>Refresh</source>
        <translation>Поновити</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="117"/>
        <source>Jump To</source>
        <translation>Перейти до</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="57"/>
        <source>Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="58"/>
        <source>J</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="59"/>
        <source>F5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="88"/>
        <location filename="../jumptotrackdialog.cpp" line="149"/>
        <source>Unqueue</source>
        <translation>Видалити з черги</translation>
    </message>
</context>
<context>
    <name>MetaDataFormatterMenu</name>
    <message>
        <location filename="../metadataformattermenu.cpp" line="26"/>
        <source>Artist</source>
        <translation>Виконавець</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="27"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="28"/>
        <source>Album Artist</source>
        <translation>Альбом Виконавець</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="31"/>
        <source>Title</source>
        <translation>Назва</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="32"/>
        <source>Track Number</source>
        <translation>Номер трека</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="33"/>
        <source>Two-digit Track Number</source>
        <translation>Подвійний номер трека</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="37"/>
        <source>Track Index</source>
        <translation>Індекс трека</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="39"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="40"/>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="41"/>
        <source>Composer</source>
        <translation>Композитор</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="46"/>
        <source>Duration</source>
        <translation>Тривалість</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="57"/>
        <source>Parent Directory Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="59"/>
        <source>Bitrate</source>
        <translation>Бітрейт</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="60"/>
        <source>Sample Rate</source>
        <translation>Частота дискретизації</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="61"/>
        <source>Number of Channels</source>
        <translation>Кількість каналів</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="62"/>
        <source>Sample Size</source>
        <translation>Розмір семпла</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="63"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="64"/>
        <source>Decoder</source>
        <translation>Декодер</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="67"/>
        <source>File Size</source>
        <translation>Розмір файла</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="42"/>
        <source>Disc Number</source>
        <translation>Номер диску</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="47"/>
        <source>File Name</source>
        <translation>Ім&apos;я файлу</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="48"/>
        <source>File Path</source>
        <translation>Ім&apos;я файлу</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="43"/>
        <source>Year</source>
        <translation>Рік</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="50"/>
        <source>Condition</source>
        <translation>Умова</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="49"/>
        <source>Artist - Title</source>
        <translation>Виконавець - Назва</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="54"/>
        <source>Artist - [Year] Album</source>
        <translation>Виконавець - [Рік] Альбом</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="56"/>
        <source>Parent Directory Name</source>
        <translation>Ім&apos;я батьківської теки</translation>
    </message>
</context>
<context>
    <name>PlayListDownloader</name>
    <message>
        <location filename="../playlistdownloader.cpp" line="123"/>
        <source>Unsupported playlist format</source>
        <translation>Формат списку не підтримується</translation>
    </message>
</context>
<context>
    <name>PlayListHeaderModel</name>
    <message>
        <location filename="../playlistheadermodel.cpp" line="35"/>
        <source>Artist - Title</source>
        <translation>Виконавець - Назва</translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="185"/>
        <source>Title</source>
        <translation>Назва</translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="186"/>
        <source>Add Column</source>
        <translation>Додати стовпчик</translation>
    </message>
</context>
<context>
    <name>PlayListManager</name>
    <message>
        <location filename="../playlistmanager.cpp" line="181"/>
        <location filename="../playlistmanager.cpp" line="327"/>
        <source>Playlist</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>PlayListTrack</name>
    <message>
        <location filename="../playlisttrack.cpp" line="240"/>
        <source>Streams</source>
        <translation>Онлайн-потоки</translation>
    </message>
    <message>
        <location filename="../playlisttrack.cpp" line="245"/>
        <source>Empty group</source>
        <translation>Пуста група</translation>
    </message>
</context>
<context>
    <name>QmmpUiSettings</name>
    <message>
        <location filename="../qmmpuisettings.cpp" line="58"/>
        <source>Playlist</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>QtFileDialogFactory</name>
    <message>
        <location filename="../qtfiledialog.cpp" line="35"/>
        <source>Qt File Dialog</source>
        <translation>Файловий діалог Qt</translation>
    </message>
</context>
<context>
    <name>TagEditor</name>
    <message>
        <location filename="../forms/tageditor.ui" line="14"/>
        <source>Tag Editor</source>
        <translation>Редактор тегів</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="38"/>
        <source>Title:</source>
        <translation>Заголовок:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="64"/>
        <source>Artist:</source>
        <translation>Виконавець:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="90"/>
        <source>Album:</source>
        <translation>Альбом:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="113"/>
        <source>Album artist:</source>
        <translation>Альбом виконавця:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="123"/>
        <source>Composer:</source>
        <translation>Композитор:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="143"/>
        <source>Genre:</source>
        <translation>Жанр:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="169"/>
        <source>Track:</source>
        <translation>Доріжка:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="190"/>
        <location filename="../forms/tageditor.ui" line="228"/>
        <location filename="../forms/tageditor.ui" line="260"/>
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="203"/>
        <source>Year:</source>
        <translation>Рік:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="250"/>
        <source>Disc number:</source>
        <translation>Номер диску:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="275"/>
        <source>Comment:</source>
        <translation>Коментар:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="311"/>
        <source>Include selected tag in file</source>
        <translation>Включити вибраний тег у файл</translation>
    </message>
</context>
<context>
    <name>TemplateEditor</name>
    <message>
        <location filename="../forms/templateeditor.ui" line="14"/>
        <source>Template Editor</source>
        <translation>Редактор шаблонів</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="39"/>
        <source>Reset</source>
        <translation>Скинути</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="46"/>
        <source>Insert</source>
        <translation>Вставити</translation>
    </message>
</context>
<context>
    <name>UiHelper</name>
    <message>
        <location filename="../uihelper.cpp" line="138"/>
        <location filename="../uihelper.cpp" line="150"/>
        <source>All Supported Bitstreams</source>
        <translation>Усі формати</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="144"/>
        <source>Select one or more files to open</source>
        <translation>Виберіть один чи декілька файлів для відкриття</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="156"/>
        <source>Select one or more files to play</source>
        <translation>Виберіть один чи декілька файлів для відтвореня</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="164"/>
        <source>Choose a directory</source>
        <translation>Виберіть теку</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="180"/>
        <location filename="../uihelper.cpp" line="206"/>
        <source>Playlist Files</source>
        <translation>Файли списків</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="182"/>
        <source>Open Playlist</source>
        <translation>Відкрити список</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="209"/>
        <location filename="../uihelper.cpp" line="228"/>
        <source>Save Playlist</source>
        <translation>Зберегти список</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="228"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 вже існує.
Бажаєте замінити?</translation>
    </message>
</context>
<context>
    <name>WinFileAssocPage</name>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="17"/>
        <source>Media files handled by Qmmp:</source>
        <translation>Медіа-файли, асоційовані з Qmmp:</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="49"/>
        <source>Select All</source>
        <translation>Виділити все</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="56"/>
        <source>Select None</source>
        <translation>Нічого не вибирати</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="125"/>
        <source>Warning</source>
        <translation>Попередження</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="126"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Не всі файли можуть бути асоційованими. Перевірте свої права та спробуйте знову.</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="133"/>
        <source>Check all file types in the list</source>
        <translation>Перевірити всі типи файлів у списку</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="134"/>
        <source>Uncheck all file types in the list</source>
        <translation>Нічого не вибирати в списку</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="135"/>
        <source>Check the media file extensions you would like Qmmp to handle. When you click Apply, the checked files will be associated with Qmmp. If you uncheck a media type, the file association will be restored.</source>
        <translation>Вкажіть типи файлів, яки Ви бажаєте асоціювати з Qmmp. Після застосування вибрані типи файлів будуть асоційовані з Qmmp. Якщо зняти відмтку - файлова асоціація буде відновлена.</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="139"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Restoration doesn&apos;t work on Windows Vista/7.</source>
        <translation>&lt;b&gt;Примітка:&lt;/b&gt; Відновлення асоціацій не працює в Windows Vista/7.</translation>
    </message>
</context>
</TS>
