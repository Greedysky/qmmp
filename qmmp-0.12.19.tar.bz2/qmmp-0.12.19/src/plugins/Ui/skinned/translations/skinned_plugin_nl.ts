<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nl">
<context>
    <name>ActionManager</name>
    <message>
        <location filename="../actionmanager.cpp" line="38"/>
        <source>&amp;Play</source>
        <translation>&amp;Afspelen</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="38"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="39"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pauze</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="39"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="40"/>
        <source>&amp;Stop</source>
        <translation>&amp;Stoppen</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="40"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="41"/>
        <source>&amp;Previous</source>
        <translation>&amp;Vorige</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="41"/>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="42"/>
        <source>&amp;Next</source>
        <translation>&amp;Volgende</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="42"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>&amp;Play/Pause</source>
        <translation>&amp;Afspelen/Pauze</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>Space</source>
        <translation>Spatie</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>&amp;Jump to Track</source>
        <translation>&amp;Ga naar Nummer</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>&amp;Repeat Playlist</source>
        <translation>&amp;Herhaal Afspeellijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>&amp;Repeat Track</source>
        <translation>&amp;Herhaal Nummer</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;Willekeurig</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>&amp;No Playlist Advance</source>
        <translation>&amp;Niet verderschuiven in afspeellijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>&amp;Stop After Selected</source>
        <translation>&amp;Stop na geselecteerde</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="51"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>&amp;Clear Queue</source>
        <translation>&amp;Leeg Rij</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>Show Playlist</source>
        <translation>Toon Afspeellijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Show Equalizer</source>
        <translation>Toon Equalizer</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Alt+G</source>
        <translation>Alt+G</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="56"/>
        <source>Always on Top</source>
        <translation>Altijd bovenaan</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>Put on All Workspaces</source>
        <translation>Plaats op alle werkbladen</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Double Size</source>
        <translation>Dubbele grootte</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Meta+D</source>
        <translation>Meta+D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="59"/>
        <source>Anti-aliasing</source>
        <translation>Anit-kartelvorming</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="63"/>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="63"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="64"/>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="64"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="65"/>
        <source>&amp;Mute</source>
        <translation>De&amp;mpen</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="65"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>&amp;Add File</source>
        <translation>&amp;Voeg Bestand Toe</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>&amp;Add Directory</source>
        <translation>&amp;Voeg Map toe</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="69"/>
        <source>&amp;Add Url</source>
        <translation>&amp;Voeg URL toe</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="69"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="70"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Verwijder Geselecteerde</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>&amp;Remove All</source>
        <translation>&amp;Verwijder Alles</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>&amp;Remove Unselected</source>
        <translation>&amp;Verwijder Gedeselecteerde</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>Remove unavailable files</source>
        <translation>Verwijder afwezige bestanden</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>Remove duplicates</source>
        <translation>Verwijder duplicaten</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>Refresh</source>
        <translation>Herlaad</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>&amp;Queue Toggle</source>
        <translation>&amp;Rij schakelaar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="80"/>
        <source>Invert Selection</source>
        <translation>Draai Selectie Om</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="81"/>
        <source>&amp;Select None</source>
        <translation>&amp;Selecteer Niets</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="82"/>
        <source>&amp;Select All</source>
        <translation>&amp;Selecteer Alles</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="83"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>&amp;View Track Details</source>
        <translation>&amp;Bekijk Nummerdetails</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>&amp;New List</source>
        <translation>&amp;Nieuwe Lijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>&amp;Delete List</source>
        <translation>&amp;Verwijder Lijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>&amp;Load List</source>
        <translation>&amp;Laad Lijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>&amp;Save List</source>
        <translation>&amp;Bewaar Lijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>Shift+S</source>
        <translation>Shift+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>&amp;Rename List</source>
        <translation>&amp;Hernoem Lijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>&amp;Select Next Playlist</source>
        <translation>&amp;Selecteer Volgende Afspeellijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+PgDown</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>&amp;Select Previous Playlist</source>
        <translation>&amp;Selecteer Vorige Afspeellijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+PgUp</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>&amp;Show Playlists</source>
        <translation>&amp;Toon Afspeellijst</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>&amp;Group Tracks</source>
        <translation>Nummers &amp;groeperen</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="98"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="98"/>
        <source>&amp;Show Column Headers</source>
        <translation>Kolomtitel&amp;s tonen</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>&amp;Settings</source>
        <translation>&amp;Instellingen</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="101"/>
        <source>&amp;About</source>
        <translation>&amp;Over</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="102"/>
        <source>&amp;About Qt</source>
        <translation>&amp;Over Qt</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="103"/>
        <source>&amp;Exit</source>
        <translation>&amp;Sluit</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="103"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
</context>
<context>
    <name>EqWidget</name>
    <message>
        <location filename="../eqwidget.cpp" line="46"/>
        <source>Equalizer</source>
        <translation>Equalizer</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="164"/>
        <location filename="../eqwidget.cpp" line="181"/>
        <source>preset</source>
        <translation>Profiel</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="265"/>
        <source>&amp;Load/Delete</source>
        <translation>&amp;Laad/Verwijder</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="267"/>
        <source>&amp;Save Preset</source>
        <translation>&amp;Bewaar Profiel</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="269"/>
        <source>&amp;Save Auto-load Preset</source>
        <translation>&amp;Bewaar Auto-laad Profiel</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="271"/>
        <source>&amp;Import</source>
        <translation>&amp;Importeer</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="274"/>
        <source>&amp;Clear</source>
        <translation>&amp;Leeghalen</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="303"/>
        <source>Saving Preset</source>
        <translation>Bewaren van Profiel</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="304"/>
        <source>Preset name:</source>
        <translation>Profielnaam:</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="305"/>
        <source>preset #</source>
        <translation>Profiel #</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="396"/>
        <source>Import Preset</source>
        <translation>Importeer Profiel</translation>
    </message>
</context>
<context>
    <name>HotkeyEditor</name>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="40"/>
        <source>Reset</source>
        <translation>Terugzetten</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="54"/>
        <source>Action</source>
        <translation>Actie</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="59"/>
        <source>Shortcut</source>
        <translation>Sneltoets</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="33"/>
        <source>Change shortcut...</source>
        <translation>Verander sneltoets...</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="58"/>
        <source>Playback</source>
        <translation>Afspelen</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="64"/>
        <source>View</source>
        <translation>Toon</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="70"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="76"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="82"/>
        <source>Misc</source>
        <translation>Overige</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="94"/>
        <source>Reset Shortcuts</source>
        <translation>Sneltoetsen herstellen</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="95"/>
        <source>Do you want to restore default shortcuts?</source>
        <translation>Wil je de standaard sneltoetsen herstellen?</translation>
    </message>
</context>
<context>
    <name>MainDisplay</name>
    <message>
        <location filename="../display.cpp" line="60"/>
        <source>Previous</source>
        <translation>Vorige</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="64"/>
        <source>Play</source>
        <translation>Afspelen</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="67"/>
        <source>Pause</source>
        <translation>Pauze</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="70"/>
        <source>Stop</source>
        <translation>Stoppen</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="73"/>
        <source>Next</source>
        <translation>Volgende</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="76"/>
        <source>Play files</source>
        <translation>Bestanden afspelen</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="83"/>
        <source>Equalizer</source>
        <translation>Equalizer</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="86"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="91"/>
        <source>Repeat playlist</source>
        <translation>Herhaal afspeellijst</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="94"/>
        <source>Shuffle</source>
        <translation>Willekeurig</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="104"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="110"/>
        <source>Balance</source>
        <translation>Balans</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="296"/>
        <source>Volume: %1%</source>
        <translation>Volume: %1%</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="300"/>
        <source>Balance: %1% right</source>
        <translation>Balans: %1% rechts</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="302"/>
        <source>Balance: %1% left</source>
        <translation>Balans: %1 links</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="304"/>
        <source>Balance: center</source>
        <translation>Balans: midden</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="310"/>
        <source>Seek to: %1</source>
        <translation>Spoel naar: %1</translation>
    </message>
</context>
<context>
    <name>MainVisual</name>
    <message>
        <location filename="../mainvisual.cpp" line="213"/>
        <source>Visualization Mode</source>
        <translation>Visualisatiestand</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="216"/>
        <source>Analyzer</source>
        <translation>Analysator</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="217"/>
        <source>Scope</source>
        <translation>Bereik</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="218"/>
        <source>Off</source>
        <translation>Uit</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="225"/>
        <source>Analyzer Mode</source>
        <translation>Analysatorstand</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="228"/>
        <source>Normal</source>
        <translation>Normaal</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="229"/>
        <source>Fire</source>
        <translation>Vuur</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="230"/>
        <source>Vertical Lines</source>
        <translation>Verticale Lijnen</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="231"/>
        <source>Lines</source>
        <translation>Lijnen</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="232"/>
        <source>Bars</source>
        <translation>Strepen</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="245"/>
        <source>Peaks</source>
        <translation>Toppen</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="249"/>
        <source>Refresh Rate</source>
        <translation>Vernieuw Frequentie</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="252"/>
        <source>50 fps</source>
        <translation>50 fps</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="253"/>
        <source>25 fps</source>
        <translation>25 fps</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="254"/>
        <source>10 fps</source>
        <translation>10 fps</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="255"/>
        <source>5 fps</source>
        <translation>5 fps</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="262"/>
        <source>Analyzer Falloff</source>
        <translation>Analysator Uitval</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="265"/>
        <location filename="../mainvisual.cpp" line="279"/>
        <source>Slowest</source>
        <translation>Traagst</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="266"/>
        <location filename="../mainvisual.cpp" line="280"/>
        <source>Slow</source>
        <translation>Traag</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="267"/>
        <location filename="../mainvisual.cpp" line="281"/>
        <source>Medium</source>
        <translation>Normaal</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="268"/>
        <location filename="../mainvisual.cpp" line="282"/>
        <source>Fast</source>
        <translation>Snel</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="269"/>
        <location filename="../mainvisual.cpp" line="283"/>
        <source>Fastest</source>
        <translation>Snelst</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="276"/>
        <source>Peaks Falloff</source>
        <translation>Toppen Uitval</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="289"/>
        <source>Background</source>
        <translation>Achtergrond</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="290"/>
        <source>Transparent</source>
        <translation>Transparant</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="351"/>
        <source>Appearance</source>
        <translation>Vertoning</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="352"/>
        <source>Shortcuts</source>
        <translation>Sneltoetsen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="422"/>
        <source>View</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="431"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="449"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="457"/>
        <source>Tools</source>
        <translation>Gereedschappen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="539"/>
        <source>Qmmp</source>
        <translation>Qmmp</translation>
    </message>
</context>
<context>
    <name>PlayList</name>
    <message>
        <location filename="../playlist.cpp" line="56"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="200"/>
        <source>&amp;Copy Selection To</source>
        <translation>&amp;Kopiëer Selectie Naar</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="231"/>
        <source>Sort List</source>
        <translation>Sorteer Lijst</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="234"/>
        <location filename="../playlist.cpp" line="289"/>
        <source>By Title</source>
        <translation>Op Titel</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="238"/>
        <location filename="../playlist.cpp" line="293"/>
        <source>By Album</source>
        <translation>Op Album</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="242"/>
        <location filename="../playlist.cpp" line="297"/>
        <source>By Disc Number</source>
        <translation>Op CD nummer</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="246"/>
        <location filename="../playlist.cpp" line="301"/>
        <source>By Artist</source>
        <translation>Op Artiest</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="250"/>
        <location filename="../playlist.cpp" line="305"/>
        <source>By Album Artist</source>
        <translation>Op albumartiest</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="254"/>
        <location filename="../playlist.cpp" line="309"/>
        <source>By Filename</source>
        <translation>Op Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="258"/>
        <location filename="../playlist.cpp" line="313"/>
        <source>By Path + Filename</source>
        <translation>Op Pad + Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="262"/>
        <location filename="../playlist.cpp" line="317"/>
        <source>By Date</source>
        <translation>Op Datum</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="266"/>
        <location filename="../playlist.cpp" line="321"/>
        <source>By Track Number</source>
        <translation>Op Lied Nummer</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="270"/>
        <location filename="../playlist.cpp" line="325"/>
        <source>By File Creation Date</source>
        <translation>Op datum van creatie</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="274"/>
        <location filename="../playlist.cpp" line="329"/>
        <source>By File Modification Date</source>
        <translation>Op datum van bewerking</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="278"/>
        <source>By Group</source>
        <translation>Op groep</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="286"/>
        <source>Sort Selection</source>
        <translation>Sorteer Selectie</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="337"/>
        <source>Randomize List</source>
        <translation>Schud Lijst</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="339"/>
        <source>Reverse List</source>
        <translation>Draai Lijst Om</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="350"/>
        <source>Actions</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="621"/>
        <source>Rename Playlist</source>
        <translation>Hernoem Afspeellijst</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="621"/>
        <source>Playlist name:</source>
        <translation>Naam van de Afspeellijst:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="642"/>
        <source>&amp;New PlayList</source>
        <translation>&amp;Nieuwe Afspeellijst</translation>
    </message>
</context>
<context>
    <name>PlayListBrowser</name>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="14"/>
        <source>Playlist Browser</source>
        <translation>Afspeellijst Navigator</translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="31"/>
        <source>Filter:</source>
        <translation>Filter:</translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="43"/>
        <source>New</source>
        <translation>Nieuw</translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="50"/>
        <location filename="../playlistbrowser.cpp" line="43"/>
        <source>Delete</source>
        <translation>Verwijder</translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="57"/>
        <location filename="../forms/playlistbrowser.ui" line="67"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../playlistbrowser.cpp" line="42"/>
        <source>Rename</source>
        <translation>Hernoem</translation>
    </message>
</context>
<context>
    <name>PlayListHeader</name>
    <message>
        <location filename="../playlistheader.cpp" line="86"/>
        <source>Add Column</source>
        <translation>Kolom toevoegen</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="87"/>
        <source>Edit Column</source>
        <translation>Wijzig kolom</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="88"/>
        <source>Show Queue/Protocol</source>
        <translation>Wachtrij/Protocol tonen</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="90"/>
        <source>Auto-resize</source>
        <translation>Automatische grootte</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="93"/>
        <source>Alignment</source>
        <translation>Uitlijning</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="94"/>
        <source>Left</source>
        <comment>alignment</comment>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="95"/>
        <source>Right</source>
        <comment>alignment</comment>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="96"/>
        <source>Center</source>
        <comment>alignment</comment>
        <translation>Midden</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="106"/>
        <source>Remove Column</source>
        <translation>Kolom verwijderen</translation>
    </message>
</context>
<context>
    <name>PopupSettings</name>
    <message>
        <location filename="../forms/popupsettings.ui" line="14"/>
        <source>Popup Information Settings</source>
        <translation>Toon Informatie Instellingen</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="29"/>
        <source>Template</source>
        <translation>Layout</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="58"/>
        <source>Reset</source>
        <translation>Terugzetten</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="65"/>
        <source>Insert</source>
        <translation>Invoegen</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="75"/>
        <source>Show cover</source>
        <translation>Toon Hoes</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="89"/>
        <source>Cover size:</source>
        <translation>Albumhoesgrootte:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="115"/>
        <source>Transparency:</source>
        <translation>Transparantie:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="145"/>
        <source>Delay:</source>
        <translation>Vertraging:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="178"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
</context>
<context>
    <name>PresetEditor</name>
    <message>
        <location filename="../forms/preseteditor.ui" line="14"/>
        <source>Preset Editor</source>
        <translation>Profiel Bewerker</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="36"/>
        <source>Preset</source>
        <translation>Instelling</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="52"/>
        <source>Auto-preset</source>
        <translation>Auto-profiel</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="77"/>
        <source>Load</source>
        <translation>Laad</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="84"/>
        <source>Delete</source>
        <translation>Verwijder</translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="14"/>
        <source>Change Shortcut</source>
        <translation>Verander Sneltoets</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="29"/>
        <source>Press the key combination you want to assign</source>
        <translation>Druk de gewenste sneltoetscombinatie</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="52"/>
        <source>Clear</source>
        <translation>Leeghalen</translation>
    </message>
</context>
<context>
    <name>SkinnedFactory</name>
    <message>
        <location filename="../skinnedfactory.cpp" line="35"/>
        <source>Skinned User Interface</source>
        <translation>Thematische Gebruikersinterface</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="61"/>
        <source>About Qmmp Skinned User Interface</source>
        <translation>Over de Qmmp Thematische Gebruikersinterface</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="62"/>
        <source>Qmmp Skinned User Interface</source>
        <translation>Qmmp Thematische Gebruikersinterface</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="63"/>
        <source>Simple user interface with Winamp-2.x/XMMS skins support</source>
        <translation>Simpele gebruikersinterface met Winamp-2.x/XMMS thema ondersteuning</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="64"/>
        <source>Written by:</source>
        <translation>Auteur:</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="65"/>
        <source>Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;</source>
        <translation>Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="66"/>
        <source>Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="67"/>
        <source>Artwork:</source>
        <translation>Uiterlijk:</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="68"/>
        <source>Andrey Adreev &lt;andreev00@gmail.com&gt;</source>
        <translation>Andrey Adreev &lt;andreev00@gmail.com&gt;</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="69"/>
        <source>sixsixfive &lt;http://sixsixfive.deviantart.com/&gt;</source>
        <translation>sixsixfive &lt;http://sixsixfive.deviantart.com/&gt;</translation>
    </message>
</context>
<context>
    <name>SkinnedSettings</name>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="24"/>
        <source>Skins</source>
        <translation>Thema&apos;s</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="55"/>
        <source>Add...</source>
        <translation>Toevoegen...</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="68"/>
        <source>Refresh</source>
        <translation>Herlaad</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="95"/>
        <source>Main Window</source>
        <translation>Hoofdvenster</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="101"/>
        <source>Hide on close</source>
        <translation>Verberg bij sluit</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="108"/>
        <source>Start hidden</source>
        <translation>Start verborgen</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="115"/>
        <source>Use skin cursors</source>
        <translation>Gebruik thema cursor</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="253"/>
        <source>Single Column Mode</source>
        <translation>Eénkolommodus</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="307"/>
        <source>Show splitters</source>
        <translation>Splitsgrepen tonen</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="314"/>
        <source>Alternate splitter color</source>
        <translation>Alternatieve splitsgreepkleur</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="416"/>
        <source>Fonts</source>
        <translation>Lettertypen</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="470"/>
        <source>Playlist:</source>
        <translation>Afspeellijst:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="506"/>
        <source>Column headers:</source>
        <translation>Kolomtitels:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="428"/>
        <source>Player:</source>
        <translation>Speler:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="450"/>
        <location filename="../forms/skinnedsettings.ui" line="492"/>
        <location filename="../forms/skinnedsettings.ui" line="519"/>
        <source>???</source>
        <translation>???</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="134"/>
        <location filename="../forms/skinnedsettings.ui" line="457"/>
        <location filename="../forms/skinnedsettings.ui" line="499"/>
        <location filename="../forms/skinnedsettings.ui" line="526"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="548"/>
        <source>Reset fonts</source>
        <translation>Lettertypen herstellen</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="557"/>
        <source>Use bitmap font if available</source>
        <translation>Gebruik bitmap lettertype indien aanwezig</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="124"/>
        <source>Window title format:</source>
        <translation>Venstertitelopmaak:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="89"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="146"/>
        <source>Transparency</source>
        <translation>Transparantie</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="152"/>
        <source>Main window</source>
        <translation>Hoofdscherm</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="175"/>
        <location filename="../forms/skinnedsettings.ui" line="199"/>
        <location filename="../forms/skinnedsettings.ui" line="223"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="182"/>
        <source>Equalizer</source>
        <translation>Equalizer</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="206"/>
        <source>Playlist</source>
        <translation>Afspeellijst</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="247"/>
        <source>Song Display</source>
        <translation>Nummer Weergave</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="286"/>
        <source>Show protocol</source>
        <translation>Laad protocol</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="266"/>
        <source>Show song lengths</source>
        <translation>Duur van nummers tonen</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="259"/>
        <source>Show song numbers</source>
        <translation>Toon liednummers</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="276"/>
        <source>Align song numbers</source>
        <translation>Liednummers uitlijnen</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="293"/>
        <source>Show anchor</source>
        <translation>Toon verankering</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="300"/>
        <source>Show playlists</source>
        <translation>Toon afspeellijst</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="368"/>
        <source>Show popup information</source>
        <translation>Toon popup informatie</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="380"/>
        <source>Edit template</source>
        <translation>Bewerk layout</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="333"/>
        <source>Playlist separator:</source>
        <translation>Scheidingsteken afspeellijst:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="324"/>
        <source>Show &apos;New Playlist&apos; button</source>
        <translation>Toon &apos;Nieuwe Afspeellijst&apos; knop</translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="120"/>
        <source>Select Skin Files</source>
        <translation>Selecteer themabestanden</translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="121"/>
        <source>Skin files</source>
        <translation>Thema bestanden</translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="173"/>
        <source>Unarchived skin</source>
        <translation>Niet gearchiveerd thema</translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="210"/>
        <source>Archived skin</source>
        <translation>Gearchiveerd thema</translation>
    </message>
</context>
<context>
    <name>TextScroller</name>
    <message>
        <location filename="../textscroller.cpp" line="57"/>
        <source>Autoscroll Songname</source>
        <translation>Automatisch naar Liednummer Scrollen</translation>
    </message>
    <message>
        <location filename="../textscroller.cpp" line="58"/>
        <source>Transparent Background</source>
        <translation>Transparante Achtergrond</translation>
    </message>
    <message>
        <location filename="../textscroller.cpp" line="129"/>
        <source>Buffering: %1%</source>
        <translation>Bufferen: %1%</translation>
    </message>
</context>
<context>
    <name>VisualMenu</name>
    <message>
        <location filename="../visualmenu.cpp" line="26"/>
        <source>Visualization</source>
        <translation>Visualisatie</translation>
    </message>
</context>
</TS>
