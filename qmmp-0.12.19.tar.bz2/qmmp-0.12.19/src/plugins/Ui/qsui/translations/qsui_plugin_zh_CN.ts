<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>AboutQSUIDialog</name>
    <message>
        <location filename="../forms/aboutqsuidialog.ui" line="14"/>
        <source>About QSUI</source>
        <translation>关于QSUI</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="41"/>
        <source>Qmmp Simple User Interface (QSUI)</source>
        <translation>Qmmp播放器简单用户界面(QSUI)</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="42"/>
        <source>Qmmp version: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Qmmp播放器版本：&lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="46"/>
        <source>Developers:</source>
        <translation>开发者：</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="47"/>
        <source>Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="49"/>
        <source>Translators:</source>
        <translation>译者：</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="44"/>
        <source>Simple user interface based on standard widgets set.</source>
        <translation> 简单的用户界面基于标准小工具系列。</translation>
    </message>
</context>
<context>
    <name>ActionManager</name>
    <message>
        <location filename="../actionmanager.cpp" line="40"/>
        <source>&amp;Play</source>
        <translation>播放(&amp;P)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="40"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="41"/>
        <source>&amp;Pause</source>
        <translation>暂停(&amp;P)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="41"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="42"/>
        <source>&amp;Stop</source>
        <translation>停止(&amp;S)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="42"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>&amp;Previous</source>
        <translation>上一曲(&amp;P)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>&amp;Next</source>
        <translation>下一首(&amp;N)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>&amp;Play/Pause</source>
        <translation>播放/暂停(&amp;P)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>Space</source>
        <translation>空格键</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>&amp;Jump to Track</source>
        <translation>跳至单曲(&amp;J)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>&amp;Play Files</source>
        <translation>&amp;播放文件</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>&amp;Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>&amp;Repeat Playlist</source>
        <translation>&amp;重复播放列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>&amp;Repeat Track</source>
        <translation>&amp;重复单曲</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;重排</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>&amp;No Playlist Advance</source>
        <translation>&amp;播放列表中播放的曲目不自动前进</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Ctrl+N</source>
        <translation>Ctrl + N</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="56"/>
        <source>&amp;Stop After Selected</source>
        <translation>&amp;播完选定的曲目后停止播放</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>&amp;Clear Queue</source>
        <translation>&amp;清除正在排队中的所有曲目</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="60"/>
        <source>Always on Top</source>
        <translation>总是在顶部显示</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="61"/>
        <source>Put on All Workspaces</source>
        <translation>在所有工作空间中显示</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="66"/>
        <source>Show Tabs</source>
        <translation>显示分页标签</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>Show Title Bars</source>
        <translation>显示题头栏</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>Block Toolbars</source>
        <translation>不显示工具栏</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="70"/>
        <source>Volume &amp;+</source>
        <translation>音量 &amp;+</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="70"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>Volume &amp;-</source>
        <translation>音量 &amp;-</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>&amp;Mute</source>
        <translation>&amp;静音</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="74"/>
        <source>&amp;Add File</source>
        <translation>&amp;添加文件</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="74"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>&amp;Add Directory</source>
        <translation>&amp;添加文件夹</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>&amp;Add Url</source>
        <translation>&amp;添加Url</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;移除所选项</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>&amp;Remove All</source>
        <translation>&amp;移除所有文件</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="80"/>
        <source>&amp;Remove Unselected</source>
        <translation>&amp;移除未被选中项</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="82"/>
        <source>Remove unavailable files</source>
        <translation>移除已不存在的文件</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>Remove duplicates</source>
        <translation>移除多余副本</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="85"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>&amp;Queue Toggle</source>
        <translation>&amp;排队状态切换</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>Invert Selection</source>
        <translation>反选</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>&amp;Select None</source>
        <translation>&amp;什么也不选</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>&amp;Select All</source>
        <translation>&amp;选择所有文件</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>&amp;View Track Details</source>
        <translation>&amp;查看曲目详细内容</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>&amp;New List</source>
        <translation>&amp;新的列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>&amp;Delete List</source>
        <translation>&amp;删除列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>&amp;Load List</source>
        <translation>&amp;载入列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>&amp;Save List</source>
        <translation>&amp;保存列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>Shift+S</source>
        <translation>Shift+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>&amp;Rename List</source>
        <translation>&amp;重命名列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="99"/>
        <source>&amp;Select Next Playlist</source>
        <translation>&amp;选择下一个播放列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+PgDown</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="101"/>
        <source>&amp;Select Previous Playlist</source>
        <translation>&amp;选择上一个播放列表</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="102"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+PgUp</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="103"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="103"/>
        <source>&amp;Group Tracks</source>
        <translation>&amp;对曲目分组</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="104"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="104"/>
        <source>&amp;Show Column Headers</source>
        <translation>&amp;显示n列题眉</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="106"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;均衡器</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="106"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="107"/>
        <source>&amp;Settings</source>
        <translation>设置(&amp;S)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="107"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="108"/>
        <source>&amp;About Ui</source>
        <translation>&amp;关于Ui</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="109"/>
        <source>&amp;About</source>
        <translation>&amp;关于</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="110"/>
        <source>&amp;About Qt</source>
        <translation>&amp;关于Qt</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="111"/>
        <source>&amp;Exit</source>
        <translation>&amp;退出</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="111"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="284"/>
        <source>Toolbar</source>
        <translation>工具栏</translation>
    </message>
</context>
<context>
    <name>ColorWidget</name>
    <message>
        <location filename="../colorwidget.cpp" line="37"/>
        <source>Select Color</source>
        <translation>选择颜色</translation>
    </message>
</context>
<context>
    <name>CoverWidget</name>
    <message>
        <location filename="../coverwidget.cpp" line="32"/>
        <source>&amp;Save As...</source>
        <translation>&amp;另存为</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="65"/>
        <source>Save Cover As</source>
        <translation>将封面另存为</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="67"/>
        <source>Images</source>
        <translation>图片</translation>
    </message>
</context>
<context>
    <name>Equalizer</name>
    <message>
        <location filename="../equalizer.cpp" line="39"/>
        <source>Equalizer</source>
        <translation>均衡器</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="48"/>
        <source>Enable equalizer</source>
        <translation>启用均衡器</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="54"/>
        <source>Preset:</source>
        <translation>预设：</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="62"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="66"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="70"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="83"/>
        <source>Preamp</source>
        <translation>前置放大器</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="100"/>
        <location filename="../equalizer.cpp" line="197"/>
        <source>%1dB</source>
        <translation>%1分贝</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="102"/>
        <location filename="../equalizer.cpp" line="195"/>
        <source>+%1dB</source>
        <translation>+%1分贝</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="150"/>
        <source>preset</source>
        <translation>预设</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="220"/>
        <source>Overwrite Request</source>
        <translation>覆盖请求</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="221"/>
        <source>Preset &apos;%1&apos; already exists. Overwrite?</source>
        <translation>预设&apos;%1&apos;已经存在。是否覆盖？</translation>
    </message>
</context>
<context>
    <name>FileSystemBrowser</name>
    <message>
        <location filename="../filesystembrowser.cpp" line="95"/>
        <source>Add to Playlist</source>
        <translation>添加到播放列表中</translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="97"/>
        <source>Change Directory</source>
        <translation>更改文件夹</translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="99"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="173"/>
        <source>Select Directory</source>
        <translation>选择文件夹</translation>
    </message>
</context>
<context>
    <name>HotkeyEditor</name>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="40"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="54"/>
        <source>Action</source>
        <translation>行动</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="59"/>
        <source>Shortcut</source>
        <translation>快捷键</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="33"/>
        <source>Change shortcut...</source>
        <translation>更改快捷键</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="55"/>
        <source>Reset Shortcuts</source>
        <translation>重置快捷键</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="56"/>
        <source>Do you want to restore default shortcuts?</source>
        <translation>您希望将快捷键恢复到默认值吗？</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="68"/>
        <source>Playback</source>
        <translation>回放</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="74"/>
        <source>View</source>
        <translation>视图</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="80"/>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="86"/>
        <source>Playlist</source>
        <translation>播放列表</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="92"/>
        <source>Misc</source>
        <translation>其他杂项</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../forms/mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="972"/>
        <source>Qmmp</source>
        <translation>Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="32"/>
        <source>&amp;File</source>
        <translation>&amp;文件</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="37"/>
        <source>&amp;Tools</source>
        <translation>&amp;工具</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="45"/>
        <source>&amp;Help</source>
        <translation>&amp;帮助</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="50"/>
        <source>&amp;Edit</source>
        <translation>&amp;编辑</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="55"/>
        <source>&amp;Playback</source>
        <translation>&amp;回放</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="60"/>
        <source>&amp;View</source>
        <translation>&amp;视图</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="84"/>
        <source>Spectrum Analyzer</source>
        <translation>光谱分析器</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="99"/>
        <source>Files</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="114"/>
        <source>Cover</source>
        <translation>封面</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="123"/>
        <source>Playlists</source>
        <translation>播放列表</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="137"/>
        <source>Previous</source>
        <translation>上一个</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="147"/>
        <source>Play</source>
        <translation>播放</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="157"/>
        <source>Pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="167"/>
        <source>Next</source>
        <translation>下一首</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="177"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="182"/>
        <source>&amp;Add File</source>
        <translation>&amp;添加文件</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="187"/>
        <source>&amp;Remove All</source>
        <translation>&amp;移除所有文件</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="192"/>
        <source>New Playlist</source>
        <translation>新的播放列表</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="197"/>
        <source>Remove Playlist</source>
        <translation>移除播放列表</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="202"/>
        <source>&amp;Add Directory</source>
        <translation>&amp;添加文件夹</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="207"/>
        <source>&amp;Exit</source>
        <translation>&amp;退出</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="212"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="217"/>
        <source>About Qt</source>
        <translation>关于Qt</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="222"/>
        <source>&amp;Select All</source>
        <translation>&amp;选择所有文件</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="227"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;移除所选项</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="232"/>
        <source>&amp;Remove Unselected</source>
        <translation>&amp;移除未被选中项</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="237"/>
        <source>Visualization</source>
        <translation>音频视觉化</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="242"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="247"/>
        <location filename="../mainwindow.cpp" line="293"/>
        <source>Rename Playlist</source>
        <translation>重命名播放列表</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="470"/>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="380"/>
        <source>&lt;b&gt;%1&lt;/b&gt;|%2 bit|%3 ch|%4 Hz|tracks: %5|total time: %6|%7 kbps|</source>
        <translation>&lt;b&gt;%1&lt;/b?|%2 比特|%3频道|%4赫兹|曲目：%5|总计时间：%6|%7前比特每秒|</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <source>Paused</source>
        <translation>被暂停</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="391"/>
        <source>&lt;b&gt;%1&lt;/b&gt;|tracks: %2|total time: %3|</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;|曲目：%2|总计时间：%3|</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="392"/>
        <source>Stopped</source>
        <translation>被停止</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="293"/>
        <source>Playlist name:</source>
        <translation>播放列表名称：</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="334"/>
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="335"/>
        <source>Shortcuts</source>
        <translation>热键</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <source>Playing</source>
        <translation>播放中</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="460"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="466"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="468"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="472"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="528"/>
        <source>Edit Toolbars</source>
        <translation>编辑工具栏</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="530"/>
        <source>Sort List</source>
        <translation>清单排序</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="533"/>
        <location filename="../mainwindow.cpp" line="588"/>
        <source>By Title</source>
        <translation>按标题</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="537"/>
        <location filename="../mainwindow.cpp" line="592"/>
        <source>By Album</source>
        <translation>按专辑</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="541"/>
        <location filename="../mainwindow.cpp" line="596"/>
        <source>By Artist</source>
        <translation>按艺术家</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="545"/>
        <location filename="../mainwindow.cpp" line="600"/>
        <source>By Album Artist</source>
        <translation>按专辑 艺术家</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="549"/>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>By Filename</source>
        <translation>按文件名称</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="553"/>
        <location filename="../mainwindow.cpp" line="608"/>
        <source>By Path + Filename</source>
        <translation>按路径+文件名称</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="557"/>
        <location filename="../mainwindow.cpp" line="612"/>
        <source>By Date</source>
        <translation>按日期</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="561"/>
        <location filename="../mainwindow.cpp" line="616"/>
        <source>By Track Number</source>
        <translation>按单曲号</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="565"/>
        <location filename="../mainwindow.cpp" line="620"/>
        <source>By Disc Number</source>
        <translation>按光盘号</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="569"/>
        <location filename="../mainwindow.cpp" line="624"/>
        <source>By File Creation Date</source>
        <translation>按文件的创建日期</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="573"/>
        <location filename="../mainwindow.cpp" line="628"/>
        <source>By File Modification Date</source>
        <translation>按文件的修改日期</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="577"/>
        <source>By Group</source>
        <translation>按组</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="585"/>
        <source>Sort Selection</source>
        <translation>排序选择</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="635"/>
        <source>Randomize List</source>
        <translation>随机列表</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="637"/>
        <source>Reverse List</source>
        <translation>反序列表</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="644"/>
        <location filename="../mainwindow.cpp" line="685"/>
        <source>Actions</source>
        <translation>行动</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="425"/>
        <source>Add new playlist</source>
        <translation>添加新播放列表</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="431"/>
        <source>Show all tabs</source>
        <translation>显示所有的分页标签</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>Buffering: %1%</source>
        <translation>缓冲中：%1%</translation>
    </message>
</context>
<context>
    <name>PlayListHeader</name>
    <message>
        <location filename="../playlistheader.cpp" line="65"/>
        <source>Add Column</source>
        <translation>增加n列</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="66"/>
        <source>Edit Column</source>
        <translation>编辑n列</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="67"/>
        <source>Show Queue/Protocol</source>
        <translation>显示排队/协议</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="69"/>
        <source>Auto-resize</source>
        <translation>自动调整大小</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="72"/>
        <source>Alignment</source>
        <translation>对齐</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="73"/>
        <source>Left</source>
        <comment>alignment</comment>
        <translation>左对齐</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="74"/>
        <source>Right</source>
        <comment>alignment</comment>
        <translation>右对齐</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="75"/>
        <source>Center</source>
        <comment>alignment</comment>
        <translation>居中</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="85"/>
        <source>Remove Column</source>
        <translation>移除n列</translation>
    </message>
</context>
<context>
    <name>PopupSettings</name>
    <message>
        <location filename="../forms/popupsettings.ui" line="14"/>
        <source>Popup Information Settings</source>
        <translation>弹出信息设置</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="29"/>
        <source>Template</source>
        <translation>模板</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="58"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="65"/>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="75"/>
        <source>Show cover</source>
        <translation>显示封面</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="89"/>
        <source>Cover size:</source>
        <translation>封面尺寸：</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="115"/>
        <source>Transparency:</source>
        <translation>透明：</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="145"/>
        <source>Delay:</source>
        <translation>延迟：</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="178"/>
        <source>ms</source>
        <translation>毫秒</translation>
    </message>
</context>
<context>
    <name>QSUIFactory</name>
    <message>
        <location filename="../qsuifactory.cpp" line="32"/>
        <source>Simple User Interface</source>
        <translation>简单用户界面</translation>
    </message>
</context>
<context>
    <name>QSUISettings</name>
    <message>
        <location filename="../forms/qsuisettings.ui" line="24"/>
        <source>View</source>
        <translation>视图</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="36"/>
        <source>Hide on close</source>
        <translation>点击关闭后隐藏</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="43"/>
        <source>Start hidden</source>
        <translation>启动后隐藏</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="770"/>
        <source>Fonts</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="776"/>
        <source>Use system fonts</source>
        <translation>使用系统字体</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="824"/>
        <source>Playlist:</source>
        <translation>播放列表：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="804"/>
        <location filename="../forms/qsuisettings.ui" line="869"/>
        <location filename="../forms/qsuisettings.ui" line="888"/>
        <source>???</source>
        <translation>？？？</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="62"/>
        <location filename="../forms/qsuisettings.ui" line="811"/>
        <location filename="../forms/qsuisettings.ui" line="834"/>
        <location filename="../forms/qsuisettings.ui" line="895"/>
        <source>...</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="30"/>
        <source>Main Window</source>
        <translation>主窗口</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="52"/>
        <source>Window title format:</source>
        <translation>窗口题目格式：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="74"/>
        <source>Song Display</source>
        <translation>歌曲显示</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="80"/>
        <source>Show protocol</source>
        <translation>显示协议</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="144"/>
        <source>Show song numbers</source>
        <translation>显示歌曲号</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="151"/>
        <source>Show song lengths</source>
        <translation>显示歌曲长度</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="161"/>
        <source>Align song numbers</source>
        <translation>排列歌曲号</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="87"/>
        <source>Show anchor</source>
        <translation>显示定位锚</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="101"/>
        <source>Show popup information</source>
        <translation>显示弹出信息</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="113"/>
        <source>Edit template</source>
        <translation>编辑模板</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="917"/>
        <source>Reset fonts</source>
        <translation>重置字体</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="932"/>
        <source>Column headers:</source>
        <translation>n列题眉：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="847"/>
        <source>Tab names:</source>
        <translation>分页标签名：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="959"/>
        <source>Miscellaneous</source>
        <translation>其他杂项</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="191"/>
        <source>Analyzer Colors</source>
        <translation>分析器颜色</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="94"/>
        <source>Show splitters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="138"/>
        <source>Single Column Mode</source>
        <translation>单列模式</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="185"/>
        <source>Colors</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="197"/>
        <source>Analyzer #1:</source>
        <translation>分析器#1：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="232"/>
        <source>Peaks:</source>
        <translation>峰值：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="264"/>
        <source>Analyzer #2:</source>
        <translation>分析器#2：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="296"/>
        <source>Background:</source>
        <translation>背景：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="328"/>
        <source>Analyzer #3:</source>
        <translation>分析器#3：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="405"/>
        <source>Playlist Colors</source>
        <translation>播放列表颜色</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="477"/>
        <source>Background #1:</source>
        <translation>背景#1：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="537"/>
        <source>Normal text:</source>
        <translation>正常文本：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="645"/>
        <source>Background #2:</source>
        <translation>背景#2：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="652"/>
        <source>Current text:</source>
        <translation>当前文本：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="530"/>
        <source>Highlighted background:</source>
        <translation>高亮显示的背景：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="484"/>
        <source>Highlighted text:</source>
        <translation>高亮显示的文本：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="995"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1003"/>
        <source>Icon size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1028"/>
        <source>Customize...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="411"/>
        <source>Use system colors</source>
        <translation>使用系统颜色</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="516"/>
        <source>Group background:</source>
        <translation>分组背景：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="523"/>
        <source>Group text:</source>
        <translation>分组文本：</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="709"/>
        <source>Splitter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="965"/>
        <source>Tabs</source>
        <translation>分页标签</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="971"/>
        <source>Show close buttons</source>
        <translation>显示关闭按钮</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="978"/>
        <source>Show tab list menu</source>
        <translation>显示分页标签列表清单</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="985"/>
        <source>Show &apos;New Playlist&apos; button</source>
        <translation>显示’新播放列表中‘按钮</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="42"/>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="43"/>
        <source>16x16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="44"/>
        <source>22x22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="45"/>
        <source>32x32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="46"/>
        <source>48x48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="47"/>
        <source>64x64</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSUiAnalyzer</name>
    <message>
        <location filename="../qsuianalyzer.cpp" line="228"/>
        <source>Cover</source>
        <translation>封面</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="231"/>
        <source>Peaks</source>
        <translation>峰</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="234"/>
        <source>Refresh Rate</source>
        <translation>刷新率</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="237"/>
        <source>50 fps</source>
        <translation>50 fps</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="238"/>
        <source>25 fps</source>
        <translation>25 帧每秒</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="239"/>
        <source>10 fps</source>
        <translation>10 帧每秒</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="240"/>
        <source>5 fps</source>
        <translation>5 帧每秒</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="247"/>
        <source>Analyzer Falloff</source>
        <translation>分析器坠落</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="250"/>
        <location filename="../qsuianalyzer.cpp" line="264"/>
        <source>Slowest</source>
        <translation>最慢</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="251"/>
        <location filename="../qsuianalyzer.cpp" line="265"/>
        <source>Slow</source>
        <translation>慢</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="252"/>
        <location filename="../qsuianalyzer.cpp" line="266"/>
        <source>Medium</source>
        <translation>中等</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="253"/>
        <location filename="../qsuianalyzer.cpp" line="267"/>
        <source>Fast</source>
        <translation>快</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="254"/>
        <location filename="../qsuianalyzer.cpp" line="268"/>
        <source>Fastest</source>
        <translation>最快</translation>
    </message>
    <message>
        <location filename="../qsuianalyzer.cpp" line="261"/>
        <source>Peaks Falloff</source>
        <translation>顶峰坠落</translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="14"/>
        <source>Change Shortcut</source>
        <translation>更改热键</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="29"/>
        <source>Press the key combination you want to assign</source>
        <translation>按下您希望分配的按键组合</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="52"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
</context>
<context>
    <name>ToolBarEditor</name>
    <message>
        <location filename="../forms/toolbareditor.ui" line="14"/>
        <source>ToolBar Editor</source>
        <translation>工具栏编辑器</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="62"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="199"/>
        <source>Toolbar:</source>
        <translation>工具栏：</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="222"/>
        <source>&amp;Create</source>
        <translation>＆新建</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="238"/>
        <source>Re&amp;name</source>
        <translation>＆重命名</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="254"/>
        <source>&amp;Remove</source>
        <translation>移除(&amp;R)</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="100"/>
        <location filename="../toolbareditor.cpp" line="198"/>
        <source>Separator</source>
        <translation>分隔符</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="248"/>
        <source>Toolbar</source>
        <translation>工具栏</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="250"/>
        <source>Toolbar %1</source>
        <translation>工具栏　%1</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Rename Toolbar</source>
        <translation>重命名　工具栏</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Toolbar name:</source>
        <translation>工具栏　名称：</translation>
    </message>
</context>
<context>
    <name>VisualMenu</name>
    <message>
        <location filename="../visualmenu.cpp" line="27"/>
        <source>Visualization</source>
        <translation>可视化</translation>
    </message>
</context>
<context>
    <name>VolumeSlider</name>
    <message>
        <location filename="../volumeslider.cpp" line="91"/>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
</context>
</TS>
