<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nl">
<context>
    <name>MplayerEngineFactory</name>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="34"/>
        <source>Mplayer Plugin</source>
        <translation>MPlayer Module</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="37"/>
        <source>Video Files</source>
        <translation>Videobestanden</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="84"/>
        <source>About MPlayer Plugin</source>
        <translation>Over de MPlayer Module</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="85"/>
        <source>Qmmp MPlayer Plugin</source>
        <translation>MPlayer Module voor Qmmp</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="86"/>
        <source>This plugin uses MPlayer as backend</source>
        <translation>Deze plugin gebruikt MPlayer</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="87"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Auteur: Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
</context>
<context>
    <name>MplayerMetaDataModel</name>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="39"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="39"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="65"/>
        <source>Demuxer</source>
        <translation>Demultiplexer</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="67"/>
        <source>Video format</source>
        <translation>Videoformaat</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="68"/>
        <source>FPS</source>
        <translation>FPS</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="69"/>
        <source>Video codec</source>
        <translation>Videocodec</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="70"/>
        <source>Aspect ratio</source>
        <translation>Verhouding</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="71"/>
        <source>Video bitrate</source>
        <translation>Video bitrate</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="71"/>
        <location filename="../mplayermetadatamodel.cpp" line="76"/>
        <source>kbps</source>
        <translation>kbps</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="74"/>
        <source>Audio codec</source>
        <translation>Audiocodec</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="75"/>
        <source>Sample rate</source>
        <translation>Sample frequentie</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="75"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="76"/>
        <source>Audio bitrate</source>
        <translation>Audio bitrate</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="77"/>
        <source>Channels</source>
        <translation>Kanalen</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="72"/>
        <source>Resolution</source>
        <translation>Resolutie</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../settingsdialog.ui" line="14"/>
        <source>MPlayer Settings</source>
        <translation>MPlayer Instellingen</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="34"/>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="48"/>
        <source>Audio:</source>
        <translation>Audio:</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="62"/>
        <source>Audio/video auto synchronization</source>
        <translation>Automatische audio/video synchronisatie</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="72"/>
        <source>Synchronization factor:</source>
        <translation>Synchronisatie factor:</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="89"/>
        <source>Extra options:</source>
        <translation>Extra opties:</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="96"/>
        <source>Extra command line options</source>
        <translation>Extra opdrachtregelopties</translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="29"/>
        <location filename="../settingsdialog.cpp" line="37"/>
        <location filename="../settingsdialog.cpp" line="46"/>
        <location filename="../settingsdialog.cpp" line="47"/>
        <location filename="../settingsdialog.cpp" line="61"/>
        <location filename="../settingsdialog.cpp" line="62"/>
        <source>default</source>
        <translation>standaard</translation>
    </message>
</context>
</TS>
