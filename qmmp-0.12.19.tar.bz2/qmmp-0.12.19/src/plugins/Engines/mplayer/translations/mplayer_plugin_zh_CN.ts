<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>MplayerEngineFactory</name>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="34"/>
        <source>Mplayer Plugin</source>
        <translation>Mplayer 插件</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="37"/>
        <source>Video Files</source>
        <translation>视频文件</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="84"/>
        <source>About MPlayer Plugin</source>
        <translation>关于 MPlayer 插件</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="85"/>
        <source>Qmmp MPlayer Plugin</source>
        <translation>Qmmp MPlayer 插件</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="86"/>
        <source>This plugin uses MPlayer as backend</source>
        <translation>此插件使用 MPlayer 后端</translation>
    </message>
    <message>
        <location filename="../mplayerenginefactory.cpp" line="87"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MplayerMetaDataModel</name>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="39"/>
        <source>Size</source>
        <translation>大小：</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="39"/>
        <source>KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="65"/>
        <source>Demuxer</source>
        <translation>流分离：</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="67"/>
        <source>Video format</source>
        <translation>视频格式</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="68"/>
        <source>FPS</source>
        <translation>帧每秒</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="69"/>
        <source>Video codec</source>
        <translation>视频编码</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="70"/>
        <source>Aspect ratio</source>
        <translation>宽高比：</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="71"/>
        <source>Video bitrate</source>
        <translation>视频比特率</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="71"/>
        <location filename="../mplayermetadatamodel.cpp" line="76"/>
        <source>kbps</source>
        <translation>千比特每秒</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="74"/>
        <source>Audio codec</source>
        <translation>音频编码</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="75"/>
        <source>Sample rate</source>
        <translation>取样率</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="75"/>
        <source>Hz</source>
        <translation>赫兹</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="76"/>
        <source>Audio bitrate</source>
        <translation>音频比特率</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="77"/>
        <source>Channels</source>
        <translation>声音通道</translation>
    </message>
    <message>
        <location filename="../mplayermetadatamodel.cpp" line="72"/>
        <source>Resolution</source>
        <translation>分辨率</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../settingsdialog.ui" line="14"/>
        <source>MPlayer Settings</source>
        <translation>Mplayer 设置</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="34"/>
        <source>Video:</source>
        <translation>视频：</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="48"/>
        <source>Audio:</source>
        <translation>音频：</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="62"/>
        <source>Audio/video auto synchronization</source>
        <translation>音频/视频自动同步</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="72"/>
        <source>Synchronization factor:</source>
        <translation>同步系数：</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="89"/>
        <source>Extra options:</source>
        <translation>其他选项：</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="96"/>
        <source>Extra command line options</source>
        <translation>其他命令行选项</translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="29"/>
        <location filename="../settingsdialog.cpp" line="37"/>
        <location filename="../settingsdialog.cpp" line="46"/>
        <location filename="../settingsdialog.cpp" line="47"/>
        <location filename="../settingsdialog.cpp" line="61"/>
        <location filename="../settingsdialog.cpp" line="62"/>
        <source>default</source>
        <translation>默认</translation>
    </message>
</context>
</TS>
