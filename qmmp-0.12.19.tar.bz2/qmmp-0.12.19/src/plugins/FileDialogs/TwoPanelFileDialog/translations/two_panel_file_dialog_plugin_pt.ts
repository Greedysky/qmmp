<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt">
<context>
    <name>TwoPanelFileDialog</name>
    <message>
        <location filename="../twopanelfiledialog.ui" line="14"/>
        <source>Add Files</source>
        <translation>Adicionar ficheiros</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="70"/>
        <source>File name:</source>
        <translation>Nome do ficheiro:</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="80"/>
        <source>Files of type:</source>
        <translation>Ficheiros do tipo:</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="117"/>
        <source>Play</source>
        <translation>Reproduzir</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="130"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="143"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>TwoPanelFileDialogFactory</name>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="67"/>
        <location filename="../twopanelfiledialog.cpp" line="77"/>
        <source>Two-panel File Dialog</source>
        <translation>Diálogo Two-Panel File</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="76"/>
        <source>About Two-panel File Dialog</source>
        <translation>Sobre o Two-panel File</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="78"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Desenvolvido por: Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="79"/>
        <source>Based on code from the Qt library</source>
        <translation>Baseado no código da biblioteca Qt</translation>
    </message>
</context>
<context>
    <name>TwoPanelFileDialogImpl</name>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="341"/>
        <location filename="../twopanelfiledialogimpl.cpp" line="357"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="359"/>
        <source>Directories</source>
        <translation>Diretórios</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="371"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="478"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 já existe.
Gostaria de o substituir?</translation>
    </message>
</context>
</TS>
