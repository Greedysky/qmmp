<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="gl_ES">
<context>
    <name>AboutQSUIDialog</name>
    <message>
        <location filename="../forms/aboutqsuidialog.ui" line="14"/>
        <source>About QSUI</source>
        <translation>Acerca de QSUI</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="41"/>
        <source>Qmmp Simple User Interface (QSUI)</source>
        <translation>Interface simple de usuario QMMP (QSUI)</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="42"/>
        <source>Qmmp version: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Versión de Qmmp: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="46"/>
        <source>Developers:</source>
        <translation>Desenvolvedores:</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="47"/>
        <source>Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="49"/>
        <source>Translators:</source>
        <translation>Traductores:</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="44"/>
        <source>Simple user interface based on standard widgets set.</source>
        <translation>Interface de usuario simple basada no conxuto de widgets estándar.</translation>
    </message>
</context>
<context>
    <name>ActionManager</name>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>&amp;Play</source>
        <translation>&amp;Reproducir</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausa</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>&amp;Stop</source>
        <translation>&amp;Deter</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>&amp;Previous</source>
        <translation>&amp;Anterior</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>&amp;Next</source>
        <translation>&amp;Seguinte</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>&amp;Play/Pause</source>
        <translation>&amp;Reproducir/Pausar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>Space</source>
        <translation>Espacio</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>&amp;Jump to Track</source>
        <translation>&amp;Saltar a pista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>&amp;Play Files</source>
        <translation>&amp;Reproducir Arquivos</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="51"/>
        <source>&amp;Record</source>
        <translation>&amp;Grabar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>&amp;Repeat Playlist</source>
        <translation>&amp;Repetir lista de reprodución</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>&amp;Repeat Track</source>
        <translation>&amp;Repetir pista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;Aleatorio</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>&amp;No Playlist Advance</source>
        <translation>&amp;Non avanzar na lista de reprodución</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="56"/>
        <source>&amp;Transit between playlists</source>
        <translation>&amp;Transición entre listas de reprodución</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>&amp;Stop After Selected</source>
        <translation>&amp;Deter despois da seleccionada</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>&amp;Clear Queue</source>
        <translation>&amp;Limpar cola</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="60"/>
        <source>Always on Top</source>
        <translation>Sempre por enriba</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="61"/>
        <source>Put on All Workspaces</source>
        <translation>Poñer en tódolos escritorios</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>Show Tabs</source>
        <translation>Amosar lapelas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>Show Title Bars</source>
        <translation>Amosar barras de título</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="69"/>
        <source>Block Toolbars</source>
        <translation>Bloquear barras de ferramentas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>&amp;Mute</source>
        <translation>&amp;Silenciar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>&amp;Add File</source>
        <translation>&amp;Engadir ficheiro</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>&amp;Add Directory</source>
        <translation>&amp;Engadir directorio</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>&amp;Add Url</source>
        <translation>&amp;Engadir Url</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Eliminar seleccionada</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>Del</source>
        <translation>Supr</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>&amp;Remove All</source>
        <translation>&amp;Eliminar todas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="80"/>
        <source>&amp;Remove Unselected</source>
        <translation>&amp;Eliminar deseleccionadas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="81"/>
        <source>Remove unavailable files</source>
        <translation>Eliminar os ficheiros non dispoñibles</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="82"/>
        <source>Remove duplicates</source>
        <translation>Eliminar duplicados</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="83"/>
        <source>Refresh</source>
        <translation>Refrescar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>&amp;Queue Toggle</source>
        <translation>&amp;Cambio de cola</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="85"/>
        <source>Invert Selection</source>
        <translation>Inverter selección</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>&amp;Select None</source>
        <translation>&amp;Non seleccionar nada</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>&amp;Select All</source>
        <translation>&amp;Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>&amp;View Track Details</source>
        <translation>&amp;Ver detalles da pista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>&amp;New List</source>
        <translation>&amp;Lista nova</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>&amp;Delete List</source>
        <translation>&amp;Borrar lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>&amp;Load List</source>
        <translation>&amp;Cargar lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>&amp;Save List</source>
        <translation>&amp;Gardar lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>Shift+S</source>
        <translation>Shift+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>&amp;Rename List</source>
        <translation>&amp;Renomear lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>&amp;Select Next Playlist</source>
        <translation>&amp;Seleccionar a próxima lista de reprodución</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+PgDown</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>&amp;Select Previous Playlist</source>
        <translation>&amp;Seleccionar a lista de reprodución anterior</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+repág</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>&amp;Group Tracks</source>
        <translation>&amp;Pistas do grupo</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>&amp;Show Column Headers</source>
        <translation>&amp;Amosar cabeceiras das columnas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="99"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Ecualizador</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="99"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>&amp;Settings</source>
        <translation>&amp;Preferencias</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="101"/>
        <source>Application Menu</source>
        <translation>Menú Aplicación</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="102"/>
        <source>&amp;About Ui</source>
        <translation>&amp;Acerca do Ui</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="103"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="104"/>
        <source>&amp;About Qt</source>
        <translation>&amp;Acerca de Qt</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="105"/>
        <source>&amp;Exit</source>
        <translation>&amp;Saír</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="105"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="328"/>
        <source>Toolbar</source>
        <translation>Barra de ferramentas</translation>
    </message>
</context>
<context>
    <name>ColorWidget</name>
    <message>
        <location filename="../colorwidget.cpp" line="47"/>
        <source>Select Color</source>
        <translation>Seleccionar cor</translation>
    </message>
</context>
<context>
    <name>CoverWidget</name>
    <message>
        <location filename="../coverwidget.cpp" line="32"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Gardar como...</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="65"/>
        <source>Save Cover As</source>
        <translation>Gardar cuberta como</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="67"/>
        <source>Images</source>
        <translation>Imaxes</translation>
    </message>
</context>
<context>
    <name>Equalizer</name>
    <message>
        <location filename="../equalizer.cpp" line="43"/>
        <source>Equalizer</source>
        <translation>Ecualizador</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="52"/>
        <source>Enable equalizer</source>
        <translation>Habilitar ecualizador</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="58"/>
        <source>Preset:</source>
        <translation>Perfil:</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="66"/>
        <source>Save</source>
        <translation>Gardar</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="70"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="74"/>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="87"/>
        <source>Preamp</source>
        <translation>Preamplificación</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="104"/>
        <location filename="../equalizer.cpp" line="201"/>
        <source>%1dB</source>
        <translation>%1dB</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="106"/>
        <location filename="../equalizer.cpp" line="199"/>
        <source>+%1dB</source>
        <translation>+%1dB</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="154"/>
        <source>preset</source>
        <translation>perfil</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="224"/>
        <source>Overwrite Request</source>
        <translation>Sobreescribir solicitude</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="225"/>
        <source>Preset &apos;%1&apos; already exists. Overwrite?</source>
        <translation>O perfil &apos;%1&apos; xa existe. Queres sobreescribilo?</translation>
    </message>
</context>
<context>
    <name>FileSystemBrowser</name>
    <message>
        <location filename="../filesystembrowser.cpp" line="91"/>
        <source>Add to Playlist</source>
        <translation>Engadir á lista de producción</translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="93"/>
        <source>Change Directory</source>
        <translation>Mudar directorio</translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="98"/>
        <source>Quick Search</source>
        <translation>Búsqueda Rápida</translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="172"/>
        <source>Select Directory</source>
        <translation>Seleccionar directorio</translation>
    </message>
</context>
<context>
    <name>HotkeyEditor</name>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="40"/>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="54"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="59"/>
        <source>Shortcut</source>
        <translation>Acceso directo</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="33"/>
        <source>Change shortcut...</source>
        <translation>Cambiar acceso rápido...</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="55"/>
        <source>Reset Shortcuts</source>
        <translation>Reiniciar tecras de acceso rápido</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="56"/>
        <source>Do you want to restore default shortcuts?</source>
        <translation>Desexas restaurar as tecras de acceso rápido predefinidas?</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="68"/>
        <source>Playback</source>
        <translation>Reprodución</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="74"/>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="80"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="86"/>
        <source>Playlist</source>
        <translation>Lista de reprodución</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="92"/>
        <source>Misc</source>
        <translation>Miscelánea</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="100"/>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../forms/mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="957"/>
        <source>Qmmp</source>
        <translation>Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="35"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="40"/>
        <source>&amp;Tools</source>
        <translation>&amp;Ferramentas</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="48"/>
        <source>&amp;Help</source>
        <translation>&amp;Axuda</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="53"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="58"/>
        <source>&amp;Playback</source>
        <translation>&amp;Reproducción</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="63"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="102"/>
        <source>Files</source>
        <translation>Arquivos</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="117"/>
        <source>Cover</source>
        <translation>Portada</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="126"/>
        <source>Playlists</source>
        <translation>Listas de reproducción</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="138"/>
        <source>Waveform Seek Bar</source>
        <translation>Barra de procura da forma da onda </translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="152"/>
        <source>Previous</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="162"/>
        <source>Play</source>
        <translation>Reproducir</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="172"/>
        <source>Pause</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="182"/>
        <source>Next</source>
        <translation>Próxima</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="192"/>
        <source>Stop</source>
        <translation>Deter</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="197"/>
        <source>&amp;Add File</source>
        <translation>&amp;Engadir ficheiro</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="202"/>
        <source>&amp;Remove All</source>
        <translation>&amp;Eliminar todas</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="207"/>
        <source>New Playlist</source>
        <translation>Nova lista de reproducción</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="212"/>
        <source>Remove Playlist</source>
        <translation>Eliminar lista de reproducción</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="217"/>
        <source>&amp;Add Directory</source>
        <translation>&amp;Engadir directorio</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="222"/>
        <source>&amp;Exit</source>
        <translation>&amp;Saír</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="227"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="232"/>
        <source>About Qt</source>
        <translation>Acerca de Qt</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="237"/>
        <source>&amp;Select All</source>
        <translation>&amp;Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="242"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Eliminar seleccionada</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="247"/>
        <source>&amp;Remove Unselected</source>
        <translation>&amp;Eliminar deseleccionadas</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="87"/>
        <location filename="../forms/mainwindow.ui" line="252"/>
        <source>Visualization</source>
        <translation>Visualización</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="257"/>
        <source>Settings</source>
        <translation>Axustes</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="262"/>
        <location filename="../mainwindow.cpp" line="280"/>
        <source>Rename Playlist</source>
        <translation>Renomear lista de reprodución</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="471"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="280"/>
        <source>Playlist name:</source>
        <translation>Nome da lista de reprodución:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="321"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="322"/>
        <source>Shortcuts</source>
        <translation>Accesos rápidos</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="401"/>
        <source>Menu Bar</source>
        <translation>Barra de Menú</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="458"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="464"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="469"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>Quick Search</source>
        <translation>Búsqueda Rápida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="531"/>
        <source>Edit Toolbars</source>
        <translation>Editar barras de ferramentas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="533"/>
        <source>Sort List</source>
        <translation>Ordear lista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="536"/>
        <location filename="../mainwindow.cpp" line="577"/>
        <source>By Title</source>
        <translation>Por título</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="539"/>
        <location filename="../mainwindow.cpp" line="580"/>
        <source>By Album</source>
        <translation>Por álbume</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="542"/>
        <location filename="../mainwindow.cpp" line="583"/>
        <source>By Artist</source>
        <translation>Por artista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="545"/>
        <location filename="../mainwindow.cpp" line="586"/>
        <source>By Album Artist</source>
        <translation>Por Artista do álbum</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="548"/>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>By Filename</source>
        <translation>Por nome de ficheiro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="551"/>
        <location filename="../mainwindow.cpp" line="592"/>
        <source>By Path + Filename</source>
        <translation>Por ruta + nome de ficheiro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="554"/>
        <location filename="../mainwindow.cpp" line="595"/>
        <source>By Date</source>
        <translation>Por data</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="557"/>
        <location filename="../mainwindow.cpp" line="598"/>
        <source>By Track Number</source>
        <translation>Por número de pista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <location filename="../mainwindow.cpp" line="601"/>
        <source>By Disc Number</source>
        <translation>Por número de disco</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="563"/>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>By File Creation Date</source>
        <translation>Por data de creación do ficheiro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="566"/>
        <location filename="../mainwindow.cpp" line="607"/>
        <source>By File Modification Date</source>
        <translation>Por data de modificación do arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="569"/>
        <source>By Group</source>
        <translation>Por grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <source>Sort Selection</source>
        <translation>Ordear selección</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="612"/>
        <source>Randomize List</source>
        <translation>Lista aleatoria</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="614"/>
        <source>Reverse List</source>
        <translation>Reverter lista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>Actions</source>
        <translation>Accións</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="420"/>
        <source>Add new playlist</source>
        <translation>Engadir nova lista de reproducción</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="426"/>
        <source>Show all tabs</source>
        <translation>Amosar tódalas lapelas</translation>
    </message>
</context>
<context>
    <name>PlayListBrowser</name>
    <message>
        <location filename="../playlistbrowser.cpp" line="62"/>
        <source>Quick Search</source>
        <translation>Búsqueda Rápida</translation>
    </message>
</context>
<context>
    <name>PlayListHeader</name>
    <message>
        <location filename="../playlistheader.cpp" line="59"/>
        <source>Add Column</source>
        <translation>Engadir columna</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="60"/>
        <source>Edit Column</source>
        <translation>Editar columna</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="61"/>
        <source>Show Queue/Protocol</source>
        <translation>Amosar cola/Protocolo</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="63"/>
        <source>Auto-resize</source>
        <translation>Mudar tamaño automáticamente</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="66"/>
        <source>Alignment</source>
        <translation>Aliñamento</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="67"/>
        <source>Left</source>
        <comment>alignment</comment>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="68"/>
        <source>Right</source>
        <comment>alignment</comment>
        <translation>Dereita</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="69"/>
        <source>Center</source>
        <comment>alignment</comment>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="79"/>
        <source>Remove Column</source>
        <translation>Quitar columna</translation>
    </message>
</context>
<context>
    <name>PopupSettings</name>
    <message>
        <location filename="../forms/popupsettings.ui" line="14"/>
        <source>Popup Information Settings</source>
        <translation>Preferencias de información emerxente</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="29"/>
        <source>Template</source>
        <translation>Plantilla</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="58"/>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="65"/>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="75"/>
        <source>Show cover</source>
        <translation>Amosar cuberta</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="89"/>
        <source>Cover size:</source>
        <translation>Tamaño de cuberta:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="115"/>
        <source>Transparency:</source>
        <translation>Transparencia:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="145"/>
        <source>Delay:</source>
        <translation>Duración:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="165"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
</context>
<context>
    <name>QSUISettings</name>
    <message>
        <location filename="../forms/qsuisettings.ui" line="24"/>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="36"/>
        <source>Hide on close</source>
        <translation>Ocultar no peche</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="43"/>
        <source>Start hidden</source>
        <translation>Comezar agochado</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="206"/>
        <source>Visualization Colors</source>
        <translation>Cores de visualización</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="212"/>
        <source>Color #1:</source>
        <translation>Cor #1:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="279"/>
        <source>Color #2:</source>
        <translation>Cor #2:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="343"/>
        <source>Color #3:</source>
        <translation>Cor #3:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="432"/>
        <source>Reset colors</source>
        <translation>Reiniciar cores</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="873"/>
        <source>Waveform Seekbar Colors</source>
        <translation>Cores de procura da forma da onda</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="879"/>
        <source>Progress bar:</source>
        <translation>Barra de progreso:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="968"/>
        <source>RMS:</source>
        <extracomment>Root mean square</extracomment>
        <translation>RMS:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1013"/>
        <source>Waveform:</source>
        <translation>Forma da onda:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1054"/>
        <source>Fonts</source>
        <translation>Fontes</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1060"/>
        <source>Use system fonts</source>
        <translation>Usar as tipografías do sistema</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1108"/>
        <source>Playlist:</source>
        <translation>Lista de reprodución:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1088"/>
        <location filename="../forms/qsuisettings.ui" line="1153"/>
        <location filename="../forms/qsuisettings.ui" line="1172"/>
        <source>???</source>
        <translation>???</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="62"/>
        <location filename="../forms/qsuisettings.ui" line="1095"/>
        <location filename="../forms/qsuisettings.ui" line="1118"/>
        <location filename="../forms/qsuisettings.ui" line="1179"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="30"/>
        <source>Main Window</source>
        <translation>Xanela principal</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="52"/>
        <source>Window title format:</source>
        <translation>Formato do título da xanela:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="74"/>
        <source>Song Display</source>
        <translation>Pantalla de canción</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="80"/>
        <source>Show protocol</source>
        <translation>Mostrar protocolo</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="144"/>
        <source>Show song numbers</source>
        <translation>Mostrar números de canción</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="151"/>
        <source>Show song lengths</source>
        <translation>Amosar lonxitudes das cancións</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="161"/>
        <source>Align song numbers</source>
        <translation>Aliñar números de canción</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="87"/>
        <source>Show anchor</source>
        <translation>Mostrar áncora</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="101"/>
        <source>Show popup information</source>
        <translation>Mostrar información emerxente</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="113"/>
        <source>Edit template</source>
        <translation>Editar plantilla</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1201"/>
        <source>Reset fonts</source>
        <translation>Reiniciar as tipografías</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1216"/>
        <source>Column headers:</source>
        <translation>Cabeceiras da columna:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1131"/>
        <source>Tab names:</source>
        <translation>Nomes das lapela:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1243"/>
        <source>Miscellaneous</source>
        <translation>Miscelánea</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="94"/>
        <source>Show splitters</source>
        <translation>Ver divisores</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="138"/>
        <source>Single Column Mode</source>
        <translation>Modo columna única</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="185"/>
        <source>Colors</source>
        <translation>Cores</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="247"/>
        <source>Peaks:</source>
        <translation>Picos:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="311"/>
        <location filename="../forms/qsuisettings.ui" line="961"/>
        <source>Background:</source>
        <translation>Fondo:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="444"/>
        <source>Playlist Colors</source>
        <translation>Cores da lista de reproducción</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="466"/>
        <source>Background #1:</source>
        <translation>Fondo #1:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="498"/>
        <source>Normal text:</source>
        <translation>Texto normal:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="530"/>
        <source>Background #2:</source>
        <translation>Fondo #2:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="562"/>
        <source>Current text:</source>
        <translation>Texto actual:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="594"/>
        <source>Highlighted background:</source>
        <translation>Fondo seleccionado:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="626"/>
        <source>Highlighted text:</source>
        <translation>Texto seleccionado:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="814"/>
        <source>Override current track background</source>
        <translation>Modificar o actual fondo de pista</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="769"/>
        <source>Current track background:</source>
        <translation>Actual fondo de pista:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="860"/>
        <source>Override group background</source>
        <translation>Modificar o fondo do grupo</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1276"/>
        <source>Tab position:</source>
        <translation>Posición tabulador:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1313"/>
        <source>Toolbars</source>
        <translation>Barras de ferramentas</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1321"/>
        <source>Icon size:</source>
        <translation>Tamaño da icona:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1346"/>
        <source>Customize...</source>
        <translation>Persoalizar...</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="450"/>
        <source>Use system colors</source>
        <translation>Usar cores do sistema</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="734"/>
        <source>Group background:</source>
        <translation>Grupo de fondo:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="702"/>
        <source>Group text:</source>
        <translation>Grupo de texto:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="661"/>
        <source>Splitter:</source>
        <translation>Divisor:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1249"/>
        <source>Tabs</source>
        <translation>Lapelas</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1255"/>
        <source>Show close buttons</source>
        <translation>Amosar botóns de pechado</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1262"/>
        <source>Show tab list menu</source>
        <translation>Amosar menú da lista de lapelas</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1269"/>
        <source>Show &apos;New Playlist&apos; button</source>
        <translation>Amosar botón &apos;Nova lista de reprodución&apos;</translation>
    </message>
</context>
<context>
    <name>QSUIVisualization</name>
    <message>
        <location filename="../qsuivisualization.cpp" line="126"/>
        <source>Cover</source>
        <translation>Portada</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="129"/>
        <source>Visualization Mode</source>
        <translation>Modo de visualización</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="132"/>
        <source>Analyzer</source>
        <translation>Analizador</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="133"/>
        <source>Scope</source>
        <translation>Pendente</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="140"/>
        <source>Analyzer Mode</source>
        <translation>Modo de analizador</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="142"/>
        <source>Cells</source>
        <translation>Células</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="143"/>
        <source>Lines</source>
        <translation>Liñas</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="151"/>
        <source>Peaks</source>
        <translation>Picos</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="154"/>
        <source>Refresh Rate</source>
        <translation>Taxa de refresco</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="157"/>
        <source>50 fps</source>
        <translation>50 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="158"/>
        <source>25 fps</source>
        <translation>25 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="159"/>
        <source>10 fps</source>
        <translation>10 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="160"/>
        <source>5 fps</source>
        <translation>5 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="167"/>
        <source>Analyzer Falloff</source>
        <translation>Analizador Falloff</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="170"/>
        <location filename="../qsuivisualization.cpp" line="184"/>
        <source>Slowest</source>
        <translation>O máis lento</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="171"/>
        <location filename="../qsuivisualization.cpp" line="185"/>
        <source>Slow</source>
        <translation>Lento</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="172"/>
        <location filename="../qsuivisualization.cpp" line="186"/>
        <source>Medium</source>
        <translation>Medio</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="173"/>
        <location filename="../qsuivisualization.cpp" line="187"/>
        <source>Fast</source>
        <translation>Rápido</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="174"/>
        <location filename="../qsuivisualization.cpp" line="188"/>
        <source>Fastest</source>
        <translation>O máis rápido</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="181"/>
        <source>Peaks Falloff</source>
        <translation>Caída de picos</translation>
    </message>
</context>
<context>
    <name>QSUiFactory</name>
    <message>
        <location filename="../qsuifactory.cpp" line="32"/>
        <source>Simple User Interface</source>
        <translation>Interface de usuario simple</translation>
    </message>
</context>
<context>
    <name>QSUiSettings</name>
    <message>
        <location filename="../qsuisettings.cpp" line="43"/>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="44"/>
        <source>16x16</source>
        <translation>16x16</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="45"/>
        <source>22x22</source>
        <translation>22x22</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="46"/>
        <source>32x32</source>
        <translation>32x32</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="47"/>
        <source>48x48</source>
        <translation>48x48</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="48"/>
        <source>64x64</source>
        <translation>64x64</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="50"/>
        <source>Top</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="51"/>
        <source>Bottom</source>
        <translation>Abaixo</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="52"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="53"/>
        <source>Right</source>
        <translation>Dereita</translation>
    </message>
</context>
<context>
    <name>QSUiStatusBar</name>
    <message>
        <location filename="../qsuistatusbar.cpp" line="68"/>
        <source>tracks: %1</source>
        <translation>pistas: %1</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="69"/>
        <source>total time: %1</source>
        <translation>tempo total: %1</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="87"/>
        <source>Playing</source>
        <translation>Reproducindo</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="87"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="102"/>
        <source>Buffering</source>
        <translation>Buffering</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="127"/>
        <source>Stopped</source>
        <translation>Detido</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="139"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="147"/>
        <source>Buffering: %1%</source>
        <translation>Buffering: %1%</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="152"/>
        <source>%1 bits</source>
        <translation>%1 bits</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="154"/>
        <source>mono</source>
        <translation>mono</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="156"/>
        <source>stereo</source>
        <translation>estéreo</translation>
    </message>
    <message numerus="yes">
        <location filename="../qsuistatusbar.cpp" line="158"/>
        <source>%n channels</source>
        <translation>
            <numerusform>%n canles</numerusform>
            <numerusform>%n canles</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="159"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="164"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
</context>
<context>
    <name>QSUiWaveformSeekBar</name>
    <message>
        <location filename="../qsuiwaveformseekbar.cpp" line="334"/>
        <source>2 Channels</source>
        <translation>2 Canles</translation>
    </message>
    <message>
        <location filename="../qsuiwaveformseekbar.cpp" line="337"/>
        <source>RMS</source>
        <extracomment>Root mean square</extracomment>
        <translation>RMS</translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="14"/>
        <source>Change Shortcut</source>
        <translation>Cambiar acceso rápido</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="29"/>
        <source>Press the key combination you want to assign</source>
        <translation>Pulsar a combinación de teclas que queres asignar</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="52"/>
        <source>Clear</source>
        <translation>Despexar</translation>
    </message>
</context>
<context>
    <name>ToolBarEditor</name>
    <message>
        <location filename="../forms/toolbareditor.ui" line="14"/>
        <source>ToolBar Editor</source>
        <translation>Barra de ferramentas do editor</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="62"/>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="199"/>
        <source>Toolbar:</source>
        <translation>Barra de ferramentas:</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="222"/>
        <source>&amp;Create</source>
        <translation>&amp;Crear</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="238"/>
        <source>Re&amp;name</source>
        <translation>Re&amp;nomear</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="254"/>
        <source>&amp;Remove</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="100"/>
        <location filename="../toolbareditor.cpp" line="198"/>
        <source>Separator</source>
        <translation>Separador</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="248"/>
        <source>Toolbar</source>
        <translation>Barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="250"/>
        <source>Toolbar %1</source>
        <translation>Barra de ferramentas %1</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Rename Toolbar</source>
        <translation>Renomear a barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Toolbar name:</source>
        <translation>Nome da barra de ferramentas:</translation>
    </message>
</context>
<context>
    <name>VisualMenu</name>
    <message>
        <location filename="../visualmenu.cpp" line="26"/>
        <source>Visualization</source>
        <translation>Visualización</translation>
    </message>
</context>
<context>
    <name>VolumeSlider</name>
    <message>
        <location filename="../volumeslider.cpp" line="91"/>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
</context>
</TS>
