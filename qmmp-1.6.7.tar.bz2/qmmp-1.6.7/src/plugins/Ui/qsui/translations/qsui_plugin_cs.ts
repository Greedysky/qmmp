<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>AboutQSUIDialog</name>
    <message>
        <location filename="../forms/aboutqsuidialog.ui" line="14"/>
        <source>About QSUI</source>
        <translation>O QSUI</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="41"/>
        <source>Qmmp Simple User Interface (QSUI)</source>
        <translation>Jednoduché uživatelské rozhraní pro Qmmp (QSUI)</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="42"/>
        <source>Qmmp version: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Verze Qmmp: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="46"/>
        <source>Developers:</source>
        <translation>Vývojáři:</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="47"/>
        <source>Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="49"/>
        <source>Translators:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="44"/>
        <source>Simple user interface based on standard widgets set.</source>
        <translation>Jednoduché uživatelské rozhraní založené na standardní sadě prvků.</translation>
    </message>
</context>
<context>
    <name>ActionManager</name>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>&amp;Play</source>
        <translation>Pře&amp;hrát</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>&amp;Pause</source>
        <translation>Pau&amp;za</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>&amp;Stop</source>
        <translation>Za&amp;stavit</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>&amp;Previous</source>
        <translation>&amp;Předchozí</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>&amp;Next</source>
        <translation>&amp;Následující</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>&amp;Play/Pause</source>
        <translation>&amp;Přehrát/Pauza</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>Space</source>
        <translation>Mezerník</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>&amp;Jump to Track</source>
        <translation>&amp;Skok na stopu</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>&amp;Play Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="51"/>
        <source>&amp;Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>&amp;Repeat Playlist</source>
        <translation>&amp;Opakovat seznam skladeb</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>R</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>&amp;Repeat Track</source>
        <translation>&amp;Opakovat stopu</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>&amp;Shuffle</source>
        <translation>Za&amp;míchat</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>S</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>&amp;No Playlist Advance</source>
        <translation>&amp;Nepostupovat v seznamu skladeb</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="56"/>
        <source>&amp;Transit between playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>&amp;Stop After Selected</source>
        <translation>Za&amp;stavit po výběru</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>&amp;Clear Queue</source>
        <translation>&amp;Vyčistit frontu</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="60"/>
        <source>Always on Top</source>
        <translation>Vždy na vrchu</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="61"/>
        <source>Put on All Workspaces</source>
        <translation>Na všechny pracovní plochy</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>Show Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>Show Title Bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="69"/>
        <source>Block Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>Volume &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>Volume &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>9</source>
        <translation type="unfinished">9</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>&amp;Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>&amp;Add File</source>
        <translation>Přidat &amp;soubor</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>&amp;Add Directory</source>
        <translation>Přidat &amp;adresář</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>&amp;Add Url</source>
        <translation>Přidat &amp;URL</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Odstranit vybrané</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>&amp;Remove All</source>
        <translation>Odstranit &amp;vše</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="80"/>
        <source>&amp;Remove Unselected</source>
        <translation>Odstranit &amp;nevybrané</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="81"/>
        <source>Remove unavailable files</source>
        <translation>Odstranit nedostupné soubory</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="82"/>
        <source>Remove duplicates</source>
        <translation>Odstranit duplicity</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="83"/>
        <source>Refresh</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>&amp;Queue Toggle</source>
        <translation>Do/z &amp;fronty</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="85"/>
        <source>Invert Selection</source>
        <translation>Invertovat výběr</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>&amp;Select None</source>
        <translation>&amp;Zrušit výběr</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>&amp;Select All</source>
        <translation>&amp;Vybrat vše</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>&amp;View Track Details</source>
        <translation>Zobrazit &amp;informace o skladbě</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>&amp;New List</source>
        <translation>&amp;Nový seznam</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>&amp;Delete List</source>
        <translation>O&amp;dstranit seznam</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>&amp;Load List</source>
        <translation>Načíst &amp;seznam</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>&amp;Save List</source>
        <translation>&amp;Uložit seznam</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>Shift+S</source>
        <translation>Shift+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>&amp;Rename List</source>
        <translation>&amp;Přejmenovat seznam</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>&amp;Select Next Playlist</source>
        <translation>Vybrat další &amp;seznam skladeb</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+PageDown</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>&amp;Select Previous Playlist</source>
        <translation>Vybrat předchozí &amp;seznam skladeb</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+PageUp</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>&amp;Group Tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>&amp;Show Column Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="99"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Ekvalizér</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="99"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>&amp;Settings</source>
        <translation>&amp;Nastavení</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="101"/>
        <source>Application Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="102"/>
        <source>&amp;About Ui</source>
        <translation>&amp;O modulu Ui</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="103"/>
        <source>&amp;About</source>
        <translation>O &amp;aplikaci</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="104"/>
        <source>&amp;About Qt</source>
        <translation>O knihovně &amp;Qt</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="105"/>
        <source>&amp;Exit</source>
        <translation>U&amp;končit</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="105"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="328"/>
        <source>Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorWidget</name>
    <message>
        <location filename="../colorwidget.cpp" line="47"/>
        <source>Select Color</source>
        <translation>Vyberte barvu</translation>
    </message>
</context>
<context>
    <name>CoverWidget</name>
    <message>
        <location filename="../coverwidget.cpp" line="32"/>
        <source>&amp;Save As...</source>
        <translation>Uložit j&amp;ako...</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="65"/>
        <source>Save Cover As</source>
        <translation>Uložit obal jako</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="67"/>
        <source>Images</source>
        <translation>Obrázky</translation>
    </message>
</context>
<context>
    <name>Equalizer</name>
    <message>
        <location filename="../equalizer.cpp" line="43"/>
        <source>Equalizer</source>
        <translation>Ekvalizér</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="52"/>
        <source>Enable equalizer</source>
        <translation>Povolit ekvalizér</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="58"/>
        <source>Preset:</source>
        <translation>Předvolba:</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="66"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="70"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="74"/>
        <source>Reset</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="87"/>
        <source>Preamp</source>
        <translation>Předzesílení</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="104"/>
        <location filename="../equalizer.cpp" line="201"/>
        <source>%1dB</source>
        <translation>%1 dB</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="106"/>
        <location filename="../equalizer.cpp" line="199"/>
        <source>+%1dB</source>
        <translation>+%1 dB</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="154"/>
        <source>preset</source>
        <translation>předvolba</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="224"/>
        <source>Overwrite Request</source>
        <translation>Žádost o přepsání</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="225"/>
        <source>Preset &apos;%1&apos; already exists. Overwrite?</source>
        <translation>Předvolba ‚%1‘ již existuje. Přepsat?</translation>
    </message>
</context>
<context>
    <name>FileSystemBrowser</name>
    <message>
        <location filename="../filesystembrowser.cpp" line="91"/>
        <source>Add to Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="93"/>
        <source>Change Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="98"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="172"/>
        <source>Select Directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HotkeyEditor</name>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="40"/>
        <source>Reset</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="54"/>
        <source>Action</source>
        <translation>Akce</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="59"/>
        <source>Shortcut</source>
        <translation>Zkratka</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="33"/>
        <source>Change shortcut...</source>
        <translation>Změnit zkratku...</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="55"/>
        <source>Reset Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="56"/>
        <source>Do you want to restore default shortcuts?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="68"/>
        <source>Playback</source>
        <translation>Přehrávání</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="74"/>
        <source>View</source>
        <translation>Zobrazení</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="80"/>
        <source>Volume</source>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="86"/>
        <source>Playlist</source>
        <translation>Seznam skladeb</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="92"/>
        <source>Misc</source>
        <translation>Různé</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="100"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../forms/mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="957"/>
        <source>Qmmp</source>
        <translation>Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="35"/>
        <source>&amp;File</source>
        <translation>&amp;Soubor</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="40"/>
        <source>&amp;Tools</source>
        <translation>Nás&amp;troje</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="48"/>
        <source>&amp;Help</source>
        <translation>&amp;Nápověda</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="53"/>
        <source>&amp;Edit</source>
        <translation>Ú&amp;pravy</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="58"/>
        <source>&amp;Playback</source>
        <translation>&amp;Přehrávání</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="63"/>
        <source>&amp;View</source>
        <translation>Po&amp;hled</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="102"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="117"/>
        <source>Cover</source>
        <translation>Obal</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="126"/>
        <source>Playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="138"/>
        <source>Waveform Seek Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="152"/>
        <source>Previous</source>
        <translation>Předchozí</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="162"/>
        <source>Play</source>
        <translation>Přehrát</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="172"/>
        <source>Pause</source>
        <translation>Pozastavit</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="182"/>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="192"/>
        <source>Stop</source>
        <translation>Zastavit</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="197"/>
        <source>&amp;Add File</source>
        <translation>Přidat &amp;soubor</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="202"/>
        <source>&amp;Remove All</source>
        <translation>Odstranit &amp;vše</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="207"/>
        <source>New Playlist</source>
        <translation>Nový seznam skladeb</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="212"/>
        <source>Remove Playlist</source>
        <translation>Odstranit seznam skladeb</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="217"/>
        <source>&amp;Add Directory</source>
        <translation>Přidat &amp;adresář</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="222"/>
        <source>&amp;Exit</source>
        <translation>U&amp;končit</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="227"/>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="232"/>
        <source>About Qt</source>
        <translation>O Qt</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="237"/>
        <source>&amp;Select All</source>
        <translation>&amp;Vybrat vše</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="242"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Odstranit vybrané</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="247"/>
        <source>&amp;Remove Unselected</source>
        <translation>Odstranit &amp;nevybrané</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="87"/>
        <location filename="../forms/mainwindow.ui" line="252"/>
        <source>Visualization</source>
        <translation>Vizualizace</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="257"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="262"/>
        <location filename="../mainwindow.cpp" line="280"/>
        <source>Rename Playlist</source>
        <translation>Přejmenovat seznam skladeb</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="471"/>
        <source>Volume</source>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="280"/>
        <source>Playlist name:</source>
        <translation>Název seznamu skladeb:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="321"/>
        <source>Appearance</source>
        <translation>Vzhled</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="322"/>
        <source>Shortcuts</source>
        <translation>Zkratky</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="401"/>
        <source>Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="458"/>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="464"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="469"/>
        <source>Position</source>
        <translation>Umístění</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="531"/>
        <source>Edit Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="533"/>
        <source>Sort List</source>
        <translation>Seřadit seznam</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="536"/>
        <location filename="../mainwindow.cpp" line="577"/>
        <source>By Title</source>
        <translation>Podle názvu skladby</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="539"/>
        <location filename="../mainwindow.cpp" line="580"/>
        <source>By Album</source>
        <translation>Podle alba</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="542"/>
        <location filename="../mainwindow.cpp" line="583"/>
        <source>By Artist</source>
        <translation>Podle umělce</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="545"/>
        <location filename="../mainwindow.cpp" line="586"/>
        <source>By Album Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="548"/>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>By Filename</source>
        <translation>Podle názvu souboru</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="551"/>
        <location filename="../mainwindow.cpp" line="592"/>
        <source>By Path + Filename</source>
        <translation>Podle cesty a názvu souboru</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="554"/>
        <location filename="../mainwindow.cpp" line="595"/>
        <source>By Date</source>
        <translation>Podle data</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="557"/>
        <location filename="../mainwindow.cpp" line="598"/>
        <source>By Track Number</source>
        <translation>Podle čísla skladby</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <location filename="../mainwindow.cpp" line="601"/>
        <source>By Disc Number</source>
        <translation>Podle čísla disku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="563"/>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>By File Creation Date</source>
        <translation>Podle data vytvoření souboru</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="566"/>
        <location filename="../mainwindow.cpp" line="607"/>
        <source>By File Modification Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="569"/>
        <source>By Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <source>Sort Selection</source>
        <translation>Seřadit výběr</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="612"/>
        <source>Randomize List</source>
        <translation>Zamíchat seznam</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="614"/>
        <source>Reverse List</source>
        <translation>Obrátit pořadí seznamu</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>Actions</source>
        <translation>Činnosti</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="420"/>
        <source>Add new playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="426"/>
        <source>Show all tabs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListBrowser</name>
    <message>
        <location filename="../playlistbrowser.cpp" line="62"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListHeader</name>
    <message>
        <location filename="../playlistheader.cpp" line="59"/>
        <source>Add Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="60"/>
        <source>Edit Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="61"/>
        <source>Show Queue/Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="63"/>
        <source>Auto-resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="66"/>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="67"/>
        <source>Left</source>
        <comment>alignment</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="68"/>
        <source>Right</source>
        <comment>alignment</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="69"/>
        <source>Center</source>
        <comment>alignment</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="79"/>
        <source>Remove Column</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PopupSettings</name>
    <message>
        <location filename="../forms/popupsettings.ui" line="14"/>
        <source>Popup Information Settings</source>
        <translation>Nastavení vyskakovacích informací</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="29"/>
        <source>Template</source>
        <translation>Šablona</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="58"/>
        <source>Reset</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="65"/>
        <source>Insert</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="75"/>
        <source>Show cover</source>
        <translation>Zobrazit obal</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="89"/>
        <source>Cover size:</source>
        <translation>Velikost obalu:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="115"/>
        <source>Transparency:</source>
        <translation>Průhlednost:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="145"/>
        <source>Delay:</source>
        <translation>Prodleva:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="165"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
</context>
<context>
    <name>QSUISettings</name>
    <message>
        <location filename="../forms/qsuisettings.ui" line="24"/>
        <source>View</source>
        <translation>Zobrazení</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="36"/>
        <source>Hide on close</source>
        <translation>Skrýt při zavření</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="43"/>
        <source>Start hidden</source>
        <translation>Spustit skryté</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="206"/>
        <source>Visualization Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="212"/>
        <source>Color #1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="279"/>
        <source>Color #2:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="343"/>
        <source>Color #3:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="432"/>
        <source>Reset colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="873"/>
        <source>Waveform Seekbar Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="879"/>
        <source>Progress bar:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="968"/>
        <source>RMS:</source>
        <extracomment>Root mean square</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1013"/>
        <source>Waveform:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1054"/>
        <source>Fonts</source>
        <translation>Písma</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1060"/>
        <source>Use system fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1108"/>
        <source>Playlist:</source>
        <translation>Seznam skladeb:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1088"/>
        <location filename="../forms/qsuisettings.ui" line="1153"/>
        <location filename="../forms/qsuisettings.ui" line="1172"/>
        <source>???</source>
        <translation>???</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="62"/>
        <location filename="../forms/qsuisettings.ui" line="1095"/>
        <location filename="../forms/qsuisettings.ui" line="1118"/>
        <location filename="../forms/qsuisettings.ui" line="1179"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="30"/>
        <source>Main Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="52"/>
        <source>Window title format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="74"/>
        <source>Song Display</source>
        <translation>Zobrazení skladby</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="80"/>
        <source>Show protocol</source>
        <translation>Zobrazit protokol</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="144"/>
        <source>Show song numbers</source>
        <translation>Zobrazit čísla skladeb</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="151"/>
        <source>Show song lengths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="161"/>
        <source>Align song numbers</source>
        <translation>Zarovnat čísla skladeb</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="87"/>
        <source>Show anchor</source>
        <translation>Zobrazit kotvu</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="101"/>
        <source>Show popup information</source>
        <translation>Zobrazit informace ve vyskakovacím okně</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="113"/>
        <source>Edit template</source>
        <translation>Upravit šablonu</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1201"/>
        <source>Reset fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1216"/>
        <source>Column headers:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1131"/>
        <source>Tab names:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1243"/>
        <source>Miscellaneous</source>
        <translation>Různé</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="94"/>
        <source>Show splitters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="138"/>
        <source>Single Column Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="185"/>
        <source>Colors</source>
        <translation>Barvy</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="247"/>
        <source>Peaks:</source>
        <translation>Špičky:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="311"/>
        <location filename="../forms/qsuisettings.ui" line="961"/>
        <source>Background:</source>
        <translation>Pozadí:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="444"/>
        <source>Playlist Colors</source>
        <translation>Barvy seznamu skladeb</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="466"/>
        <source>Background #1:</source>
        <translation>Pozadí #1:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="498"/>
        <source>Normal text:</source>
        <translation>Normální text:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="530"/>
        <source>Background #2:</source>
        <translation>Pozadí #2:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="562"/>
        <source>Current text:</source>
        <translation>Aktuální text:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="594"/>
        <source>Highlighted background:</source>
        <translation>Zvýrazněné pozadí:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="626"/>
        <source>Highlighted text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="814"/>
        <source>Override current track background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="769"/>
        <source>Current track background:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="860"/>
        <source>Override group background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1276"/>
        <source>Tab position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1313"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1321"/>
        <source>Icon size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1346"/>
        <source>Customize...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="450"/>
        <source>Use system colors</source>
        <translation>Použít systémové barvy</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="734"/>
        <source>Group background:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="702"/>
        <source>Group text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="661"/>
        <source>Splitter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1249"/>
        <source>Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1255"/>
        <source>Show close buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1262"/>
        <source>Show tab list menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1269"/>
        <source>Show &apos;New Playlist&apos; button</source>
        <translation>Zobrazit tlačítko ‚Nový seznam skladeb‘</translation>
    </message>
</context>
<context>
    <name>QSUIVisualization</name>
    <message>
        <location filename="../qsuivisualization.cpp" line="126"/>
        <source>Cover</source>
        <translation type="unfinished">Obal</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="129"/>
        <source>Visualization Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="132"/>
        <source>Analyzer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="133"/>
        <source>Scope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="140"/>
        <source>Analyzer Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="142"/>
        <source>Cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="143"/>
        <source>Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="151"/>
        <source>Peaks</source>
        <translation type="unfinished">Špičky</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="154"/>
        <source>Refresh Rate</source>
        <translation type="unfinished">Obnovovací frekvence</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="157"/>
        <source>50 fps</source>
        <translation type="unfinished">50 s/s</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="158"/>
        <source>25 fps</source>
        <translation type="unfinished">25 s/s</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="159"/>
        <source>10 fps</source>
        <translation type="unfinished">10 s/s</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="160"/>
        <source>5 fps</source>
        <translation type="unfinished">5 s/s</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="167"/>
        <source>Analyzer Falloff</source>
        <translation type="unfinished">Pokles analyzéru</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="170"/>
        <location filename="../qsuivisualization.cpp" line="184"/>
        <source>Slowest</source>
        <translation type="unfinished">Nejpomalejší</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="171"/>
        <location filename="../qsuivisualization.cpp" line="185"/>
        <source>Slow</source>
        <translation type="unfinished">Pomalý</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="172"/>
        <location filename="../qsuivisualization.cpp" line="186"/>
        <source>Medium</source>
        <translation type="unfinished">Střední</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="173"/>
        <location filename="../qsuivisualization.cpp" line="187"/>
        <source>Fast</source>
        <translation type="unfinished">Rychlý</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="174"/>
        <location filename="../qsuivisualization.cpp" line="188"/>
        <source>Fastest</source>
        <translation type="unfinished">Nejrychlejší</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="181"/>
        <source>Peaks Falloff</source>
        <translation type="unfinished">Pokles špiček</translation>
    </message>
</context>
<context>
    <name>QSUiFactory</name>
    <message>
        <location filename="../qsuifactory.cpp" line="32"/>
        <source>Simple User Interface</source>
        <translation type="unfinished">Jednoduché uživatelské rozhraní</translation>
    </message>
</context>
<context>
    <name>QSUiSettings</name>
    <message>
        <location filename="../qsuisettings.cpp" line="43"/>
        <source>Default</source>
        <translation type="unfinished">Výchozí</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="44"/>
        <source>16x16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="45"/>
        <source>22x22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="46"/>
        <source>32x32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="47"/>
        <source>48x48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="48"/>
        <source>64x64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="50"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="51"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="52"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="53"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSUiStatusBar</name>
    <message>
        <location filename="../qsuistatusbar.cpp" line="68"/>
        <source>tracks: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="69"/>
        <source>total time: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="87"/>
        <source>Playing</source>
        <translation type="unfinished">Přehrává se</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="87"/>
        <source>Paused</source>
        <translation type="unfinished">Pozastaveno</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="102"/>
        <source>Buffering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="127"/>
        <source>Stopped</source>
        <translation type="unfinished">Zastaveno</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="139"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="147"/>
        <source>Buffering: %1%</source>
        <translation type="unfinished">Načítám: %1 %</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="152"/>
        <source>%1 bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="154"/>
        <source>mono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="156"/>
        <source>stereo</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qsuistatusbar.cpp" line="158"/>
        <source>%n channels</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="159"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="164"/>
        <source>%1 kbps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSUiWaveformSeekBar</name>
    <message>
        <location filename="../qsuiwaveformseekbar.cpp" line="334"/>
        <source>2 Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuiwaveformseekbar.cpp" line="337"/>
        <source>RMS</source>
        <extracomment>Root mean square</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="14"/>
        <source>Change Shortcut</source>
        <translation>Změnit zkratku</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="29"/>
        <source>Press the key combination you want to assign</source>
        <translation>Stlačte kombinaci kláves, kterou chcete přiřadit</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="52"/>
        <source>Clear</source>
        <translation>Vymazat</translation>
    </message>
</context>
<context>
    <name>ToolBarEditor</name>
    <message>
        <location filename="../forms/toolbareditor.ui" line="14"/>
        <source>ToolBar Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="62"/>
        <source>Reset</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="199"/>
        <source>Toolbar:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="222"/>
        <source>&amp;Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="238"/>
        <source>Re&amp;name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="254"/>
        <source>&amp;Remove</source>
        <translation>Odst&amp;ranit</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="100"/>
        <location filename="../toolbareditor.cpp" line="198"/>
        <source>Separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="248"/>
        <source>Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="250"/>
        <source>Toolbar %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Rename Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Toolbar name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VisualMenu</name>
    <message>
        <location filename="../visualmenu.cpp" line="26"/>
        <source>Visualization</source>
        <translation>Vizualizace</translation>
    </message>
</context>
<context>
    <name>VolumeSlider</name>
    <message>
        <location filename="../volumeslider.cpp" line="91"/>
        <source>%1%</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
