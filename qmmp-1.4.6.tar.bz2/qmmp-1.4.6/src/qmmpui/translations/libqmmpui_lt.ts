<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="lt">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About Qmmp</source>
        <translation>Apie Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="49"/>
        <source>About</source>
        <translation>Apie</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="63"/>
        <source>Authors</source>
        <translation>Autoriai</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="77"/>
        <source>Translators</source>
        <translation>Vertėjai</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="91"/>
        <source>Thanks To</source>
        <translation>Dėkojame</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="105"/>
        <source>License Agreement</source>
        <translation>Licenzija</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="63"/>
        <source>Qt-based Multimedia Player (Qmmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="67"/>
        <source>Version: %1</source>
        <translation>Versija: %1</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="68"/>
        <source>Using Qt %1 (compiled with Qt %2)</source>
        <translation>Naudojama Qt %1 (sukompiliuota su Qt %2)</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="71"/>
        <source>(c) %1-%2 Qmmp Development Team</source>
        <translation>(c) %1-%2 Qmmp Kūrėjų Komanda</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="76"/>
        <source>Input plugins:</source>
        <translation>Įeinantys:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="85"/>
        <source>Output plugins:</source>
        <translation>Išeinantys:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="94"/>
        <source>Visual plugins:</source>
        <translation>Vizualizacijos:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="103"/>
        <source>Effect plugins:</source>
        <translation>Efektai:</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="112"/>
        <source>General plugins:</source>
        <translation>Bendriniai įskiepiai:</translation>
    </message>
</context>
<context>
    <name>AddUrlDialog</name>
    <message>
        <location filename="../forms/addurldialog.ui" line="14"/>
        <source>Enter URL to add</source>
        <translation>Įrašyk adresą</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="46"/>
        <source>&amp;Add</source>
        <translation>&amp;Pridėti</translation>
    </message>
    <message>
        <location filename="../forms/addurldialog.ui" line="53"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Atšaukti</translation>
    </message>
    <message>
        <location filename="../addurldialog.cpp" line="88"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
</context>
<context>
    <name>ColumnEditor</name>
    <message>
        <location filename="../forms/columneditor.ui" line="14"/>
        <source>Edit Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="36"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="76"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="64"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../forms/columneditor.ui" line="29"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="85"/>
        <source>Artist</source>
        <translation type="unfinished">Atlikėjas</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="86"/>
        <source>Album</source>
        <translation type="unfinished">Albumas</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="90"/>
        <source>Title</source>
        <translation type="unfinished">Pavadinimas</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="93"/>
        <source>Genre</source>
        <translation type="unfinished">Žanras</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="94"/>
        <source>Comment</source>
        <translation type="unfinished">Komentaras</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="95"/>
        <source>Composer</source>
        <translation type="unfinished">Autorius</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="96"/>
        <source>Duration</source>
        <translation type="unfinished">Trukmė</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="101"/>
        <source>Year</source>
        <translation type="unfinished">Metai</translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="100"/>
        <source>Track Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="87"/>
        <source>Artist - Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="88"/>
        <source>Artist - Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="89"/>
        <source>Album Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="91"/>
        <source>Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="92"/>
        <source>Two-digit Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="97"/>
        <source>Disc Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="98"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="99"/>
        <source>File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="102"/>
        <source>Parent Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../columneditor.cpp" line="103"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../forms/configdialog.ui" line="14"/>
        <source>Qmmp Settings</source>
        <translation>Qmmp nustatymai</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="58"/>
        <source>Playlist</source>
        <translation>Grojaraštis</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="67"/>
        <source>Plugins</source>
        <translation>Įskiepiai</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="76"/>
        <source>Advanced</source>
        <translation>Papildomi</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="85"/>
        <source>Connectivity</source>
        <translation>Tinklas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="94"/>
        <location filename="../forms/configdialog.ui" line="773"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="123"/>
        <source>Metadata</source>
        <translation>Meta duomenys</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="143"/>
        <source>Convert %20 to blanks</source>
        <translation>Paversti %20 į tarpus</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="129"/>
        <source>Load metadata from files</source>
        <translation>Įkelti metaduomenis iš bylų</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="136"/>
        <source>Convert underscores to blanks</source>
        <translation>Paversti brūkšnius į tarpus</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="150"/>
        <source>Group format:</source>
        <translation>Grupės formatas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="160"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="170"/>
        <source>Read tags while loading a playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="180"/>
        <source>Directory Scanning Options</source>
        <translation>Aplanko skenavimo pasirinkimai</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="186"/>
        <source>Restrict files to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="196"/>
        <location filename="../forms/configdialog.ui" line="454"/>
        <source>Exclude files:</source>
        <translation>Išskirti bylas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="209"/>
        <source>Miscellaneous</source>
        <translation>Įvairūs</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="215"/>
        <source>Auto-save playlist when modified</source>
        <translation>Automatiškai išsaugoti grojąraštį po pakeitimų</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="222"/>
        <source>Clear previous playlist when opening new one</source>
        <translation>Išvalyti seną grojąraštį atveriant naują</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="270"/>
        <location filename="../configdialog.cpp" line="321"/>
        <source>Preferences</source>
        <translation>Nustatymai</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="283"/>
        <location filename="../configdialog.cpp" line="324"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="325"/>
        <source>Description</source>
        <translation>Aprašymas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="330"/>
        <source>Filename</source>
        <translation>Bylos pavadinimas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="342"/>
        <source>Look and Feel</source>
        <translation>Išvaizda</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="348"/>
        <source>Language:</source>
        <translation>Kalba:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="381"/>
        <source>Display average bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="391"/>
        <source>Playback</source>
        <translation>Grojimas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="397"/>
        <source>Continue playback on startup</source>
        <translation>Tęsti grojimą įjungus</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="404"/>
        <source>Determine file type by content</source>
        <translation>Nustatyti bylos tipą pagal turinį</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="411"/>
        <source>Add files from command line to this playlist:</source>
        <translation>Į šį grojaraštį įkelti bylas iš komandinės eilutės: </translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="428"/>
        <source>Cover Image Retrieve</source>
        <translation>Parsiųsti cd viršelį</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="434"/>
        <source>Use separate image files</source>
        <translation>Naudoti atskiras paveiksliukų bylas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="444"/>
        <source>Include files:</source>
        <translation>Įtraukti bylas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="466"/>
        <source>Recursive search depth:</source>
        <translation>Rekursinės paieškos gylis:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="498"/>
        <source>URL Dialog</source>
        <translation>Adreso dialogas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="504"/>
        <source>Auto-paste URL from clipboard</source>
        <translation>Automatiškai įkelti adresą iš iškarpinės</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="531"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="543"/>
        <source>Enable proxy usage</source>
        <translation>Įjungti proxy palaikymą </translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="550"/>
        <source>Proxy type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="560"/>
        <source>Proxy host name:</source>
        <translation>Proxy serveris:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="573"/>
        <source>Proxy port:</source>
        <translation>Proxy portas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="586"/>
        <source>Use authentication with proxy</source>
        <translation>Naudoti proxy autentifikavimą</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="593"/>
        <source>Proxy user name:</source>
        <translation>Proxy vartotojo vardas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="606"/>
        <source>Proxy password:</source>
        <translation>Proxy slaptažodis:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="643"/>
        <source>Replay Gain</source>
        <translation>Replay Gain</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="649"/>
        <source>Replay Gain mode:</source>
        <translation>Replay Gain metodas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="666"/>
        <source>Preamp:</source>
        <translation>Išankstinis stiprinimas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="698"/>
        <location filename="../forms/configdialog.ui" line="743"/>
        <source>dB</source>
        <translation>dB</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="711"/>
        <source>Default gain:</source>
        <translation>Stiprinimas pagal nutylėjima:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="763"/>
        <source>Use  peak info to prevent clipping</source>
        <translation>Naudoti pikų informaciją trūkinėjimo išvengimui</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="779"/>
        <source>Buffer size:</source>
        <translation>Buferio dydis:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="805"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="838"/>
        <source>Use software volume control</source>
        <translation>Naudoti programinį garso valdymą</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="878"/>
        <source>Use two passes for equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="821"/>
        <source>Volume adjustment step:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="845"/>
        <source>Output bit depth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="786"/>
        <source>Use dithering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="63"/>
        <source>Track</source>
        <translation>Takelis</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="64"/>
        <source>Album</source>
        <translation>Albumas</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="65"/>
        <source>Disabled</source>
        <translation>Išjungta</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="72"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="73"/>
        <source>SOCKS5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="86"/>
        <source>File Types</source>
        <translation>Bylų tipai</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="196"/>
        <source>Transports</source>
        <translation>Transportas</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="207"/>
        <source>Decoders</source>
        <translation>Dekoderiai</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="218"/>
        <source>Engines</source>
        <translation>Varikliai</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="229"/>
        <source>Effects</source>
        <translation>Efektai</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="240"/>
        <source>Visualization</source>
        <translation>Vizualizacija</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="251"/>
        <source>General</source>
        <translation>Bendri</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="262"/>
        <source>Output</source>
        <translation>Išvestis</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="273"/>
        <source>File Dialogs</source>
        <translation>Bylų dialogai</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="284"/>
        <source>User Interfaces</source>
        <translation>Vartotojo sąsajos</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="334"/>
        <source>&lt;Autodetect&gt;</source>
        <translation>&lt;Aptikti automatiškai&gt;</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="335"/>
        <source>Brazilian Portuguese</source>
        <translation>Brazilų Portugalų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="336"/>
        <source>Chinese Simplified</source>
        <translation>Kinų supaprastintas</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="337"/>
        <source>Chinese Traditional</source>
        <translation>Kinų tradicinis</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="338"/>
        <source>Czech</source>
        <translation>Čekų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="339"/>
        <source>Dutch</source>
        <translation>Olandų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="340"/>
        <source>English</source>
        <translation>Anglų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="341"/>
        <source>French</source>
        <translation>Prancūzų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="342"/>
        <source>Galician</source>
        <translation>Galisų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="343"/>
        <source>German</source>
        <translation>Vokiečių</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="344"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="345"/>
        <source>Hebrew</source>
        <translation>Hebrajų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="346"/>
        <source>Hungarian</source>
        <translation>Vengrų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="347"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="348"/>
        <source>Italian</source>
        <translation>Italų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="349"/>
        <source>Japanese</source>
        <translation>Japonų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="350"/>
        <source>Kazakh</source>
        <translation>Kazachų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="351"/>
        <source>Lithuanian</source>
        <translation>Lietuvių</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="352"/>
        <source>Polish</source>
        <translation>Lenkų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="353"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="354"/>
        <source>Russian</source>
        <translation>Rusų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="355"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="356"/>
        <source>Slovak</source>
        <translation>Slovakų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="357"/>
        <source>Spanish</source>
        <translation>Ispanų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="358"/>
        <source>Turkish</source>
        <translation>Turkų</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="359"/>
        <source>Ukrainian</source>
        <translation>Ukrainiečių</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="360"/>
        <source>Serbian (Ijekavian)</source>
        <translation>Serbų(Ijekavian) </translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="361"/>
        <source>Serbian (Ekavian)</source>
        <translation>Serbų(Ekavian)</translation>
    </message>
</context>
<context>
    <name>CoverEditor</name>
    <message>
        <location filename="../forms/covereditor.ui" line="22"/>
        <source>Image source:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="76"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="83"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/covereditor.ui" line="90"/>
        <source>Save as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="33"/>
        <source>External file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../covereditor.cpp" line="34"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoverViewer</name>
    <message>
        <location filename="../coverviewer.cpp" line="35"/>
        <source>&amp;Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="68"/>
        <source>Save Cover As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="70"/>
        <location filename="../coverviewer.cpp" line="83"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coverviewer.cpp" line="81"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DetailsDialog</name>
    <message>
        <location filename="../forms/detailsdialog.ui" line="14"/>
        <source>Details</source>
        <translation>Apie</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="44"/>
        <source>Open the directory containing this file</source>
        <translation>Atverti aplanką, kuriame yra ši byla</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="47"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/detailsdialog.ui" line="63"/>
        <source>Summary</source>
        <translation>Takelio informacija</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="164"/>
        <source>%1/%2</source>
        <translation>%1/%2</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="210"/>
        <source>Cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="240"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="241"/>
        <source>Artist</source>
        <translation>Atlikėjas</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="242"/>
        <source>Album artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="243"/>
        <source>Album</source>
        <translation>Albumas</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="244"/>
        <source>Comment</source>
        <translation>Komentaras</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="245"/>
        <source>Genre</source>
        <translation>Žanras</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="246"/>
        <source>Composer</source>
        <translation>Autorius</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="247"/>
        <source>Year</source>
        <translation>Metai</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="248"/>
        <source>Track</source>
        <translation>Takelis</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="249"/>
        <source>Disc number</source>
        <translation>Disko numeris</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="267"/>
        <source>Duration</source>
        <translation type="unfinished">Trukmė</translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="270"/>
        <source>Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="270"/>
        <source>kbps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="271"/>
        <source>Sample rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="271"/>
        <source>Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="272"/>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="273"/>
        <source>Sample size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="273"/>
        <source>bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="274"/>
        <source>Format name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="275"/>
        <source>File size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="275"/>
        <source>KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="319"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../detailsdialog.cpp" line="319"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JumpToTrackDialog</name>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="14"/>
        <source>Jump To Track</source>
        <translation>Pereiti prie takelio</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="46"/>
        <source>Filter:</source>
        <translation>Filtras:</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="85"/>
        <location filename="../jumptotrackdialog.cpp" line="90"/>
        <location filename="../jumptotrackdialog.cpp" line="151"/>
        <source>Queue</source>
        <translation>Į eilę</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="101"/>
        <source>Refresh</source>
        <translation>Atnaujinti</translation>
    </message>
    <message>
        <location filename="../forms/jumptotrackdialog.ui" line="117"/>
        <source>Jump To</source>
        <translation>Prereiti prie</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="57"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="58"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="59"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../jumptotrackdialog.cpp" line="88"/>
        <location filename="../jumptotrackdialog.cpp" line="149"/>
        <source>Unqueue</source>
        <translation>Pašalinti iš eilės</translation>
    </message>
</context>
<context>
    <name>MetaDataFormatterMenu</name>
    <message>
        <location filename="../metadataformattermenu.cpp" line="26"/>
        <source>Artist</source>
        <translation type="unfinished">Atlikėjas</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="27"/>
        <source>Album</source>
        <translation type="unfinished">Albumas</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="28"/>
        <source>Album Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="31"/>
        <source>Title</source>
        <translation type="unfinished">Pavadinimas</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="32"/>
        <source>Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="33"/>
        <source>Two-digit Track Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="37"/>
        <source>Track Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="39"/>
        <source>Genre</source>
        <translation type="unfinished">Žanras</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="40"/>
        <source>Comment</source>
        <translation type="unfinished">Komentaras</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="41"/>
        <source>Composer</source>
        <translation type="unfinished">Autorius</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="46"/>
        <source>Duration</source>
        <translation type="unfinished">Trukmė</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="58"/>
        <source>Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="59"/>
        <source>Sample Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="60"/>
        <source>Number of Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="61"/>
        <source>Sample Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="62"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="63"/>
        <source>Decoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="66"/>
        <source>File Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="42"/>
        <source>Disc Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="47"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="48"/>
        <source>File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="43"/>
        <source>Year</source>
        <translation type="unfinished">Metai</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="50"/>
        <source>Condition</source>
        <translation type="unfinished">Būklė</translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="49"/>
        <source>Artist - Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="54"/>
        <source>Artist - [Year] Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../metadataformattermenu.cpp" line="56"/>
        <source>Parent Directory Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListDownloader</name>
    <message>
        <location filename="../playlistdownloader.cpp" line="123"/>
        <source>Unsupported playlist format</source>
        <translation>Napalaikomas grojaraščio tipas</translation>
    </message>
</context>
<context>
    <name>PlayListHeaderModel</name>
    <message>
        <location filename="../playlistheadermodel.cpp" line="36"/>
        <source>Artist - Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="186"/>
        <source>Title</source>
        <translation type="unfinished">Pavadinimas</translation>
    </message>
    <message>
        <location filename="../playlistheadermodel.cpp" line="187"/>
        <source>Add Column</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListManager</name>
    <message>
        <location filename="../playlistmanager.cpp" line="178"/>
        <location filename="../playlistmanager.cpp" line="323"/>
        <source>Playlist</source>
        <translation>Grojaraštis</translation>
    </message>
</context>
<context>
    <name>PlayListTrack</name>
    <message>
        <location filename="../playlisttrack.cpp" line="249"/>
        <source>Streams</source>
        <translation>Srautai</translation>
    </message>
    <message>
        <location filename="../playlisttrack.cpp" line="254"/>
        <source>Empty group</source>
        <translation>Tuščia grupė</translation>
    </message>
</context>
<context>
    <name>QmmpUiSettings</name>
    <message>
        <location filename="../qmmpuisettings.cpp" line="58"/>
        <source>Playlist</source>
        <translation>Grojaraštis</translation>
    </message>
</context>
<context>
    <name>QtFileDialogFactory</name>
    <message>
        <location filename="../qtfiledialog.cpp" line="35"/>
        <source>Qt File Dialog</source>
        <translation>Qt bylų langas</translation>
    </message>
</context>
<context>
    <name>TagEditor</name>
    <message>
        <location filename="../forms/tageditor.ui" line="14"/>
        <source>Tag Editor</source>
        <translation>Meta informacijos redaktorius</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="38"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="64"/>
        <source>Artist:</source>
        <translation>Atlikėjas:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="90"/>
        <source>Album:</source>
        <translation>Albumas:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="113"/>
        <source>Album artist:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="123"/>
        <source>Composer:</source>
        <translation>Autorius:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="143"/>
        <source>Genre:</source>
        <translation>Žanras:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="169"/>
        <source>Track:</source>
        <translation>Takelis:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="190"/>
        <location filename="../forms/tageditor.ui" line="228"/>
        <location filename="../forms/tageditor.ui" line="260"/>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="203"/>
        <source>Year:</source>
        <translation>Metai:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="250"/>
        <source>Disc number:</source>
        <translation>Disko numeris:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="275"/>
        <source>Comment:</source>
        <translation>Komentaras:</translation>
    </message>
    <message>
        <location filename="../forms/tageditor.ui" line="311"/>
        <source>Include selected tag in file</source>
        <translation>Įtraukti meta informaciją į bylą</translation>
    </message>
</context>
<context>
    <name>TemplateEditor</name>
    <message>
        <location filename="../forms/templateeditor.ui" line="14"/>
        <source>Template Editor</source>
        <translation>Šablonų redaktorius</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="39"/>
        <source>Reset</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../forms/templateeditor.ui" line="46"/>
        <source>Insert</source>
        <translation>Įkelti</translation>
    </message>
</context>
<context>
    <name>UiHelper</name>
    <message>
        <location filename="../uihelper.cpp" line="141"/>
        <location filename="../uihelper.cpp" line="153"/>
        <source>All Supported Bitstreams</source>
        <translation>Palaikomi bylų tipai</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="147"/>
        <source>Select one or more files to open</source>
        <translation>Pasirinkite vieną ar kelias bylas atvėrimui</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="159"/>
        <source>Select one or more files to play</source>
        <translation>Pasirink vieną ar daugiau bylų grojimui</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="167"/>
        <source>Choose a directory</source>
        <translation>Pasirinkite aplanką</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="183"/>
        <location filename="../uihelper.cpp" line="209"/>
        <source>Playlist Files</source>
        <translation>Grojaraščio bylos</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="185"/>
        <source>Open Playlist</source>
        <translation>Atverti grojaraštį</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="212"/>
        <location filename="../uihelper.cpp" line="231"/>
        <source>Save Playlist</source>
        <translation>Išsaugoti grojaraštį</translation>
    </message>
    <message>
        <location filename="../uihelper.cpp" line="231"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WinFileAssocPage</name>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="17"/>
        <source>Media files handled by Qmmp:</source>
        <translation>Media bylos, kurias atvers qmmp:</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="49"/>
        <source>Select All</source>
        <translation>Pasirinkti visus</translation>
    </message>
    <message>
        <location filename="../forms/winfileassocpage.ui" line="56"/>
        <source>Select None</source>
        <translation>Nepasirinkti nieko</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="125"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="126"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Ne visi bylų tipai galėjo būti priskirti. Pasitikrink leidimus ir bandyk dar kartą.</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="133"/>
        <source>Check all file types in the list</source>
        <translation>Pažymėti visus media bylų tipus sąraše</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="134"/>
        <source>Uncheck all file types in the list</source>
        <translation>Atžymėti visus bylų tipus sąraše</translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="135"/>
        <source>Check the media file extensions you would like Qmmp to handle. When you click Apply, the checked files will be associated with Qmmp. If you uncheck a media type, the file association will be restored.</source>
        <translation>Pažymėk media bylų tipus, kuriuos turėtų atverti qmmp. Jei atžymėsi, media bylų asociacijos bus atkurtos. </translation>
    </message>
    <message>
        <location filename="../winfileassocpage.cpp" line="139"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; Restoration doesn&apos;t work on Windows Vista/7.</source>
        <translation>&lt;b&gt;Pastaba:&lt;/b&gt; Atkūrimas neveikia Windows Vista/7.</translation>
    </message>
</context>
</TS>
