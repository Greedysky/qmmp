/***************************************************************************
 *   Copyright (C) 2013 by Ilya Kotov                                      *
 *   forkotov02@ya.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.         *
 ***************************************************************************/

#include <QFileInfo>
#include <QDateTime>
#include <QtAlgorithms>
#include "playlistmodel.h"
#include "playlistcontainer_p.h"

void PlayListContainer::addTrack(PlayListTrack *track)
{
    addTracks(QList<PlayListTrack *> () << track);
}

void PlayListContainer::swapTrackNumbers(QList<PlayListItem *> *container, int index1, int index2)
{
    int number = container->at(index1)->trackIndex();
    container->at(index1)->setTrackIndex(container->at(index2)->trackIndex());
    container->at(index2)->setTrackIndex(number);
}
