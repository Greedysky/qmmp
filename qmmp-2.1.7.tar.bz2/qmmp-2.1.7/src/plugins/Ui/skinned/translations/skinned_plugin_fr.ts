<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>ActionManager</name>
    <message>
        <location filename="../actionmanager.cpp" line="39"/>
        <source>&amp;Play</source>
        <translation>&amp;Jouer</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="39"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="40"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pause</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="40"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="41"/>
        <source>&amp;Stop</source>
        <translation>&amp;Arrêter</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="41"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="42"/>
        <source>&amp;Previous</source>
        <translation>&amp;Précédent</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="42"/>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>&amp;Next</source>
        <translation>&amp;Suivant</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>&amp;Play/Pause</source>
        <translation>&amp;Jouer / Arrêter</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>Space</source>
        <translation>Espace</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>&amp;Jump to Track</source>
        <translation>&amp;Sauter à la piste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>&amp;Repeat Playlist</source>
        <translation>&amp;Répéter la liste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>&amp;Repeat Track</source>
        <translation>&amp;Répéter la piste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;Mélanger</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>&amp;No Playlist Advance</source>
        <translation>&amp;Ne pas avancer dans la liste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>&amp;Stop After Selected</source>
        <translation>&amp;Arrêter après la sélection</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="51"/>
        <source>&amp;Transit between playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>&amp;Clear Queue</source>
        <translation>&amp;Effacer la file</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>Show Playlist</source>
        <translation>Montrer la liste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Show Equalizer</source>
        <translation>Montrer l&apos;égaliseur</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Alt+G</source>
        <translation>Alt+G</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="56"/>
        <source>Always on Top</source>
        <translation>Toujours au dessus</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>Put on All Workspaces</source>
        <translation>Placer sur tous les bureaux</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Double Size</source>
        <translation>Doubler la taille</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Meta+D</source>
        <translation>Meta+D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="59"/>
        <source>Anti-aliasing</source>
        <translation>Anticrénelage</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="61"/>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="61"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="62"/>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="62"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="63"/>
        <source>&amp;Mute</source>
        <translation>&amp;Couper le son</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="63"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="65"/>
        <source>&amp;Add File</source>
        <translation>@Ajouter un fichier</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="65"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="66"/>
        <source>&amp;Add Directory</source>
        <translation>&amp;Ajouter un dossier</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="66"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>&amp;Add Url</source>
        <translation>&amp;Ajouter une adresse internet (URL)</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Supprimer la sélection</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>Del</source>
        <translation>Suppr</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="69"/>
        <source>&amp;Remove All</source>
        <translation>&amp;Tout supprimer</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="70"/>
        <source>&amp;Remove Unselected</source>
        <translation>&amp;Ne garder que la sélection</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>Remove unavailable files</source>
        <translation>Supprimer les fichiers non disponibles</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>Remove duplicates</source>
        <translation>Supprimer les fichiers en double</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>Refresh</source>
        <translation>Rafraîchir</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="74"/>
        <source>&amp;Queue Toggle</source>
        <translation>&amp;Activer mettre en file</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="74"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>Invert Selection</source>
        <translation>Inverser la sélection</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>&amp;Select None</source>
        <translation>&amp;Ne rien sélectionner</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>&amp;Select All</source>
        <translation>&amp;Tout sélectionner</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>&amp;View Track Details</source>
        <translation>&amp;Voir les détails du morceau</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>&amp;New List</source>
        <translation>&amp;Nouvelle liste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="80"/>
        <source>&amp;Delete List</source>
        <translation>&amp;Supprimer la liste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="80"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="81"/>
        <source>&amp;Load List</source>
        <translation>&amp;Charger la lsite</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="81"/>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="82"/>
        <source>&amp;Save List</source>
        <translation>&amp;Enregistrer la liste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="82"/>
        <source>Shift+S</source>
        <translation>Shift+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="83"/>
        <source>&amp;Rename List</source>
        <translation>&amp;Renommer la liste</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="83"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>&amp;Select Next Playlist</source>
        <translation>&amp;Sélectionner la liste suivante</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+PageBas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="85"/>
        <source>&amp;Select Previous Playlist</source>
        <translation>&amp;Sélectionner la liste précédente</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="85"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+PageHaut</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>&amp;Show Playlists</source>
        <translation>&amp;Montrer les listes</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>&amp;Group Tracks</source>
        <translation>&amp;Grouper les pistes</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>&amp;Show Column Headers</source>
        <translation>&amp;Montrer les noms de colonnes</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>Show &amp;Tab Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>Alt+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>&amp;Settings</source>
        <translation>&amp;Configuration</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>&amp;About</source>
        <translation>&amp;À propos</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>&amp;About Qt</source>
        <translation>&amp;À propos de Qt</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>&amp;Exit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
</context>
<context>
    <name>ColorWidget</name>
    <message>
        <location filename="../colorwidget.cpp" line="47"/>
        <source>Select Color</source>
        <translation>Sélectionner couleur</translation>
    </message>
</context>
<context>
    <name>EqWidget</name>
    <message>
        <location filename="../eqwidget.cpp" line="47"/>
        <source>Equalizer</source>
        <translation>Égaliseur</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="171"/>
        <location filename="../eqwidget.cpp" line="188"/>
        <source>preset</source>
        <translation>réglage</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="272"/>
        <source>&amp;Load/Delete</source>
        <translation>&amp;Charger / Supprimer</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="274"/>
        <source>&amp;Save Preset</source>
        <translation>&amp;Enregistrer un réglage</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="276"/>
        <source>&amp;Save Auto-load Preset</source>
        <translation>&amp;Enregistrer un réglage automatiquement chargé</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="278"/>
        <source>&amp;Import</source>
        <translation>&amp;Importer</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="281"/>
        <source>&amp;Clear</source>
        <translation>&amp;Effacer</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="310"/>
        <source>Saving Preset</source>
        <translation>Réglage en cours d&apos;enregistrement</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="311"/>
        <source>Preset name:</source>
        <translation>Nom du réglage : </translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="312"/>
        <source>preset #</source>
        <translation>réglage #</translation>
    </message>
    <message>
        <location filename="../eqwidget.cpp" line="403"/>
        <source>Import Preset</source>
        <translation>Importer un réglage</translation>
    </message>
</context>
<context>
    <name>HotkeyEditor</name>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="43"/>
        <source>Reset</source>
        <translation>Réinitialiser</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="57"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="62"/>
        <source>Shortcut</source>
        <translation>Raccourci</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="33"/>
        <source>Change shortcut...</source>
        <translation>Changer le raccourci</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="57"/>
        <source>Playback</source>
        <translation>Lecture</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="63"/>
        <source>View</source>
        <translation>Vue</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="69"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="75"/>
        <source>Playlist</source>
        <translation>Liste</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="81"/>
        <source>Misc</source>
        <translation>Divers</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="93"/>
        <source>Reset Shortcuts</source>
        <translation>Réinitialiser les raccourcis</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="94"/>
        <source>Do you want to restore default shortcuts?</source>
        <translation>Voulez-vous restaurer les raccourcis par défaut&#xa0;?</translation>
    </message>
</context>
<context>
    <name>MainDisplay</name>
    <message>
        <location filename="../display.cpp" line="59"/>
        <source>Previous</source>
        <translation>Précédent</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="63"/>
        <source>Play</source>
        <translation>Jouer</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="66"/>
        <source>Pause</source>
        <translation>Mettre en pause</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="69"/>
        <source>Stop</source>
        <translation>Arrêter</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="72"/>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="75"/>
        <source>Play files</source>
        <translation>Jouer les fichiers</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="82"/>
        <source>Equalizer</source>
        <translation>Égaliseur</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="85"/>
        <source>Playlist</source>
        <translation>Liste</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="90"/>
        <source>Repeat playlist</source>
        <translation>Répéter la liste</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="93"/>
        <source>Shuffle</source>
        <translation>Mélanger</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="103"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="109"/>
        <source>Balance</source>
        <translation>Balance</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="295"/>
        <source>Volume: %1%</source>
        <translation>Volume : %1 %</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="299"/>
        <source>Balance: %1% right</source>
        <translation>Balance : %1 % droite</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="301"/>
        <source>Balance: %1% left</source>
        <translation>Balance : %1 % gauche</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="303"/>
        <source>Balance: center</source>
        <translation>Balance : centre</translation>
    </message>
    <message>
        <location filename="../display.cpp" line="309"/>
        <source>Seek to: %1</source>
        <translation>Aller à : %1</translation>
    </message>
</context>
<context>
    <name>MainVisual</name>
    <message>
        <location filename="../mainvisual.cpp" line="214"/>
        <source>Visualization Mode</source>
        <translation>Mode visualisation</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="217"/>
        <source>Analyzer</source>
        <translation>Analyseur</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="218"/>
        <source>Scope</source>
        <translation>Oscilloscope</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="219"/>
        <source>Off</source>
        <translation>Arrêt</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="226"/>
        <source>Analyzer Mode</source>
        <translation>Mode analyseur</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="229"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="230"/>
        <source>Fire</source>
        <translation>Feu</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="231"/>
        <source>Vertical Lines</source>
        <translation>Lignes verticales</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="232"/>
        <source>Lines</source>
        <translation>Lignes</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="233"/>
        <source>Bars</source>
        <translation>Barres</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="246"/>
        <source>Peaks</source>
        <translation>Pics</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="250"/>
        <source>Refresh Rate</source>
        <translation>Taux de rafraîchissement</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="253"/>
        <source>50 fps</source>
        <translation>50 ips</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="254"/>
        <source>25 fps</source>
        <translation>25 ips</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="255"/>
        <source>10 fps</source>
        <translation>10 ips</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="256"/>
        <source>5 fps</source>
        <translation>5 ips</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="263"/>
        <source>Analyzer Falloff</source>
        <translation>Retombée de l&apos;analyseur</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="266"/>
        <location filename="../mainvisual.cpp" line="280"/>
        <source>Slowest</source>
        <translation>Très lente</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="267"/>
        <location filename="../mainvisual.cpp" line="281"/>
        <source>Slow</source>
        <translation>Lente</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="268"/>
        <location filename="../mainvisual.cpp" line="282"/>
        <source>Medium</source>
        <translation>Moyenne</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="269"/>
        <location filename="../mainvisual.cpp" line="283"/>
        <source>Fast</source>
        <translation>Rapide</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="270"/>
        <location filename="../mainvisual.cpp" line="284"/>
        <source>Fastest</source>
        <translation>Très rapide</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="277"/>
        <source>Peaks Falloff</source>
        <translation>Retombée des pics</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="290"/>
        <source>Background</source>
        <translation>Arrière-plan</translation>
    </message>
    <message>
        <location filename="../mainvisual.cpp" line="291"/>
        <source>Transparent</source>
        <translation>Transparent</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="359"/>
        <source>Appearance</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="360"/>
        <source>Shortcuts</source>
        <translation>Raccourcis</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="430"/>
        <source>View</source>
        <translation>Vue</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="439"/>
        <source>Playlist</source>
        <translation>Liste</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="466"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="474"/>
        <source>Tools</source>
        <translation>Outils</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="556"/>
        <source>Qmmp</source>
        <translation>Qmmp</translation>
    </message>
</context>
<context>
    <name>PlayList</name>
    <message>
        <location filename="../playlist.cpp" line="56"/>
        <source>Playlist</source>
        <translation>Liste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="197"/>
        <source>&amp;Copy Selection To</source>
        <translation>&amp;Copier la sélection vers</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="228"/>
        <source>Sort List</source>
        <translation>Trier la liste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="231"/>
        <location filename="../playlist.cpp" line="271"/>
        <source>By Title</source>
        <translation>par titre</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="234"/>
        <location filename="../playlist.cpp" line="274"/>
        <source>By Album</source>
        <translation>par album</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="255"/>
        <location filename="../playlist.cpp" line="295"/>
        <source>By Disc Number</source>
        <translation>par numéro de disque</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="237"/>
        <location filename="../playlist.cpp" line="277"/>
        <source>By Artist</source>
        <translation>par artiste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="240"/>
        <location filename="../playlist.cpp" line="280"/>
        <source>By Album Artist</source>
        <translation>par artiste d&apos;album</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="243"/>
        <location filename="../playlist.cpp" line="283"/>
        <source>By Filename</source>
        <translation>par nom de fichier</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="246"/>
        <location filename="../playlist.cpp" line="286"/>
        <source>By Path + Filename</source>
        <translation>par emplacement + nom de fichier</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="249"/>
        <location filename="../playlist.cpp" line="289"/>
        <source>By Date</source>
        <translation>par date</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="252"/>
        <location filename="../playlist.cpp" line="292"/>
        <source>By Track Number</source>
        <translation>par numéro de piste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="258"/>
        <location filename="../playlist.cpp" line="298"/>
        <source>By File Creation Date</source>
        <translation>par date de création du fichier</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="261"/>
        <location filename="../playlist.cpp" line="301"/>
        <source>By File Modification Date</source>
        <translation>par date de modification du fichier</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="264"/>
        <source>By Group</source>
        <translation>par groupe</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="269"/>
        <source>Sort Selection</source>
        <translation>Trier la sélection</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="306"/>
        <source>Randomize List</source>
        <translation>Mélanger la liste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="308"/>
        <source>Reverse List</source>
        <translation>Inverser la liste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="315"/>
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="590"/>
        <source>Rename Playlist</source>
        <translation>Renommer la liste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="590"/>
        <source>Playlist name:</source>
        <translation>Nom de la liste : </translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="611"/>
        <source>&amp;New PlayList</source>
        <translation>&amp;Nouvelle liste</translation>
    </message>
</context>
<context>
    <name>PlayListBrowser</name>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="14"/>
        <source>Playlist Browser</source>
        <translation>Navigateur de liste</translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="31"/>
        <source>Filter:</source>
        <translation>Filtre : </translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="47"/>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="54"/>
        <location filename="../playlistbrowser.cpp" line="43"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../forms/playlistbrowser.ui" line="61"/>
        <location filename="../forms/playlistbrowser.ui" line="71"/>
        <source>...</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../playlistbrowser.cpp" line="42"/>
        <source>Rename</source>
        <translation>Renommer</translation>
    </message>
</context>
<context>
    <name>PlayListHeader</name>
    <message>
        <location filename="../playlistheader.cpp" line="77"/>
        <source>Add Column</source>
        <translation>Ajouter une colonne</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="78"/>
        <source>Edit Column</source>
        <translation>Éditer la colonne</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="79"/>
        <source>Show Queue/Protocol</source>
        <translation>Montrer la file / le protocole</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="81"/>
        <source>Auto-resize</source>
        <translation>Redimensionnement automatique</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="84"/>
        <source>Alignment</source>
        <translation>Alignement</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="85"/>
        <source>Left</source>
        <comment>alignment</comment>
        <translation>Gauche</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="86"/>
        <source>Right</source>
        <comment>alignment</comment>
        <translation>Droite</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="87"/>
        <source>Center</source>
        <comment>alignment</comment>
        <translation>Centre</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="97"/>
        <source>Remove Column</source>
        <translation>Supprimer la colonne</translation>
    </message>
</context>
<context>
    <name>PopupSettings</name>
    <message>
        <location filename="../forms/popupsettings.ui" line="14"/>
        <source>Popup Information Settings</source>
        <translation>Fenêtre d&apos;information de la configuration</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="29"/>
        <source>Template</source>
        <translation>Patron</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="58"/>
        <source>Reset</source>
        <translation>Remise à zéro</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="65"/>
        <source>Insert</source>
        <translation>Insérer</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="75"/>
        <source>Show cover</source>
        <translation>Montrer la couverture</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="89"/>
        <source>Cover size:</source>
        <translation>Taille de la couverture : </translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="115"/>
        <source>Transparency:</source>
        <translation>Transparence : </translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="145"/>
        <source>Delay:</source>
        <translation>Délai : </translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="178"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
</context>
<context>
    <name>PresetEditor</name>
    <message>
        <location filename="../forms/preseteditor.ui" line="14"/>
        <source>Preset Editor</source>
        <translation>Éditeur de réglages</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="36"/>
        <source>Preset</source>
        <translation>Réglage</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="52"/>
        <source>Auto-preset</source>
        <translation>Réglage auto</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="77"/>
        <source>Load</source>
        <translation>Charger</translation>
    </message>
    <message>
        <location filename="../forms/preseteditor.ui" line="84"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="14"/>
        <source>Change Shortcut</source>
        <translation>Changer le raccourci</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="29"/>
        <source>Press the key combination you want to assign</source>
        <translation>Appuyer sur la combinaison de touches que vous voulez assigner</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="52"/>
        <source>Clear</source>
        <translation>Effacer</translation>
    </message>
</context>
<context>
    <name>SkinnedFactory</name>
    <message>
        <location filename="../skinnedfactory.cpp" line="35"/>
        <source>Skinned User Interface</source>
        <translation>Thème d&apos;interface</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="61"/>
        <source>About Qmmp Skinned User Interface</source>
        <translation>À propos du thème d&apos;interface Qmmp</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="62"/>
        <source>Qmmp Skinned User Interface</source>
        <translation>Thème d&apos;interface Qmmp</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="63"/>
        <source>Simple user interface with Winamp-2.x/XMMS skins support</source>
        <translation>Simple interface avec support des thèmes Winamp-2.x / XMMS</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="64"/>
        <source>Written by:</source>
        <translation>Écrit par&#xa0;:</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="65"/>
        <source>Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;</source>
        <translation>Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="66"/>
        <source>Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="67"/>
        <source>Artwork:</source>
        <translation>Conception graphique : </translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="68"/>
        <source>Andrey Adreev &lt;andreev00@gmail.com&gt;</source>
        <translation>Andrey Adreev &lt;andreev00@gmail.com&gt;</translation>
    </message>
    <message>
        <location filename="../skinnedfactory.cpp" line="69"/>
        <source>sixsixfive &lt;http://sixsixfive.deviantart.com/&gt;</source>
        <translation>sixsixfive &lt;http://sixsixfive.deviantart.com/&gt;</translation>
    </message>
</context>
<context>
    <name>SkinnedSettings</name>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="24"/>
        <source>Skins</source>
        <translation>Thèmes</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="55"/>
        <source>Add...</source>
        <translation>Ajouter…</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="72"/>
        <source>Refresh</source>
        <translation>Rafraîchir</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="103"/>
        <source>Main Window</source>
        <translation>Fenêtre principale</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="109"/>
        <source>Hide on close</source>
        <translation>Masquer à la fermeture</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="116"/>
        <source>Start hidden</source>
        <translation>Démarrer masqué</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="123"/>
        <source>Use skin cursors</source>
        <translation>Utiliser les pointeurs du thème</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="261"/>
        <source>Single Column Mode</source>
        <translation>Mode colonne unique</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="308"/>
        <source>Show splitters</source>
        <translation>Afficher les séparateurs</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="315"/>
        <source>Alternate splitter color</source>
        <translation>Séparateur de couleur alterné</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="415"/>
        <source>Colors</source>
        <translation>Couleurs</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="421"/>
        <source>Playlist Colors</source>
        <translation>Couleurs des listes</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="427"/>
        <source>Use skin colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="520"/>
        <source>Background #2:</source>
        <translation>Arrière-plan n°2 :</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="584"/>
        <source>Highlighted background:</source>
        <translation>Arrière-plan en surbrillance&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="488"/>
        <source>Normal text:</source>
        <translation>Texte normal&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="651"/>
        <source>Splitter:</source>
        <translation>Séparateur:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="552"/>
        <source>Current text:</source>
        <translation>Texte actuel&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="616"/>
        <source>Highlighted text:</source>
        <translation>Texte en surbrillance&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="759"/>
        <source>Current track background:</source>
        <translation>Fond de la piste courante</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="861"/>
        <source>Override current track background</source>
        <translation>Remplacer le fond de la piste courante</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="724"/>
        <source>Group background:</source>
        <translation>Arrière-plan de groupe&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="854"/>
        <source>Override group background</source>
        <translation>Remplacer le fond du groupe</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="692"/>
        <source>Group text:</source>
        <translation>Texte de groupe&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="443"/>
        <source>Background #1:</source>
        <translation>Arrière-plan n°1&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="819"/>
        <source>Load skin colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="888"/>
        <source>Fonts</source>
        <translation>Polices</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="942"/>
        <source>Playlist:</source>
        <translation>Liste : </translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="978"/>
        <source>Column headers:</source>
        <translation>Noms des colonnes&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="900"/>
        <source>Player:</source>
        <translation>Lecteur : </translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="922"/>
        <location filename="../forms/skinnedsettings.ui" line="964"/>
        <location filename="../forms/skinnedsettings.ui" line="991"/>
        <source>???</source>
        <translation>???</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="142"/>
        <location filename="../forms/skinnedsettings.ui" line="929"/>
        <location filename="../forms/skinnedsettings.ui" line="971"/>
        <location filename="../forms/skinnedsettings.ui" line="998"/>
        <source>...</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="1020"/>
        <source>Reset fonts</source>
        <translation>Réinitialiser les polices</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="1029"/>
        <source>Use bitmap font if available</source>
        <translation>Utiliser une police matricielle si disponible</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="132"/>
        <source>Window title format:</source>
        <translation>Format du titre de la fenêtre&#xa0;:</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="97"/>
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="154"/>
        <source>Transparency</source>
        <translation>Transparence</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="160"/>
        <source>Main window</source>
        <translation>Fenêtre principale</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="183"/>
        <location filename="../forms/skinnedsettings.ui" line="207"/>
        <location filename="../forms/skinnedsettings.ui" line="231"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="190"/>
        <source>Equalizer</source>
        <translation>Égaliseur</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="214"/>
        <source>Playlist</source>
        <translation>Liste</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="255"/>
        <source>Song Display</source>
        <translation>Affichage du morceau</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="294"/>
        <source>Show protocol</source>
        <translation>Montrer le protocole</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="274"/>
        <source>Show song lengths</source>
        <translation>Montrer les durées des morceaux</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="267"/>
        <source>Show song numbers</source>
        <translation>Montrer les numéros des morceaux</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="284"/>
        <source>Align song numbers</source>
        <translation>Aligner les numéros de morceaux</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="301"/>
        <source>Show anchor</source>
        <translation>Montrer l&apos;ancre</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="363"/>
        <source>Show popup information</source>
        <translation>Montrer les fenêtre d&apos;information</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="375"/>
        <source>Edit template</source>
        <translation>Éditer le patron</translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="331"/>
        <source>Playlist separator:</source>
        <translation>Séparateur de liste : </translation>
    </message>
    <message>
        <location filename="../forms/skinnedsettings.ui" line="322"/>
        <source>Show &apos;New Playlist&apos; button</source>
        <translation>Montrer le bouton « Nouvelle liste »</translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="106"/>
        <source>Select Skin Files</source>
        <translation>Sélectionner les fichiers d&apos;un thème</translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="107"/>
        <source>Skin files</source>
        <translation>Fichiers d&apos;un thème</translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="186"/>
        <source>Unarchived skin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../skinnedsettings.cpp" line="186"/>
        <source>Archived skin %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextScroller</name>
    <message>
        <location filename="../textscroller.cpp" line="55"/>
        <source>Autoscroll Songname</source>
        <translation>Défilement automatique du nom du morceau</translation>
    </message>
    <message>
        <location filename="../textscroller.cpp" line="56"/>
        <source>Transparent Background</source>
        <translation>Arrière-plan transparent</translation>
    </message>
    <message>
        <location filename="../textscroller.cpp" line="127"/>
        <source>Buffering: %1%</source>
        <translation>Mise en tampon : %1 %</translation>
    </message>
</context>
<context>
    <name>VisualMenu</name>
    <message>
        <location filename="../visualmenu.cpp" line="26"/>
        <source>Visualization</source>
        <translation>Visualisation</translation>
    </message>
</context>
</TS>
