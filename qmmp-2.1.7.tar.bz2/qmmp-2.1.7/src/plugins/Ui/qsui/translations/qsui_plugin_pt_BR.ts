<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>AboutQSUIDialog</name>
    <message>
        <location filename="../forms/aboutqsuidialog.ui" line="14"/>
        <source>About QSUI</source>
        <translation>Sobre QSUI</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="41"/>
        <source>Qmmp Simple User Interface (QSUI)</source>
        <translation>Interface de usuário Qmmp (QSUI)</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="42"/>
        <source>Qmmp version: &lt;b&gt;%1&lt;/b&gt;</source>
        <translation>Versão Qmmp: &lt;b&gt;%1&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="46"/>
        <source>Developers:</source>
        <translation>Programadores:</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="47"/>
        <source>Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="49"/>
        <source>Translators:</source>
        <translation>Tradutores:</translation>
    </message>
    <message>
        <location filename="../aboutqsuidialog.cpp" line="44"/>
        <source>Simple user interface based on standard widgets set.</source>
        <translation>Interface de usuário baseada nos widgets padrão.</translation>
    </message>
</context>
<context>
    <name>ActionManager</name>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>&amp;Play</source>
        <translation>Re&amp;produzir</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="43"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>&amp;Pause</source>
        <translation>P&amp;ausa</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="44"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>&amp;Stop</source>
        <translation>Pa&amp;rar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="45"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>&amp;Previous</source>
        <translation>An&amp;terior</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="46"/>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>&amp;Next</source>
        <translation>Próxi&amp;mo</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="47"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>&amp;Play/Pause</source>
        <translation>Re&amp;produzir/pausa</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="48"/>
        <source>Space</source>
        <translation>Espaço</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>&amp;Jump to Track</source>
        <translation>&amp;Ir para faixa</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="49"/>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>&amp;Play Files</source>
        <translation>Re&amp;produzir arquivos</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="50"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="51"/>
        <source>&amp;Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>&amp;Repeat Playlist</source>
        <translation>Repetir &amp;lista de reprodução</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="52"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>&amp;Repeat Track</source>
        <translation>&amp;Repetir faixa</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="53"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;Embaralhar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="54"/>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>&amp;No Playlist Advance</source>
        <translation>Sem avanço &amp;na lista de reprodução</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="55"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="56"/>
        <source>&amp;Transit between playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>&amp;Stop After Selected</source>
        <translation>Parar após a &amp;seleção</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="57"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>&amp;Clear Queue</source>
        <translation>Limpar fila de reproduçã&amp;o</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="58"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="60"/>
        <source>Always on Top</source>
        <translation>Sempre na frente</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="61"/>
        <source>Put on All Workspaces</source>
        <translation>Mostrar em todas as áreas de trabalho</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="67"/>
        <source>Show Tabs</source>
        <translation>Mostrar abas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="68"/>
        <source>Show Title Bars</source>
        <translation>Mostrar barra de título</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="69"/>
        <source>Block Toolbars</source>
        <translation>Bloquear barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="71"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="72"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>&amp;Mute</source>
        <translation>&amp;Silenciar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="73"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>&amp;Add File</source>
        <translation>&amp;Adicionar arquivo</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="75"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>&amp;Add Directory</source>
        <translation>A&amp;dicionar pasta</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="76"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>&amp;Add Url</source>
        <translation>Adicionar &amp;URL</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="77"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Remover selecionados</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="78"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="79"/>
        <source>&amp;Remove All</source>
        <translation>&amp;Remover tudo</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="80"/>
        <source>&amp;Remove Unselected</source>
        <translation>Remover &amp;não selecionados</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="81"/>
        <source>Remove unavailable files</source>
        <translation>Remover arquivos indisponíveis</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="82"/>
        <source>Remove duplicates</source>
        <translation>Remover duplicados</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="83"/>
        <source>Refresh</source>
        <translation>Atualizar</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>&amp;Queue Toggle</source>
        <translation>A&amp;lternar fila de reprodução</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="84"/>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="85"/>
        <source>Invert Selection</source>
        <translation>Inverter seleção</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="86"/>
        <source>&amp;Select None</source>
        <translation>De&amp;smarcar tudo</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>&amp;Select All</source>
        <translation>&amp;Selecionar todos</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="87"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>&amp;View Track Details</source>
        <translation>&amp;Ver detalhes da faixa</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="88"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>&amp;New List</source>
        <translation>&amp;Nova lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="89"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>&amp;Delete List</source>
        <translation>&amp;Apagar lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="90"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>&amp;Load List</source>
        <translation>Carregar &amp;lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="91"/>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>&amp;Save List</source>
        <translation>Salvar li&amp;sta</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="92"/>
        <source>Shift+S</source>
        <translation>Shift+S</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>&amp;Rename List</source>
        <translation>&amp;Renomear lista</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="93"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>&amp;Select Next Playlist</source>
        <translation>&amp;Selecionar próxima lista de reprodução</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="94"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+PgDown</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>&amp;Select Previous Playlist</source>
        <translation>Selecionar lista de reprodução a&amp;nterior</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="95"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+PgUp</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="96"/>
        <source>&amp;Group Tracks</source>
        <translation>A&amp;grupar faixas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="97"/>
        <source>&amp;Show Column Headers</source>
        <translation>Mo&amp;strar cabeçalhos de colunas</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="99"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizador</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="99"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>&amp;Settings</source>
        <translation>Preferência&amp;s</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="100"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="101"/>
        <source>Application Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="102"/>
        <source>&amp;About Ui</source>
        <translation>Sobre &amp;UI</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="103"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="104"/>
        <source>&amp;About Qt</source>
        <translation>Sobre &amp;Qt</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="105"/>
        <source>&amp;Exit</source>
        <translation>S&amp;air</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="105"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../actionmanager.cpp" line="324"/>
        <source>Toolbar</source>
        <translation>Barra de ferramentas</translation>
    </message>
</context>
<context>
    <name>ColorWidget</name>
    <message>
        <location filename="../colorwidget.cpp" line="47"/>
        <source>Select Color</source>
        <translation>Selecionar cor</translation>
    </message>
</context>
<context>
    <name>CoverWidget</name>
    <message>
        <location filename="../coverwidget.cpp" line="32"/>
        <source>&amp;Save As...</source>
        <translation>Salvar &amp;como...</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="65"/>
        <source>Save Cover As</source>
        <translation>Salvar capa como</translation>
    </message>
    <message>
        <location filename="../coverwidget.cpp" line="67"/>
        <source>Images</source>
        <translation>Imagens</translation>
    </message>
</context>
<context>
    <name>Equalizer</name>
    <message>
        <location filename="../equalizer.cpp" line="39"/>
        <source>Equalizer</source>
        <translation>Equalizador</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="48"/>
        <source>Enable equalizer</source>
        <translation>Ativar equalizador</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="54"/>
        <source>Preset:</source>
        <translation>Pré-ajuste:</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="62"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="66"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="70"/>
        <source>Reset</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="83"/>
        <source>Preamp</source>
        <translation>Amplificador</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="100"/>
        <location filename="../equalizer.cpp" line="197"/>
        <source>%1dB</source>
        <translation>%1dB</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="102"/>
        <location filename="../equalizer.cpp" line="195"/>
        <source>+%1dB</source>
        <translation>+%1dB</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="150"/>
        <source>preset</source>
        <translation>pré-ajuste</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="220"/>
        <source>Overwrite Request</source>
        <translation>Substituição</translation>
    </message>
    <message>
        <location filename="../equalizer.cpp" line="221"/>
        <source>Preset &apos;%1&apos; already exists. Overwrite?</source>
        <translation>O pré-ajuste %1 já existe. Substituir?</translation>
    </message>
</context>
<context>
    <name>FileSystemBrowser</name>
    <message>
        <location filename="../filesystembrowser.cpp" line="91"/>
        <source>Add to Playlist</source>
        <translation>Adicionar à lista de reprodução</translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="93"/>
        <source>Change Directory</source>
        <translation>Mudar pasta</translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="98"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filesystembrowser.cpp" line="172"/>
        <source>Select Directory</source>
        <translation>Selecionar pasta</translation>
    </message>
</context>
<context>
    <name>HotkeyEditor</name>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="40"/>
        <source>Reset</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="54"/>
        <source>Action</source>
        <translation>Ação</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="59"/>
        <source>Shortcut</source>
        <translation>Atalho</translation>
    </message>
    <message>
        <location filename="../forms/hotkeyeditor.ui" line="33"/>
        <source>Change shortcut...</source>
        <translation>Mudar atalho...</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="55"/>
        <source>Reset Shortcuts</source>
        <translation>Restaurar atalhos</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="56"/>
        <source>Do you want to restore default shortcuts?</source>
        <translation>Gostaria de restaurar os atalhos originais?</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="68"/>
        <source>Playback</source>
        <translation>Reprodução</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="74"/>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="80"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="86"/>
        <source>Playlist</source>
        <translation>Lista de reprodução</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="92"/>
        <source>Misc</source>
        <translation>Diversos</translation>
    </message>
    <message>
        <location filename="../hotkeyeditor.cpp" line="100"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../forms/mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="958"/>
        <source>Qmmp</source>
        <translation>Qmmp</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="35"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="40"/>
        <source>&amp;Tools</source>
        <translation>Ferramen&amp;tas</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="45"/>
        <source>&amp;Help</source>
        <translation>Aj&amp;uda</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="50"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="55"/>
        <source>&amp;Playback</source>
        <translation>Re&amp;produção</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="60"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="99"/>
        <source>Files</source>
        <translation>Arquivos</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="114"/>
        <source>Cover</source>
        <translation>Capa de álbum</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="123"/>
        <source>Playlists</source>
        <translation>Listas de reprodução</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="135"/>
        <source>Waveform Seek Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="149"/>
        <source>Previous</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="159"/>
        <source>Play</source>
        <translation>Reproduzir</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="169"/>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="179"/>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="189"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="194"/>
        <source>&amp;Add File</source>
        <translation>&amp;Adicionar arquivo</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="199"/>
        <source>&amp;Remove All</source>
        <translation>&amp;Remover tudo</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="204"/>
        <source>New Playlist</source>
        <translation>Nova lista de reprodução</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="209"/>
        <source>Remove Playlist</source>
        <translation>Remover lista de reprodução</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="214"/>
        <source>&amp;Add Directory</source>
        <translation>A&amp;dicionar pasta</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="219"/>
        <source>&amp;Exit</source>
        <translation>S&amp;air</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="224"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="229"/>
        <source>About Qt</source>
        <translation>Sobre Qt</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="234"/>
        <source>&amp;Select All</source>
        <translation>&amp;Selecionar tudo</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="239"/>
        <source>&amp;Remove Selected</source>
        <translation>&amp;Remover selecionados</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="244"/>
        <source>&amp;Remove Unselected</source>
        <translation>Remover &amp;não selecionados</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="84"/>
        <location filename="../forms/mainwindow.ui" line="249"/>
        <source>Visualization</source>
        <translation>Visualização</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="254"/>
        <source>Settings</source>
        <translation>Preferências</translation>
    </message>
    <message>
        <location filename="../forms/mainwindow.ui" line="259"/>
        <location filename="../mainwindow.cpp" line="281"/>
        <source>Rename Playlist</source>
        <translation>Renomear lista de reprodução</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="472"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="281"/>
        <source>Playlist name:</source>
        <translation>Nome da lista de reprodução:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="322"/>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="323"/>
        <source>Shortcuts</source>
        <translation>Atalhos</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="402"/>
        <source>Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="459"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="465"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="470"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="474"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="532"/>
        <source>Edit Toolbars</source>
        <translation>Editar barras de ferramentas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="534"/>
        <source>Sort List</source>
        <translation>Organizar lista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="537"/>
        <location filename="../mainwindow.cpp" line="578"/>
        <source>By Title</source>
        <translation>Por título</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="540"/>
        <location filename="../mainwindow.cpp" line="581"/>
        <source>By Album</source>
        <translation>Por álbum</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="543"/>
        <location filename="../mainwindow.cpp" line="584"/>
        <source>By Artist</source>
        <translation>Por artista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="546"/>
        <location filename="../mainwindow.cpp" line="587"/>
        <source>By Album Artist</source>
        <translation>Por artista do álbum</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="549"/>
        <location filename="../mainwindow.cpp" line="590"/>
        <source>By Filename</source>
        <translation>Por nome de arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>By Path + Filename</source>
        <translation>Por caminho e nome de arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="555"/>
        <location filename="../mainwindow.cpp" line="596"/>
        <source>By Date</source>
        <translation>Por data</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="558"/>
        <location filename="../mainwindow.cpp" line="599"/>
        <source>By Track Number</source>
        <translation>Por número de faixa</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="561"/>
        <location filename="../mainwindow.cpp" line="602"/>
        <source>By Disc Number</source>
        <translation>Por número de disco</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="564"/>
        <location filename="../mainwindow.cpp" line="605"/>
        <source>By File Creation Date</source>
        <translation>Por data de criação do arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="567"/>
        <location filename="../mainwindow.cpp" line="608"/>
        <source>By File Modification Date</source>
        <translation>Por data de modificação do arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="570"/>
        <source>By Group</source>
        <translation>Por grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="575"/>
        <source>Sort Selection</source>
        <translation>Organizar seleção</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="613"/>
        <source>Randomize List</source>
        <translation>Lista aleatória</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <source>Reverse List</source>
        <translation>Inverter lista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="665"/>
        <source>Actions</source>
        <translation>Ações</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="421"/>
        <source>Add new playlist</source>
        <translation>Adicionar nova lista de reprodução</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="427"/>
        <source>Show all tabs</source>
        <translation>Mostrar todos as abas</translation>
    </message>
</context>
<context>
    <name>PlayListBrowser</name>
    <message>
        <location filename="../playlistbrowser.cpp" line="62"/>
        <source>Quick Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListHeader</name>
    <message>
        <location filename="../playlistheader.cpp" line="55"/>
        <source>Add Column</source>
        <translation>Adicionar coluna</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="56"/>
        <source>Edit Column</source>
        <translation>Editar coluna</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="57"/>
        <source>Show Queue/Protocol</source>
        <translation>Mostrar fila/protocolo</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="59"/>
        <source>Auto-resize</source>
        <translation>Ajuste automático</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="62"/>
        <source>Alignment</source>
        <translation>Alinhamento</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="63"/>
        <source>Left</source>
        <comment>alignment</comment>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="64"/>
        <source>Right</source>
        <comment>alignment</comment>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="65"/>
        <source>Center</source>
        <comment>alignment</comment>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../playlistheader.cpp" line="75"/>
        <source>Remove Column</source>
        <translation>Remover coluna</translation>
    </message>
</context>
<context>
    <name>PopupSettings</name>
    <message>
        <location filename="../forms/popupsettings.ui" line="14"/>
        <source>Popup Information Settings</source>
        <translation>Definições do alerta de informações</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="29"/>
        <source>Template</source>
        <translation>Modelo</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="58"/>
        <source>Reset</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="65"/>
        <source>Insert</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="75"/>
        <source>Show cover</source>
        <translation>Mostrar capa de álbum</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="89"/>
        <source>Cover size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="115"/>
        <source>Transparency:</source>
        <translation>Transparência:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="145"/>
        <source>Delay:</source>
        <translation>Atraso:</translation>
    </message>
    <message>
        <location filename="../forms/popupsettings.ui" line="165"/>
        <source>ms</source>
        <translation>ms</translation>
    </message>
</context>
<context>
    <name>QSUISettings</name>
    <message>
        <location filename="../forms/qsuisettings.ui" line="24"/>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="36"/>
        <source>Hide on close</source>
        <translation>Ocultar ao fechar</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="43"/>
        <source>Start hidden</source>
        <translation>Iniciar oculto</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="206"/>
        <source>Visualization Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="212"/>
        <source>Color #1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="279"/>
        <source>Color #2:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="343"/>
        <source>Color #3:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="432"/>
        <source>Reset colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="873"/>
        <source>Waveform Seekbar Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="879"/>
        <source>Progress bar:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="968"/>
        <source>RMS:</source>
        <extracomment>Root mean square</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1013"/>
        <source>Waveform:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1054"/>
        <source>Fonts</source>
        <translation>Tipo de letra</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1060"/>
        <source>Use system fonts</source>
        <translation>Utilizar tipo de letra do sistema</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1108"/>
        <source>Playlist:</source>
        <translation>Lista de reprodução:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1088"/>
        <location filename="../forms/qsuisettings.ui" line="1153"/>
        <location filename="../forms/qsuisettings.ui" line="1172"/>
        <source>???</source>
        <translation>???</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="62"/>
        <location filename="../forms/qsuisettings.ui" line="1095"/>
        <location filename="../forms/qsuisettings.ui" line="1118"/>
        <location filename="../forms/qsuisettings.ui" line="1179"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="30"/>
        <source>Main Window</source>
        <translation>Janela principal</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="52"/>
        <source>Window title format:</source>
        <translation>Formato de título da janela:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="74"/>
        <source>Song Display</source>
        <translation>Exibição de faixas</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="80"/>
        <source>Show protocol</source>
        <translation>Mostrar protocolo</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="144"/>
        <source>Show song numbers</source>
        <translation>Mostrar número da faixa</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="151"/>
        <source>Show song lengths</source>
        <translation>Mostrar duração da faixa</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="161"/>
        <source>Align song numbers</source>
        <translation>Alinhar número das faixas</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="87"/>
        <source>Show anchor</source>
        <translation>Mostrar âncora</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="101"/>
        <source>Show popup information</source>
        <translation>Mostrar alerta de informações</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="113"/>
        <source>Edit template</source>
        <translation>Editar modelo</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1201"/>
        <source>Reset fonts</source>
        <translation>Restaurar tipo de letra</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1216"/>
        <source>Column headers:</source>
        <translation>Cabeçalhos de colunas: </translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1131"/>
        <source>Tab names:</source>
        <translation>Nome das abas:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1243"/>
        <source>Miscellaneous</source>
        <translation>Diversos</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="94"/>
        <source>Show splitters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="138"/>
        <source>Single Column Mode</source>
        <translation>Modo de uma coluna</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="185"/>
        <source>Colors</source>
        <translation>Cores</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="247"/>
        <source>Peaks:</source>
        <translation>Picos:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="311"/>
        <location filename="../forms/qsuisettings.ui" line="961"/>
        <source>Background:</source>
        <translation>Fundo:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="444"/>
        <source>Playlist Colors</source>
        <translation>Cores da lista de reprodução</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="466"/>
        <source>Background #1:</source>
        <translation>Fundo #1:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="498"/>
        <source>Normal text:</source>
        <translation>Texto normal:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="530"/>
        <source>Background #2:</source>
        <translation>Fundo #2:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="562"/>
        <source>Current text:</source>
        <translation>Texto atual:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="594"/>
        <source>Highlighted background:</source>
        <translation>Destaque de fundo:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="626"/>
        <source>Highlighted text:</source>
        <translation>Destaque de texto:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="814"/>
        <source>Override current track background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="769"/>
        <source>Current track background:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="860"/>
        <source>Override group background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1276"/>
        <source>Tab position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1313"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1321"/>
        <source>Icon size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1346"/>
        <source>Customize...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="450"/>
        <source>Use system colors</source>
        <translation>Usar cores do sistema</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="734"/>
        <source>Group background:</source>
        <translation>Fundo do grupo:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="702"/>
        <source>Group text:</source>
        <translation>Texto do grupo:</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="661"/>
        <source>Splitter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1249"/>
        <source>Tabs</source>
        <translation>Abas</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1255"/>
        <source>Show close buttons</source>
        <translation>Mostrar botão de fechamento</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1262"/>
        <source>Show tab list menu</source>
        <translation>Mostrar menu de lista de separadores</translation>
    </message>
    <message>
        <location filename="../forms/qsuisettings.ui" line="1269"/>
        <source>Show &apos;New Playlist&apos; button</source>
        <translation>Mostrar botão &apos;Nova lista de reprodução&apos;</translation>
    </message>
</context>
<context>
    <name>QSUIVisualization</name>
    <message>
        <location filename="../qsuivisualization.cpp" line="126"/>
        <source>Cover</source>
        <translation type="unfinished">Capa de álbum</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="129"/>
        <source>Visualization Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="132"/>
        <source>Analyzer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="133"/>
        <source>Scope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="140"/>
        <source>Analyzer Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="142"/>
        <source>Cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="143"/>
        <source>Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="151"/>
        <source>Peaks</source>
        <translation type="unfinished">Picos</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="154"/>
        <source>Refresh Rate</source>
        <translation type="unfinished">Taxa de atualização</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="157"/>
        <source>50 fps</source>
        <translation type="unfinished">50 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="158"/>
        <source>25 fps</source>
        <translation type="unfinished">25 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="159"/>
        <source>10 fps</source>
        <translation type="unfinished">10 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="160"/>
        <source>5 fps</source>
        <translation type="unfinished">5 fps</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="167"/>
        <source>Analyzer Falloff</source>
        <translation type="unfinished">Queda do analisador</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="170"/>
        <location filename="../qsuivisualization.cpp" line="184"/>
        <source>Slowest</source>
        <translation type="unfinished">Mais lenta</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="171"/>
        <location filename="../qsuivisualization.cpp" line="185"/>
        <source>Slow</source>
        <translation type="unfinished">Lenta</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="172"/>
        <location filename="../qsuivisualization.cpp" line="186"/>
        <source>Medium</source>
        <translation type="unfinished">Média</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="173"/>
        <location filename="../qsuivisualization.cpp" line="187"/>
        <source>Fast</source>
        <translation type="unfinished">Rápida</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="174"/>
        <location filename="../qsuivisualization.cpp" line="188"/>
        <source>Fastest</source>
        <translation type="unfinished">Mais rápida</translation>
    </message>
    <message>
        <location filename="../qsuivisualization.cpp" line="181"/>
        <source>Peaks Falloff</source>
        <translation type="unfinished">Queda de picos</translation>
    </message>
</context>
<context>
    <name>QSUiFactory</name>
    <message>
        <location filename="../qsuifactory.cpp" line="32"/>
        <source>Simple User Interface</source>
        <translation type="unfinished">Interface de usuário simples</translation>
    </message>
</context>
<context>
    <name>QSUiSettings</name>
    <message>
        <location filename="../qsuisettings.cpp" line="43"/>
        <source>Default</source>
        <translation type="unfinished">Pré-definido</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="44"/>
        <source>16x16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="45"/>
        <source>22x22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="46"/>
        <source>32x32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="47"/>
        <source>48x48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="48"/>
        <source>64x64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="50"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="51"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="52"/>
        <source>Left</source>
        <translation type="unfinished">Esquerda</translation>
    </message>
    <message>
        <location filename="../qsuisettings.cpp" line="53"/>
        <source>Right</source>
        <translation type="unfinished">Direita</translation>
    </message>
</context>
<context>
    <name>QSUiStatusBar</name>
    <message>
        <location filename="../qsuistatusbar.cpp" line="68"/>
        <source>tracks: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="69"/>
        <source>total time: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="87"/>
        <source>Playing</source>
        <translation type="unfinished">Reprodução</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="87"/>
        <source>Paused</source>
        <translation type="unfinished">Pausado</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="102"/>
        <source>Buffering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="127"/>
        <source>Stopped</source>
        <translation type="unfinished">Parado</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="139"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="147"/>
        <source>Buffering: %1%</source>
        <translation type="unfinished">Processamento: %1%</translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="152"/>
        <source>%1 bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="154"/>
        <source>mono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="156"/>
        <source>stereo</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qsuistatusbar.cpp" line="158"/>
        <source>%n channels</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="159"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuistatusbar.cpp" line="164"/>
        <source>%1 kbps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSUiWaveformSeekBar</name>
    <message>
        <location filename="../qsuiwaveformseekbar.cpp" line="329"/>
        <source>2 Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qsuiwaveformseekbar.cpp" line="332"/>
        <source>RMS</source>
        <extracomment>Root mean square</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="14"/>
        <source>Change Shortcut</source>
        <translation>Mudar atalho</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="29"/>
        <source>Press the key combination you want to assign</source>
        <translation>Aperte a combinação de teclas que pretende atribuir</translation>
    </message>
    <message>
        <location filename="../forms/shortcutdialog.ui" line="52"/>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
</context>
<context>
    <name>ToolBarEditor</name>
    <message>
        <location filename="../forms/toolbareditor.ui" line="14"/>
        <source>ToolBar Editor</source>
        <translation>Editor da barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="62"/>
        <source>Reset</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="199"/>
        <source>Toolbar:</source>
        <translation>Barra de ferramentas:</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="222"/>
        <source>&amp;Create</source>
        <translation>&amp;Criar</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="238"/>
        <source>Re&amp;name</source>
        <translation>Re&amp;nomear</translation>
    </message>
    <message>
        <location filename="../forms/toolbareditor.ui" line="254"/>
        <source>&amp;Remove</source>
        <translation>&amp;Remover</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="100"/>
        <location filename="../toolbareditor.cpp" line="198"/>
        <source>Separator</source>
        <translation>Separador</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="248"/>
        <source>Toolbar</source>
        <translation>Barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="250"/>
        <source>Toolbar %1</source>
        <translation>Barra de ferramentas %1</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Rename Toolbar</source>
        <translation>Renomear barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="264"/>
        <source>Toolbar name:</source>
        <translation>Nome da barra de ferramentas:</translation>
    </message>
</context>
<context>
    <name>VisualMenu</name>
    <message>
        <location filename="../visualmenu.cpp" line="26"/>
        <source>Visualization</source>
        <translation>Visualização</translation>
    </message>
</context>
<context>
    <name>VolumeSlider</name>
    <message>
        <location filename="../volumeslider.cpp" line="91"/>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
</context>
</TS>
