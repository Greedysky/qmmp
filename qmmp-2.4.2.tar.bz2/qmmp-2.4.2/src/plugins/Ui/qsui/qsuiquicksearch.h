/***************************************************************************
 *   Copyright (C) 2017-2026 by Ilya Kotov                                 *
 *   forkotov02@ya.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.         *
 ***************************************************************************/

#ifndef QSUIQUICKSEARCH_H
#define QSUIQUICKSEARCH_H

#include <QWidget>
#include <QList>

class QLineEdit;
class PlayListManager;
class QSUiListWidget;

/**
    @author Ilya Kotov <forkotov02@ya.ru>
*/
class QSUiQuickSearch : public QWidget
{
    Q_OBJECT
public:
    explicit QSUiQuickSearch(QSUiListWidget *listWidget, QWidget *parent = nullptr);

private:
    QLineEdit *m_lineEdit;
    PlayListManager *m_manager;
    QSUiListWidget *m_listWidget;

};

#endif // QSUIQUICKSEARCH_H
