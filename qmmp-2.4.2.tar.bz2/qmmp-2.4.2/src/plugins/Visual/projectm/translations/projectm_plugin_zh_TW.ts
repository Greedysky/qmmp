<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>ProjectM4Widget</name>
    <message>
        <location filename="../projectm4window.cpp" line="161"/>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>&amp;Show Menu</source>
        <translation>&amp; 顯示功能表</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="161"/>
        <location filename="../projectm4window.cpp" line="163"/>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="163"/>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>&amp;Next Preset</source>
        <translation>下一個預設</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="164"/>
        <location filename="../projectm4window.cpp" line="173"/>
        <source>&amp;Previous Preset</source>
        <translation>上一個預設</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="164"/>
        <location filename="../projectm4window.cpp" line="173"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <location filename="../projectm4window.cpp" line="174"/>
        <source>&amp;Shuffle</source>
        <translation>亂序</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <location filename="../projectm4window.cpp" line="174"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="166"/>
        <location filename="../projectm4window.cpp" line="175"/>
        <source>&amp;Lock Preset</source>
        <translation>鎖定邊框形式(&amp;L)</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="166"/>
        <location filename="../projectm4window.cpp" line="175"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <location filename="../projectm4window.cpp" line="177"/>
        <source>&amp;Fullscreen</source>
        <translation>全屏(&amp;F)</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <location filename="../projectm4window.cpp" line="177"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>ProjectMPlugin</name>
    <message>
        <location filename="../projectmplugin.cpp" line="42"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
</context>
<context>
    <name>ProjectMWidget</name>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <location filename="../projectmwidget.cpp" line="158"/>
        <source>&amp;Help</source>
        <translation>幫助(&amp;H)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <location filename="../projectmwidget.cpp" line="158"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="147"/>
        <location filename="../projectmwidget.cpp" line="159"/>
        <source>&amp;Show Song Title</source>
        <translation>顯示曲目標題(&amp;S)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="147"/>
        <location filename="../projectmwidget.cpp" line="159"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>&amp;Show Preset Name</source>
        <translation>顯示邊框形式名稱(&amp;S)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>&amp;Show Menu</source>
        <translation>&amp; 顯示功能表</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>&amp;Next Preset</source>
        <translation>下一個預設</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="152"/>
        <location filename="../projectmwidget.cpp" line="164"/>
        <source>&amp;Previous Preset</source>
        <translation>上一個預設</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="152"/>
        <location filename="../projectmwidget.cpp" line="164"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>&amp;Random Preset</source>
        <translation>隨意邊框形式(&amp;R)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>&amp;Lock Preset</source>
        <translation>鎖定邊框形式(&amp;L)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>&amp;Fullscreen</source>
        <translation>全屏(&amp;F)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>VisualProjectMFactory</name>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="30"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="50"/>
        <source>About ProjectM Visual Plugin</source>
        <translation>關於 ProjectM 可視化插件</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="51"/>
        <source>Qmmp ProjectM Visual Plugin</source>
        <translation>Qmmp ProjectM 可視化插件</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="52"/>
        <source>This plugin adds projectM visualization</source>
        <translation>此插件添加 ProjectM 可視化</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="53"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>撰寫：Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="54"/>
        <source>Based on libprojectM-qt library</source>
        <translation>基於 libprojectM-qt 程式庫</translation>
    </message>
</context>
</TS>
