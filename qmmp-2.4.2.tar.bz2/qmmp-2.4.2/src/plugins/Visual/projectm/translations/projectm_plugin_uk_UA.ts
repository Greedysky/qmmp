<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk_UA">
<context>
    <name>ProjectM4Widget</name>
    <message>
        <location filename="../projectm4window.cpp" line="161"/>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>&amp;Show Menu</source>
        <translation>&amp;Показати меню</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="161"/>
        <location filename="../projectm4window.cpp" line="163"/>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="163"/>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>&amp;Next Preset</source>
        <translation>&amp;Наступний пресет</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="164"/>
        <location filename="../projectm4window.cpp" line="173"/>
        <source>&amp;Previous Preset</source>
        <translation>&amp;Попередній пресет</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="164"/>
        <location filename="../projectm4window.cpp" line="173"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <location filename="../projectm4window.cpp" line="174"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;Перемішати</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <location filename="../projectm4window.cpp" line="174"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="166"/>
        <location filename="../projectm4window.cpp" line="175"/>
        <source>&amp;Lock Preset</source>
        <translation>&amp;Заблокувати пресет</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="166"/>
        <location filename="../projectm4window.cpp" line="175"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <location filename="../projectm4window.cpp" line="177"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Повноекранно</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <location filename="../projectm4window.cpp" line="177"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>ProjectMPlugin</name>
    <message>
        <location filename="../projectmplugin.cpp" line="42"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
</context>
<context>
    <name>ProjectMWidget</name>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <location filename="../projectmwidget.cpp" line="158"/>
        <source>&amp;Help</source>
        <translation>&amp;Довідка</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <location filename="../projectmwidget.cpp" line="158"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="147"/>
        <location filename="../projectmwidget.cpp" line="159"/>
        <source>&amp;Show Song Title</source>
        <translation>&amp;Показати назву пісні</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="147"/>
        <location filename="../projectmwidget.cpp" line="159"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>&amp;Show Preset Name</source>
        <translation>&amp;Показати ім&apos;я пресету</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>&amp;Show Menu</source>
        <translation>&amp;Показати меню</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>&amp;Next Preset</source>
        <translation>&amp;Наступний пресет</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="152"/>
        <location filename="../projectmwidget.cpp" line="164"/>
        <source>&amp;Previous Preset</source>
        <translation>&amp;Попередній пресет</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="152"/>
        <location filename="../projectmwidget.cpp" line="164"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>&amp;Random Preset</source>
        <translation>&amp;Випадковий пресет</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>&amp;Lock Preset</source>
        <translation>&amp;Заблокувати пресет</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Повноекранно</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>VisualProjectMFactory</name>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="30"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="50"/>
        <source>About ProjectM Visual Plugin</source>
        <translation>Про втулок ProjectM для Qmmp</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="51"/>
        <source>Qmmp ProjectM Visual Plugin</source>
        <translation>Втулок projectM для Qmmp</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="52"/>
        <source>This plugin adds projectM visualization</source>
        <translation>Цей втулок додає унаочнення projectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="53"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Розробник: Ілля Котов &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="54"/>
        <source>Based on libprojectM-qt library</source>
        <translation>Базується на бібліотеці libprojectM-qt</translation>
    </message>
</context>
</TS>
