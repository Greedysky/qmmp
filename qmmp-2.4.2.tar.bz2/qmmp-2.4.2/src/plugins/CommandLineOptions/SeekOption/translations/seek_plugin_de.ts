<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>SeekOption</name>
    <message>
        <location filename="../seekoption.cpp" line="29"/>
        <source>Seek to position in the current track</source>
        <translation>Zu Position im derzeitigen Titel spulen</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="30"/>
        <source>Seek forward</source>
        <translation>Vorwärts spulen</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="31"/>
        <source>Seek backwards</source>
        <translation>Rückwärts spulen</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="64"/>
        <source>Invalid position specified</source>
        <translation>Ungültige Position angegeben</translation>
    </message>
</context>
</TS>
