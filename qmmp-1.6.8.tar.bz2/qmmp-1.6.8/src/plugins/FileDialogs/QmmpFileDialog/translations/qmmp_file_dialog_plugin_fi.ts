<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fi">
<context>
    <name>QmmpFileDialog</name>
    <message>
        <location filename="../qmmpfiledialog.ui" line="14"/>
        <source>Add Files</source>
        <translation>Lisää tiedostoja</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="177"/>
        <source>Up</source>
        <translation>Ylös</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="180"/>
        <location filename="../qmmpfiledialog.ui" line="193"/>
        <location filename="../qmmpfiledialog.ui" line="212"/>
        <location filename="../qmmpfiledialog.ui" line="237"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="190"/>
        <source>List view</source>
        <translation>Listanäkymä</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="209"/>
        <source>Detailed view</source>
        <translation>Tietonäkymä</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="234"/>
        <source>Close dialog on add</source>
        <translation>Sulje ikkuna lisäyksen yhteydessä</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="106"/>
        <source>File name:</source>
        <translation>Tiedostonimi:</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="122"/>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="129"/>
        <source>Files of type:</source>
        <translation>Tiedostot tyyppiä:</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.ui" line="155"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
</context>
<context>
    <name>QmmpFileDialogFactory</name>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="70"/>
        <location filename="../qmmpfiledialog.cpp" line="80"/>
        <source>Qmmp File Dialog</source>
        <translation>Qmmp File Dialog</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="79"/>
        <source>About Qmmp File Dialog</source>
        <translation>Tietoja: Qmmp File Dialog</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="81"/>
        <source>Written by:
Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;
Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Kirjoittaneet:
Vladimir Kuznetsov &lt;vovanec@gmail.com&gt;
Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialog.cpp" line="84"/>
        <source>Some code is copied from the Qt library</source>
        <translation>Osa koodista on kopioitu Qt-kirjastosta</translation>
    </message>
</context>
<context>
    <name>QmmpFileDialogImpl</name>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="263"/>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="276"/>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="290"/>
        <source>Directories</source>
        <translation>Kansiot</translation>
    </message>
    <message>
        <location filename="../qmmpfiledialogimpl.cpp" line="480"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 on jo olemassa.
Haluatko korvata sen?</translation>
    </message>
</context>
</TS>
