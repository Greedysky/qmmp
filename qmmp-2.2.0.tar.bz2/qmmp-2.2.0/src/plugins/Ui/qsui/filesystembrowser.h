/***************************************************************************
 *   Copyright (C) 2013-2024 by Ilya Kotov                                 *
 *   forkotov02@ya.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.         *
 ***************************************************************************/

#ifndef FILESYSTEMBROWSER_H
#define FILESYSTEMBROWSER_H

#include <QWidget>

class QFileSystemModel;
class QModelIndex;
class QTreeView;
class QAction;
class QLineEdit;
class FileSystemFilterProxyModel;
class PlayListModel;

namespace Utils {
   class ElidingLabel;
}


/**
    @author Ilya Kotov <forkotov02@ya.ru>
*/
class FileSystemBrowser : public QWidget
{
    Q_OBJECT
public:
    explicit FileSystemBrowser(QWidget *parent = nullptr);
    ~FileSystemBrowser();

    void readSettings();

private slots:
    void onListViewActivated(const QModelIndex &index);
    void addToPlayList();
    void replacePlayList();
    void selectDirectory();
    void onFilterLineEditTextChanged(const QString &str);
    void setTreeViewMode(bool enabled);

private:
    QStringList selectedPaths() const;
    void setCurrentDirectory(const QString &path);
    bool m_update = false;
    Utils::ElidingLabel *m_label;
    QFileSystemModel *m_fileSystemModel;
    QTreeView *m_treeView;
    FileSystemFilterProxyModel *m_proxyModel;
    QLineEdit *m_filterLineEdit;
    QAction *m_showFilterAction;
    QAction *m_treeModeAction;
    QAction *m_sortAction;
};

#endif // FILESYSTEMBROWSER_H
