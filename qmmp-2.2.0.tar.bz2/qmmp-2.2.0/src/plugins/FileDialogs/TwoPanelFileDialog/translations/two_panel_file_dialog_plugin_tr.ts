<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr">
<context>
    <name>TwoPanelFileDialog</name>
    <message>
        <location filename="../twopanelfiledialog.ui" line="14"/>
        <source>Add Files</source>
        <translation>Dosya Ekle</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="70"/>
        <source>File name:</source>
        <translation>Dosya adı:</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="80"/>
        <source>Files of type:</source>
        <translation>Dosya tipi:</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="117"/>
        <source>Play</source>
        <translation>Oynat</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="130"/>
        <source>Add</source>
        <translation>Ekle</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.ui" line="143"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>TwoPanelFileDialogFactory</name>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="67"/>
        <location filename="../twopanelfiledialog.cpp" line="77"/>
        <source>Two-panel File Dialog</source>
        <translation>İki Panelli Dosya İletişim Kutusu</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="76"/>
        <source>About Two-panel File Dialog</source>
        <translation>İki Panelli Dosya İletişim Kutusu Hakkında</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="78"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Yazan: Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialog.cpp" line="79"/>
        <source>Based on code from the Qt library</source>
        <translation>Qt kitaplığındaki kodu temel alır</translation>
    </message>
</context>
<context>
    <name>TwoPanelFileDialogImpl</name>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="321"/>
        <location filename="../twopanelfiledialogimpl.cpp" line="337"/>
        <source>Add</source>
        <translation>Ekle</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="339"/>
        <source>Directories</source>
        <translation>Dizinler</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="351"/>
        <source>Save</source>
        <translation>Kaydet</translation>
    </message>
    <message>
        <location filename="../twopanelfiledialogimpl.cpp" line="457"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 zaten var.
Bunu değiştirmek istiyor musunuz?</translation>
    </message>
</context>
</TS>
