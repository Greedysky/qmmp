<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>BuiltinCommandLineOption</name>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="46"/>
        <source>Don&apos;t clear the playlist</source>
        <translation>不要清除這個播放清單</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="47"/>
        <source>Start playing current song</source>
        <translation>開始播放目前曲目</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="48"/>
        <source>Pause current song</source>
        <translation>暫停目前曲目</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="49"/>
        <source>Pause if playing, play otherwise</source>
        <translation>正在播放則暫停，相反處於暫停則播放</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="50"/>
        <source>Stop current song</source>
        <translation>停止目前曲目</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="51"/>
        <source>Display Jump to Track dialog</source>
        <translation>顯示跳轉至軌道對話框</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="52"/>
        <source>Quit application</source>
        <translation>退出應用程式</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="53"/>
        <source>Set playback volume (example: qmmp --volume 20)</source>
        <translation>設置回放音量 (例如：qmmp --volume 20)</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="54"/>
        <source>Print volume level</source>
        <translation>列印音量等級</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="55"/>
        <source>Mute/Restore volume</source>
        <translation>靜音/恢復音量</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="56"/>
        <source>Print mute status</source>
        <translation>列印靜音狀態</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="57"/>
        <source>Skip forward in playlist</source>
        <translation>跳到播放清單中的下一曲</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="58"/>
        <source>Skip backwards in playlist</source>
        <translation>跳到播放清單中的上一曲</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="59"/>
        <source>Show/hide application</source>
        <translation>察看/隱藏程式</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="60"/>
        <source>Show main window</source>
        <translation>顯示主視窗</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="61"/>
        <source>Display Add File dialog</source>
        <translation>察看添加文件對話</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="62"/>
        <source>Display Add Directory dialog</source>
        <translation>察看添加目錄對話</translation>
    </message>
</context>
<context>
    <name>QMMPStarter</name>
    <message>
        <location filename="../qmmpstarter.cpp" line="149"/>
        <source>Unknown command</source>
        <translation>未知指令</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="479"/>
        <source>Usage: qmmp [options] [files]</source>
        <translation>使用：qmmp [設定] [文件]</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="480"/>
        <source>Options:</source>
        <translation>設定：</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="486"/>
        <source>Start qmmp with the specified user interface</source>
        <translation>使用指定的使用者介面啟動 qmmp</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="487"/>
        <source>List all available user interfaces</source>
        <translation>列出所有可用的使用者介面</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="488"/>
        <source>Don&apos;t start the application</source>
        <translation>無法啟動此程式</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="489"/>
        <source>Print debugging messages</source>
        <translation>列印偵錯訊息</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="490"/>
        <source>Display this text and exit</source>
        <translation>察看這些字檔並結束</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="491"/>
        <source>Print version number and exit</source>
        <translation>察看版本並結束</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="493"/>
        <source>Home page: %1</source>
        <translation>首頁：%1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="494"/>
        <source>Development page: %1</source>
        <translation>開發頁面：%1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="495"/>
        <source>Bug tracker: %1</source>
        <translation>錯誤追蹤器：%1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="171"/>
        <location filename="../qmmpstarter.cpp" line="500"/>
        <source>Command Line Help</source>
        <translation>命令列幫助</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="513"/>
        <source>QMMP version: %1</source>
        <translation>QMP 版本：%1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="514"/>
        <source>Compiled with Qt version: %1</source>
        <translation>使用 Qt 版本編譯：%1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="515"/>
        <source>Using Qt version: %1</source>
        <translation>使用 Qt 版本：%1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="518"/>
        <source>Qmmp Version</source>
        <translation>Qmmp版本</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="535"/>
        <source>User Interfaces</source>
        <translation>使用者介面</translation>
    </message>
</context>
</TS>
