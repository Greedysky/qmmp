<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it">
<context>
    <name>BuiltinCommandLineOption</name>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="46"/>
        <source>Don&apos;t clear the playlist</source>
        <translation>Non ripulire la playlist</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="47"/>
        <source>Start playing current song</source>
        <translation>Inizia il brano scelto</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="48"/>
        <source>Pause current song</source>
        <translation>Sospendi il brano in riproduzione</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="49"/>
        <source>Pause if playing, play otherwise</source>
        <translation>Sospendi il brano se in riproduzione; lo riprende se in pausa</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="50"/>
        <source>Stop current song</source>
        <translation>Arresta il brano in esecuzione</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="51"/>
        <source>Display Jump to Track dialog</source>
        <translation>Mostra la finestra Passa alla traccia</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="52"/>
        <source>Quit application</source>
        <translation>Chiudi l&apos;applicazione</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="53"/>
        <source>Set playback volume (example: qmmp --volume 20)</source>
        <translation>Imposta il volume di riproduzione (esempio: qmmp --volume 20)</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="54"/>
        <source>Print volume level</source>
        <translation>Stampa il livello del volume</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="55"/>
        <source>Mute/Restore volume</source>
        <translation>Silenzia/ripristina volume</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="56"/>
        <source>Print mute status</source>
        <translation>Stampa lo stato del silenzio</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="57"/>
        <source>Skip forward in playlist</source>
        <translation>Scorri in avanti nella playlist</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="58"/>
        <source>Skip backwards in playlist</source>
        <translation>Scorri indietro nella playlist</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="59"/>
        <source>Show/hide application</source>
        <translation>Mostra/nascondi il programma</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="60"/>
        <source>Show main window</source>
        <translation>Mostra la finestra principale</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="61"/>
        <source>Display Add File dialog</source>
        <translation>Mostra il menu «Aggiungi file»</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="62"/>
        <source>Display Add Directory dialog</source>
        <translation>Mostra il menu «Aggiungi cartella»</translation>
    </message>
</context>
<context>
    <name>QMMPStarter</name>
    <message>
        <location filename="../qmmpstarter.cpp" line="149"/>
        <source>Unknown command</source>
        <translation>Comando sconosciuto</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="479"/>
        <source>Usage: qmmp [options] [files]</source>
        <translation>Uso: qmmp [opzioni] [file]</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="480"/>
        <source>Options:</source>
        <translation>Opzioni: </translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="486"/>
        <source>Start qmmp with the specified user interface</source>
        <translation>Avvia qmmp con l&apos;interfaccia utente specificata</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="487"/>
        <source>List all available user interfaces</source>
        <translation>Elenca tutte le interfacce utente disponibili</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="488"/>
        <source>Don&apos;t start the application</source>
        <translation>Non avviare l&apos;applicazione</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="489"/>
        <source>Print debugging messages</source>
        <translation>Stampa messaggi di debug</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="490"/>
        <source>Display this text and exit</source>
        <translation>Mostra questo testo ed esci</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="491"/>
        <source>Print version number and exit</source>
        <translation>Stampa il numero di versione ed esci</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="493"/>
        <source>Home page: %1</source>
        <translation>Pagina principale: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="494"/>
        <source>Development page: %1</source>
        <translation>Pagina di sviluppo: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="495"/>
        <source>Bug tracker: %1</source>
        <translation>Segnalazioni di bug: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="171"/>
        <location filename="../qmmpstarter.cpp" line="500"/>
        <source>Command Line Help</source>
        <translation>Aiuto a riga di comando</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="513"/>
        <source>QMMP version: %1</source>
        <translation>QMMP versione: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="514"/>
        <source>Compiled with Qt version: %1</source>
        <translation>Compilato con Qt versione: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="515"/>
        <source>Using Qt version: %1</source>
        <translation>Usa Qt versione: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="518"/>
        <source>Qmmp Version</source>
        <translation>Versione di Qmmp</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="535"/>
        <source>User Interfaces</source>
        <translation>Interfacce utente</translation>
    </message>
</context>
</TS>
