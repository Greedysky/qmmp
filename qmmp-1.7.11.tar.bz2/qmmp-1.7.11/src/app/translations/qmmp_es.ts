<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>BuiltinCommandLineOption</name>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="46"/>
        <source>Don&apos;t clear the playlist</source>
        <translation>No limpiar la lista de reproducción</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="47"/>
        <source>Start playing current song</source>
        <translation>Empezar reproduciendo la canción actual</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="48"/>
        <source>Pause current song</source>
        <translation>Pausar la canción actual</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="49"/>
        <source>Pause if playing, play otherwise</source>
        <translation>Pausar si se está reproduciendo, o viceversa</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="50"/>
        <source>Stop current song</source>
        <translation>Detener la canción actual</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="51"/>
        <source>Display Jump to Track dialog</source>
        <translation>Mostrar diálogo  Saltar a pista</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="52"/>
        <source>Quit application</source>
        <translation>Salir de aplicación</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="53"/>
        <source>Set playback volume (example: qmmp --volume 20)</source>
        <translation>Cambiar el volumen de reproducción (ejemplo: qmmp --volume 20)</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="54"/>
        <source>Print volume level</source>
        <translation>Mostrar nivel de volumen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="55"/>
        <source>Mute/Restore volume</source>
        <translation>Silenciar/Restaurar volumen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="56"/>
        <source>Print mute status</source>
        <translation>Mostrar estado de silencio</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="57"/>
        <source>Skip forward in playlist</source>
        <translation>Avanzar en la lista de reproducción</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="58"/>
        <source>Skip backwards in playlist</source>
        <translation>Retroceder en la lista de reproducción</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="59"/>
        <source>Show/hide application</source>
        <translation>Mostrar/ocultar aplicación</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="60"/>
        <source>Show main window</source>
        <translation>Mostrar ventana principal</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="61"/>
        <source>Display Add File dialog</source>
        <translation>Mostrar el diálogo Añadir archivo</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="62"/>
        <source>Display Add Directory dialog</source>
        <translation>Mostrar el diálogo Añadir directorio</translation>
    </message>
</context>
<context>
    <name>QMMPStarter</name>
    <message>
        <location filename="../qmmpstarter.cpp" line="149"/>
        <source>Unknown command</source>
        <translation>Comando desconocido</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="479"/>
        <source>Usage: qmmp [options] [files]</source>
        <translation>Uso: qmmp [opciones] [archivos]</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="480"/>
        <source>Options:</source>
        <translation>Opciones:</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="486"/>
        <source>Start qmmp with the specified user interface</source>
        <translation>Iniciar qmmp con la interfaz de usuario especificada</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="487"/>
        <source>List all available user interfaces</source>
        <translation>Mostrar lista de todas las interfaces de usuario disponibles</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="488"/>
        <source>Don&apos;t start the application</source>
        <translation>No iniciar la aplicación</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="489"/>
        <source>Print debugging messages</source>
        <translation>Mostrar mensajes de depuración</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="490"/>
        <source>Display this text and exit</source>
        <translation>Muestra este texto y sale</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="491"/>
        <source>Print version number and exit</source>
        <translation>Mostrar el número de versión y salir</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="493"/>
        <source>Home page: %1</source>
        <translation>Página de inicio: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="494"/>
        <source>Development page: %1</source>
        <translation>Página de desarrollo: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="495"/>
        <source>Bug tracker: %1</source>
        <translation>Reporte de errores: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="171"/>
        <location filename="../qmmpstarter.cpp" line="500"/>
        <source>Command Line Help</source>
        <translation>Ayuda de Consola</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="513"/>
        <source>QMMP version: %1</source>
        <translation>QMMP versión: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="514"/>
        <source>Compiled with Qt version: %1</source>
        <translation>Compilado con Qt versión: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="515"/>
        <source>Using Qt version: %1</source>
        <translation>Usando Qt versión: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="518"/>
        <source>Qmmp Version</source>
        <translation>Versión de Qmmp</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="535"/>
        <source>User Interfaces</source>
        <translation>Interfaz de usuario</translation>
    </message>
</context>
</TS>
