<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sk">
<context>
    <name>BuiltinCommandLineOption</name>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="46"/>
        <source>Don&apos;t clear the playlist</source>
        <translation>Nevyčisťovať playlist</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="47"/>
        <source>Start playing current song</source>
        <translation>Začať prehrávanie súčasnej piesne</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="48"/>
        <source>Pause current song</source>
        <translation>Pozastaviť súčasnú pieseň</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="49"/>
        <source>Pause if playing, play otherwise</source>
        <translation>Pozastaviť ak hrá, inak hrať</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="50"/>
        <source>Stop current song</source>
        <translation>Zastaviť súčasnú pieseň</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="51"/>
        <source>Display Jump to Track dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="52"/>
        <source>Quit application</source>
        <translation>Ukončiť program</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="53"/>
        <source>Set playback volume (example: qmmp --volume 20)</source>
        <translation>Nastaviť hlasitosť prehrávania (napríklad: qmmp --volume 20)</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="54"/>
        <source>Print volume level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="55"/>
        <source>Mute/Restore volume</source>
        <translation>Vypnúť/obnoviť zvuk</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="56"/>
        <source>Print mute status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="57"/>
        <source>Skip forward in playlist</source>
        <translation>Posunúť sa v plaliste</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="58"/>
        <source>Skip backwards in playlist</source>
        <translation>Vrátiť sa v playliste</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="59"/>
        <source>Show/hide application</source>
        <translation>Zobraziť/skryť program</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="60"/>
        <source>Show main window</source>
        <translation>Zobraziť hlavné okno</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="61"/>
        <source>Display Add File dialog</source>
        <translation>Zobraziť dialóg Pridať súbor</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="62"/>
        <source>Display Add Directory dialog</source>
        <translation>Zobraziť dialóg Pridať priečinok</translation>
    </message>
</context>
<context>
    <name>QMMPStarter</name>
    <message>
        <location filename="../qmmpstarter.cpp" line="149"/>
        <source>Unknown command</source>
        <translation>Neznámý príkaz</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="479"/>
        <source>Usage: qmmp [options] [files]</source>
        <translation>Použitie: qmmp [možnosti] [súbory]</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="480"/>
        <source>Options:</source>
        <translation>Možnosti:</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="486"/>
        <source>Start qmmp with the specified user interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="487"/>
        <source>List all available user interfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="488"/>
        <source>Don&apos;t start the application</source>
        <translation>Nezapnúť program</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="489"/>
        <source>Print debugging messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="490"/>
        <source>Display this text and exit</source>
        <translation>Zobraziť tento text a skončiť</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="491"/>
        <source>Print version number and exit</source>
        <translation>Vypísať číslo verzie a skončiť</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="493"/>
        <source>Home page: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="494"/>
        <source>Development page: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="495"/>
        <source>Bug tracker: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="171"/>
        <location filename="../qmmpstarter.cpp" line="500"/>
        <source>Command Line Help</source>
        <translation>Nápoveda príkazového riadka</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="513"/>
        <source>QMMP version: %1</source>
        <translation>Verzia QMMP: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="514"/>
        <source>Compiled with Qt version: %1</source>
        <translation>Skompilované s verziou Qt: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="515"/>
        <source>Using Qt version: %1</source>
        <translation>Používaná verzia Qt: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="518"/>
        <source>Qmmp Version</source>
        <translation>Verzia Qmmp</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="535"/>
        <source>User Interfaces</source>
        <translation>Užívateľské rozhrania</translation>
    </message>
</context>
</TS>
