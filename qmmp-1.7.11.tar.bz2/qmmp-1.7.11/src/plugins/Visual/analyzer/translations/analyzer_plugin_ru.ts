<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>Analyzer</name>
    <message>
        <location filename="../analyzer.cpp" line="36"/>
        <source>Qmmp Analyzer</source>
        <translation>Анализатор Qmmp</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="314"/>
        <source>Peaks</source>
        <translation>Пики</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="317"/>
        <source>Refresh Rate</source>
        <translation>Частота обновления</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="320"/>
        <source>50 fps</source>
        <translation>50 кадр/c</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="321"/>
        <source>25 fps</source>
        <translation>25 кадр/c</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="322"/>
        <source>10 fps</source>
        <translation>10 кадр/c</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="323"/>
        <source>5 fps</source>
        <translation>5 кадр/c</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="330"/>
        <source>Analyzer Falloff</source>
        <translation>Падение анализатора</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="333"/>
        <location filename="../analyzer.cpp" line="347"/>
        <source>Slowest</source>
        <translation>Самое медленное</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="334"/>
        <location filename="../analyzer.cpp" line="348"/>
        <source>Slow</source>
        <translation>Медленное</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="335"/>
        <location filename="../analyzer.cpp" line="349"/>
        <source>Medium</source>
        <translation>Среднее</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="336"/>
        <location filename="../analyzer.cpp" line="350"/>
        <source>Fast</source>
        <translation>Быстрое</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="337"/>
        <location filename="../analyzer.cpp" line="351"/>
        <source>Fastest</source>
        <translation>Самое быстрое</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="344"/>
        <source>Peaks Falloff</source>
        <translation>Падение пиков</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="358"/>
        <source>&amp;Full Screen</source>
        <translation>&amp;Полноэкранный режим</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="358"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>AnalyzerColorWidget</name>
    <message>
        <location filename="../analyzercolorwidget.cpp" line="37"/>
        <source>Select Color</source>
        <translation>Выберите цвет</translation>
    </message>
</context>
<context>
    <name>AnalyzerSettingsDialog</name>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="14"/>
        <source>Analyzer Plugin Settings</source>
        <translation>Настройки  анализатора</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="35"/>
        <source>General</source>
        <translation>Общие</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="41"/>
        <source>Cells size:</source>
        <translation>Размер ячеек:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="101"/>
        <source>Colors</source>
        <translation>Цвета</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="107"/>
        <source>Peaks:</source>
        <translation>Пики:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="139"/>
        <source>Analyzer #1:</source>
        <translation>Анализатор №1:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="171"/>
        <source>Background:</source>
        <translation>Фон:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="203"/>
        <source>Analyzer #2:</source>
        <translation>Анализатор №2:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="248"/>
        <source>Analyzer #3:</source>
        <translation>Анализатор №3:</translation>
    </message>
</context>
<context>
    <name>VisualAnalyzerFactory</name>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="30"/>
        <source>Analyzer Plugin</source>
        <translation>Анализатор</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="49"/>
        <source>About Analyzer Visual Plugin</source>
        <translation>Об анализаторе (модуле визуализации)</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="50"/>
        <source>Qmmp Analyzer Visual Plugin</source>
        <translation>Модуль анализатора для Qmmp</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="51"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Разработчик: Илья Котов &lt;forkotov02@ya.ru&gt;</translation>
    </message>
</context>
</TS>
