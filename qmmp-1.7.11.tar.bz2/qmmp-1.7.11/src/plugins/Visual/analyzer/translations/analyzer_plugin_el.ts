<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el">
<context>
    <name>Analyzer</name>
    <message>
        <location filename="../analyzer.cpp" line="36"/>
        <source>Qmmp Analyzer</source>
        <translation>Αναλυτής Qmmp</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="314"/>
        <source>Peaks</source>
        <translation>Αιχμές</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="317"/>
        <source>Refresh Rate</source>
        <translation>Ρυθμός ανανέωσης</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="320"/>
        <source>50 fps</source>
        <translation>50 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="321"/>
        <source>25 fps</source>
        <translation>25 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="322"/>
        <source>10 fps</source>
        <translation>10 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="323"/>
        <source>5 fps</source>
        <translation>5 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="330"/>
        <source>Analyzer Falloff</source>
        <translation>Πτώση Αναλυτή</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="333"/>
        <location filename="../analyzer.cpp" line="347"/>
        <source>Slowest</source>
        <translation>Βραδύτατη</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="334"/>
        <location filename="../analyzer.cpp" line="348"/>
        <source>Slow</source>
        <translation>Αργή</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="335"/>
        <location filename="../analyzer.cpp" line="349"/>
        <source>Medium</source>
        <translation>Μέση</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="336"/>
        <location filename="../analyzer.cpp" line="350"/>
        <source>Fast</source>
        <translation>Γρήγορη</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="337"/>
        <location filename="../analyzer.cpp" line="351"/>
        <source>Fastest</source>
        <translation>Τάχιστη</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="344"/>
        <source>Peaks Falloff</source>
        <translation>Πτώση αιχμών</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="358"/>
        <source>&amp;Full Screen</source>
        <translation>&amp;Πλήρης οθόνη</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="358"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>AnalyzerColorWidget</name>
    <message>
        <location filename="../analyzercolorwidget.cpp" line="37"/>
        <source>Select Color</source>
        <translation>Επιλογή χρώματος</translation>
    </message>
</context>
<context>
    <name>AnalyzerSettingsDialog</name>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="14"/>
        <source>Analyzer Plugin Settings</source>
        <translation>Ρυθμίσεις του πρόσθετου του αναλυτή</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="35"/>
        <source>General</source>
        <translation>Γενικά</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="41"/>
        <source>Cells size:</source>
        <translation>Μέγεθος κελιών:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="101"/>
        <source>Colors</source>
        <translation>Χρώματα</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="107"/>
        <source>Peaks:</source>
        <translation>Αιχμές:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="139"/>
        <source>Analyzer #1:</source>
        <translation>Αναλυτής #1:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="171"/>
        <source>Background:</source>
        <translation>Παρασκήνιο:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="203"/>
        <source>Analyzer #2:</source>
        <translation>Αναλυτής #2:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="248"/>
        <source>Analyzer #3:</source>
        <translation>Αναλυτής #3:</translation>
    </message>
</context>
<context>
    <name>VisualAnalyzerFactory</name>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="30"/>
        <source>Analyzer Plugin</source>
        <translation>Πρόσθετο αναλυτή</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="49"/>
        <source>About Analyzer Visual Plugin</source>
        <translation>Σχετικά με το πρόσθετο οπτικού αναλυτή</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="50"/>
        <source>Qmmp Analyzer Visual Plugin</source>
        <translation>Πρόσθετο Qmmp οπτικού αναλυτή</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="51"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Γράφτηκε από τον: Ilya Kotov &lt;forkotov02@hotmail.ru&gt;</translation>
    </message>
</context>
</TS>
