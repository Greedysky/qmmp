<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fi">
<context>
    <name>ProjectM4Widget</name>
    <message>
        <location filename="../projectm4widget.cpp" line="163"/>
        <source>&amp;Show Menu</source>
        <translation>&amp;Näytä valikko</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="163"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="165"/>
        <source>&amp;Next Preset</source>
        <translation>&amp;Seuraava esiasetus</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="165"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="166"/>
        <source>&amp;Previous Preset</source>
        <translation>&amp;Edellinen esiasetus</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="166"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="167"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;Sekoita</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="167"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="168"/>
        <source>&amp;Lock Preset</source>
        <translation>&amp;Lukitse esiasetus</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="168"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="170"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Koko näyttö</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="170"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>ProjectMPlugin</name>
    <message>
        <location filename="../projectmplugin.cpp" line="42"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
</context>
<context>
    <name>ProjectMWidget</name>
    <message>
        <location filename="../projectmwidget.cpp" line="143"/>
        <source>&amp;Help</source>
        <translation>&amp;Ohje</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="143"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="144"/>
        <source>&amp;Show Song Title</source>
        <translation>&amp;Näytä kappaleen nimi</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="144"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="145"/>
        <source>&amp;Show Preset Name</source>
        <translation>&amp;Näytä esiasetuksen nimi</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="145"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <source>&amp;Show Menu</source>
        <translation>&amp;Näytä valikko</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <source>&amp;Next Preset</source>
        <translation>&amp;Seuraava esiasetus</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <source>&amp;Previous Preset</source>
        <translation>&amp;Edellinen esiasetus</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <source>&amp;Random Preset</source>
        <translation>&amp;Satunnainen esiasetus</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <source>&amp;Lock Preset</source>
        <translation>&amp;Lukitse esiasetus</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Koko näyttö</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>VisualProjectMFactory</name>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="30"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="50"/>
        <source>About ProjectM Visual Plugin</source>
        <translation>Tietoja: ProjectM Visual Plugin</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="51"/>
        <source>Qmmp ProjectM Visual Plugin</source>
        <translation>Qmmp ProjectM Visual Plugin</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="52"/>
        <source>This plugin adds projectM visualization</source>
        <translation>Tämä laajennus lisää projectM visualisoinnin</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="53"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Kirjoittanut: Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="54"/>
        <source>Based on libprojectM-qt library</source>
        <translation>Pohjautuu libprojectM-qt kirjastoon</translation>
    </message>
</context>
</TS>
