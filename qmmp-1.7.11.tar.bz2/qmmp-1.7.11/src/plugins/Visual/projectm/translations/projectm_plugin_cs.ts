<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>ProjectM4Widget</name>
    <message>
        <location filename="../projectm4widget.cpp" line="163"/>
        <source>&amp;Show Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="163"/>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="165"/>
        <source>&amp;Next Preset</source>
        <translation type="unfinished">&amp;Další předvolby</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="165"/>
        <source>N</source>
        <translation type="unfinished">N</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="166"/>
        <source>&amp;Previous Preset</source>
        <translation type="unfinished">Př&amp;edchozí předvolby</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="166"/>
        <source>P</source>
        <translation type="unfinished">P</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="167"/>
        <source>&amp;Shuffle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="167"/>
        <source>R</source>
        <translation type="unfinished">R</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="168"/>
        <source>&amp;Lock Preset</source>
        <translation type="unfinished">U&amp;zamknout předvolby</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="168"/>
        <source>L</source>
        <translation type="unfinished">L</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="170"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">&amp;Celá obrazovka</translation>
    </message>
    <message>
        <location filename="../projectm4widget.cpp" line="170"/>
        <source>F</source>
        <translation type="unfinished">F</translation>
    </message>
</context>
<context>
    <name>ProjectMPlugin</name>
    <message>
        <location filename="../projectmplugin.cpp" line="42"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
</context>
<context>
    <name>ProjectMWidget</name>
    <message>
        <location filename="../projectmwidget.cpp" line="143"/>
        <source>&amp;Help</source>
        <translation>&amp;Nápověda</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="143"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="144"/>
        <source>&amp;Show Song Title</source>
        <translation>&amp;Zobrazit název skladby</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="144"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="145"/>
        <source>&amp;Show Preset Name</source>
        <translation>Zobrazit název &amp;předvoleb</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="145"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <source>&amp;Show Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="146"/>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <source>&amp;Next Preset</source>
        <translation>&amp;Další předvolby</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <source>&amp;Previous Preset</source>
        <translation>Př&amp;edchozí předvolby</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <source>&amp;Random Preset</source>
        <translation>Ná&amp;hodné předvolby</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <source>&amp;Lock Preset</source>
        <translation>U&amp;zamknout předvolby</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Celá obrazovka</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>VisualProjectMFactory</name>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="30"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="50"/>
        <source>About ProjectM Visual Plugin</source>
        <translation>O vizualizačním modulu ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="51"/>
        <source>Qmmp ProjectM Visual Plugin</source>
        <translation>Vizualizační modul Qmmp ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="52"/>
        <source>This plugin adds projectM visualization</source>
        <translation>Tento modul přidává vizualizaci ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="53"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="54"/>
        <source>Based on libprojectM-qt library</source>
        <translation>Založeno na knihovně libprojectM-qt</translation>
    </message>
</context>
</TS>
